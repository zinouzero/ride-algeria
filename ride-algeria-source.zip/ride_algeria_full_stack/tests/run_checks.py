from pathlib import Path
import json, subprocess, sys, unittest, shutil, tomllib
ROOT = Path(__file__).resolve().parents[1]

class ReleaseStaticChecks(unittest.TestCase):
    def test_supabase_function_config_matches_folders(self):
        config = tomllib.loads((ROOT/'supabase/config.toml').read_text())
        configured = set(config.get('functions',{}))
        folders = {p.name for p in (ROOT/'supabase/functions').iterdir() if p.is_dir() and p.name != '_shared'}
        self.assertEqual(configured, folders)
        self.assertEqual(len(configured),17)

    def test_migrations_are_ordered_and_present(self):
        files = sorted((ROOT/'supabase/migrations').glob('*.sql'))
        self.assertGreaterEqual(len(files), 21)
        self.assertEqual([p.name[:14] for p in files], sorted(p.name[:14] for p in files))

    def test_trip_event_schema_and_writes_use_metadata(self):
        schema = (ROOT/'supabase/migrations/202611060001_initial_schema.sql').read_text()
        self.assertIn('metadata jsonb', schema)
        for p in list((ROOT/'supabase/functions').rglob('*.ts')) + list((ROOT/'supabase/migrations').glob('*.sql')):
            text = p.read_text()
            self.assertNotIn('event_type,payload', text, str(p))
            self.assertNotIn('event_type:"no_driver_found",payload', text, str(p))

    def test_quotes_fail_closed_without_routing_adapter(self):
        src = (ROOT/'supabase/functions/create-quote/index.ts').read_text()
        self.assertIn('ROUTING_ADAPTER_URL', src)
        self.assertIn('routing_not_configured', src)
        self.assertNotIn('straight_line_approximation', src)

    def test_trip_creation_is_atomic_and_dispatch_starts(self):
        sql = (ROOT/'supabase/migrations/202611060006_atomic_trip_creation.sql').read_text()
        fn = (ROOT/'supabase/functions/request-trip/index.ts').read_text()
        self.assertIn('create_trip_from_quote', sql)
        self.assertIn('on conflict(actor_id,operation,idempotency_key) do nothing', sql.lower())
        self.assertIn('/functions/v1/dispatch-trip', fn)

    def test_driver_acceptance_requires_approval_and_vehicle(self):
        sql = (ROOT/'supabase/migrations/202611060005_release_security_and_auth.sql').read_text()
        self.assertIn("status='approved'", sql)
        self.assertIn('matching_vehicle_required', sql)
        self.assertIn('vehicle_id=v_vehicle.id', sql)
        self.assertIn('select max_capacity from public.ride_categories', sql)

    def test_role_specific_trip_transitions(self):
        sql = (ROOT/'supabase/migrations/202611060005_release_security_and_auth.sql').read_text()
        self.assertIn("v_is_passenger and v_trip.status in ('requested','searching','assigned'", sql)
        cancel_sql = (ROOT/'supabase/migrations/202611060010_passenger_search_cancellation.sql').read_text()
        self.assertIn("'requested','searching','assigned'", cancel_sql)
        self.assertIn("v_is_driver and (", sql)

    def test_offer_retry_index_is_partial(self):
        sql = (ROOT/'supabase/migrations/202611060008_realtime_and_offer_retry.sql').read_text()
        self.assertIn("where status in ('offered','accepted')", sql)
        self.assertIn("status='expired'", (ROOT/'supabase/migrations/202611060013_dispatch_retry_worker.sql').read_text())
        geo = (ROOT/'supabase/migrations/202611060011_geospatial_dispatch.sql').read_text()
        self.assertIn('using gist(location)', geo.lower())
        self.assertIn('st_dwithin', geo.lower())
        self.assertIn('find_dispatch_candidates', (ROOT/'supabase/migrations/202611060013_dispatch_retry_worker.sql').read_text())

    def test_no_service_role_key_in_client_sources(self):
        for folder in ['passenger_app/lib','driver_app/lib','admin_console/app','admin_console/lib']:
            for p in (ROOT/folder).rglob('*'):
                if p.is_file() and p.suffix in {'.dart','.ts','.tsx'}:
                    self.assertNotIn('SUPABASE_SERVICE_ROLE_KEY', p.read_text(), str(p))

    def test_fake_ride_data_not_in_release_apps(self):
        for folder in ['passenger_app/lib','driver_app/lib']:
            for p in (ROOT/folder).rglob('*.dart'):
                text = p.read_text().lower()
                self.assertNotIn('quote-demo', text, str(p))
                self.assertNotIn('ride-demo', text, str(p))
                self.assertNotIn('عرض تجريبي', text, str(p))

    def test_driver_onboarding_and_atomic_admin_review(self):
        sql = (ROOT/'supabase/migrations/202611060009_driver_onboarding.sql').read_text()
        self.assertIn('submit_driver_application', sql)
        self.assertIn('review_driver_application', sql)
        self.assertIn('driver-documents', sql)
        self.assertIn('admin_audit_log', sql)
        self.assertTrue((ROOT/'supabase/functions/submit-driver-application/index.ts').exists())
        self.assertTrue((ROOT/'supabase/functions/review-driver-application/index.ts').exists())

    def test_geocoding_adapter_is_fail_closed(self):
        src = (ROOT/'supabase/functions/search-places/index.ts').read_text()
        self.assertIn('GEOCODING_ADAPTER_URL', src)
        self.assertIn('geocoding_not_configured', src)
        self.assertIn('country_code', src)

    def test_dispatch_retries_are_locked_and_secret_protected(self):
        sql = (ROOT/'supabase/migrations/202611060013_dispatch_retry_worker.sql').read_text()
        worker = (ROOT/'supabase/functions/dispatch-worker/index.ts').read_text()
        self.assertIn('for update skip locked', sql.lower())
        self.assertIn('dispatch_attempts between 0 and 5', sql.lower())
        self.assertIn('DISPATCH_WORKER_SECRET', worker)
        self.assertIn('process_dispatch_attempt', worker)
        self.assertIn('verify_jwt = false', (ROOT/'supabase/config.toml').read_text())

    def test_cash_collection_is_server_calculated_and_idempotent(self):
        sql = (ROOT/'supabase/migrations/202611060012_cash_collection.sql').read_text()
        fn = (ROOT/'supabase/functions/mark-cash-collected/index.ts').read_text()
        self.assertIn("v_trip.status<>'completed'", sql)
        self.assertIn("v_cash.status='collected'", sql)
        self.assertIn("'cash_collected'", sql)
        self.assertIn('mark-cash-collected', (ROOT/'driver_app/lib/main.dart').read_text())
        self.assertIn('mark_cash_collected', fn)

    def test_rating_is_bound_to_completed_owned_trip(self):
        sql = (ROOT/'supabase/migrations/202611060014_trip_ratings.sql').read_text()
        fn = (ROOT/'supabase/functions/submit-rating/index.ts').read_text()
        self.assertIn('v_trip.passenger_id<>p_passenger_id', sql)
        self.assertIn("v_trip.status<>'completed'", sql)
        self.assertIn('rating_count=rating_count+1', sql)
        self.assertIn('submit-rating', (ROOT/'passenger_app/lib/main.dart').read_text())
        self.assertIn('submit_trip_rating', fn)

    def test_driver_active_trip_restores_after_restart(self):
        sql = (ROOT/'supabase/migrations/202611060021_driver_active_trip_restore.sql').read_text()
        fn = (ROOT/'supabase/functions/driver-active-trip/index.ts').read_text()
        app = (ROOT/'driver_app/lib/main.dart').read_text()
        self.assertIn('get_driver_active_trip', sql)
        self.assertIn('declared_collected_at is null', sql)
        self.assertIn('get_driver_active_trip', fn)
        self.assertIn('restoreActiveTrip', app)

    def test_cash_review_requires_admin_and_driver_declaration(self):
        sql = (ROOT/'supabase/migrations/202611060018_cash_reconciliation.sql').read_text()
        fn = (ROOT/'supabase/functions/review-cash-collection/index.ts').read_text()
        compat = (ROOT/'supabase/migrations/202611060019_cash_review_collection_compat.sql').read_text()
        self.assertIn('driver_receipt_not_declared', sql)
        self.assertIn('admin_required', sql)
        self.assertIn('review-cash-collection', (ROOT/'admin_console/app/cash/review-actions.tsx').read_text())
        self.assertIn('under_review', compat)
        self.assertIn('review_cash_collection', fn)

    def test_support_ticket_creation_and_message_authorization(self):
        migration = (ROOT/'supabase/migrations/202611060016_support_workflow.sql').read_text()
        create_fn = (ROOT/'supabase/functions/create-support-ticket/index.ts').read_text()
        message_fn = (ROOT/'supabase/functions/send-support-message/index.ts').read_text()
        self.assertIn('drop policy if exists "support requester insert"', migration)
        self.assertIn('trip_not_found', create_fn)
        self.assertIn('not_ticket_participant', message_fn)
        self.assertIn('ticket_closed', message_fn)
        self.assertIn('create-support-ticket', (ROOT/'passenger_app/lib/main.dart').read_text())
        self.assertIn('send-support-message', (ROOT/'driver_app/lib/main.dart').read_text())

    def test_service_zone_geojson_is_validated_and_spatially_indexed(self):
        sql = (ROOT/'supabase/migrations/202611060020_postgis_service_zones.sql').read_text()
        fn = (ROOT/'supabase/functions/create-quote/index.ts').read_text()
        self.assertIn('service_zone_geometry_validate', sql)
        self.assertIn('using gist(boundary_geom)', sql.lower())
        self.assertIn('st_covers', sql.lower())
        self.assertIn('resolve_service_zone_for_points', fn)
        self.assertNotIn('pointInGeoJson', fn)

    def test_support_ticket_content_is_protected_and_audited(self):
        sql = (ROOT/'supabase/migrations/202611060017_support_ticket_guard.sql').read_text()
        self.assertIn('support_ticket_content_is_immutable', sql)
        self.assertIn('invalid_support_assignee', sql)
        self.assertIn('audit_support_ticket_changes', sql)

    def test_admin_zone_fare_and_audit_controls(self):
        ui = (ROOT/'admin_console/app/settings/settings-forms.tsx').read_text()
        audit = (ROOT/'supabase/migrations/202611060015_config_audit.sql').read_text()
        self.assertIn('boundary_geojson', ui)
        self.assertIn('base_fare_minor:Math.round(values[0]*100)', ui)
        self.assertIn('audit_fare_rules', audit)
        self.assertIn('admin_audit_log', audit)

    def test_admin_has_otp_and_role_gate(self):
        login = (ROOT/'admin_console/app/login/login-form.tsx').read_text()
        page = (ROOT/'admin_console/app/page.tsx').read_text()
        self.assertIn('signInWithOtp', login)
        self.assertIn('verifyOtp', login)
        self.assertIn("['admin','support']", page)


    def test_dart_delimiters(self):
        files = [p for folder in ['passenger_app/lib','driver_app/lib'] for p in (ROOT/folder).rglob('*.dart')]
        pairs = {')':'(', ']':'[', '}':'{'}
        for path in files:
            source = path.read_text(); stack=[]; i=0; line=1
            while i < len(source):
                c=source[i]
                if c=='\n': line+=1; i+=1; continue
                if source.startswith('//',i):
                    j=source.find('\n',i); i=len(source) if j<0 else j; continue
                if source.startswith('/*',i):
                    j=source.find('*/',i+2); i=len(source) if j<0 else j+2; continue
                if c in 'rR' and i+1<len(source) and source[i+1] in "'\"": i+=1; c=source[i]
                if c in "'\"":
                    q=c; triple=source.startswith(q*3,i); delim=q*3 if triple else q; i+=len(delim)
                    while i<len(source):
                        if source.startswith(delim,i): i+=len(delim); break
                        if source[i]=='\\': i+=2; continue
                        if source[i]=='\n': line+=1
                        i+=1
                    continue
                if c in '([{': stack.append((c,line))
                elif c in ')]}':
                    self.assertTrue(stack and stack[-1][0]==pairs[c], f'{path}:{line}: mismatched {c}')
                    stack.pop()
                i+=1
            self.assertFalse(stack, f'{path}: unclosed delimiters {stack[-3:]}')


    def test_sql_migration_structure(self):
        for path in sorted((ROOT/'supabase/migrations').glob('*.sql')):
            source=path.read_text()
            self.assertEqual(source.count('$$')%2,0,f'{path.name}: unmatched dollar quote')
            stack=[]; i=0; line=1; quote=None
            while i<len(source):
                c=source[i]
                if c=='\n': line+=1; i+=1; continue
                if source.startswith('--',i):
                    j=source.find('\n',i); i=len(source) if j<0 else j; continue
                if source.startswith('/*',i):
                    j=source.find('*/',i+2); self.assertNotEqual(j,-1,f'{path.name}:{line}: unclosed comment'); i=j+2; continue
                if c=="'":
                    i+=1
                    while i<len(source):
                        if source[i]=="'":
                            if i+1<len(source) and source[i+1]=="'": i+=2; continue
                            i+=1; break
                        if source[i]=='\\': i+=2; continue
                        if source[i]=='\n': line+=1
                        i+=1
                    continue
                if c=='"':
                    i+=1
                    while i<len(source):
                        if source[i]=='"':
                            if i+1<len(source) and source[i+1]=='"': i+=2; continue
                            i+=1; break
                        i+=1
                    continue
                if c=='(' : stack.append(line)
                elif c==')': self.assertTrue(stack,f'{path.name}:{line}: extra )'); stack.pop()
                i+=1
            self.assertFalse(stack,f'{path.name}: unclosed parentheses {stack[-3:]}')
            without_line_comments='\n'.join(line.split('--',1)[0] for line in source.splitlines())
            self.assertTrue(without_line_comments.rstrip().endswith(';'),f'{path.name}: missing final semicolon')

    def test_typescript_syntax(self):
        files = [p for folder in ['supabase/functions','admin_console'] for p in (ROOT/folder).rglob('*')
                 if p.is_file() and p.suffix in {'.ts','.tsx'} and not p.name.endswith('.d.ts')]
        node = shutil.which('node')
        if not node: self.skipTest('Node.js is not installed')
        module = ROOT/'admin_console/node_modules/typescript/lib/typescript.js'
        if not module.exists():
            npm_root = subprocess.run(['npm','root','-g'],text=True,capture_output=True)
            if npm_root.returncode == 0:
                module = Path(npm_root.stdout.strip())/'typescript/lib/typescript.js'
        if not module.exists(): self.skipTest('TypeScript package is not installed')
        script = r'''const ts=require(process.argv[1]);
const fs=require('fs'); const files=JSON.parse(fs.readFileSync(0,'utf8')); let errors=[];
for(const f of files){const s=fs.readFileSync(f,'utf8');const out=ts.transpileModule(s,{fileName:f,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}});for(const d of (out.diagnostics||[])){if(d.category===ts.DiagnosticCategory.Error)errors.push(f+': '+ts.flattenDiagnosticMessageText(d.messageText,' '));}}
if(errors.length){console.error(errors.join('\n'));process.exit(1)} console.log('TypeScript syntax OK:',files.length,'files');'''
        proc = subprocess.run([node,'-e',script,str(module)],input=json.dumps([str(p) for p in files]),text=True,capture_output=True)
        self.assertEqual(proc.returncode,0,proc.stdout+'\n'+proc.stderr)

if __name__ == '__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ReleaseStaticChecks)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
