import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:geolocator/geolocator.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabasePublishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
String formatDzd(dynamic minor) { final value=(num.tryParse(minor.toString())??0)/100; return value==value.roundToDouble()?value.toStringAsFixed(0):value.toStringAsFixed(2); }

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabasePublishableKey.isEmpty) {
    runApp(const DriverConfigurationApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  runApp(const DriverApp());
}

class DriverConfigurationApp extends StatelessWidget {
  const DriverConfigurationApp({super.key});
  @override Widget build(BuildContext context) => const MaterialApp(home: Scaffold(body: Center(child: Padding(
    padding: EdgeInsets.all(24), child: Text('يلزم ربط مشروع الخادم ومفتاح التطبيق قبل تشغيل تطبيق السائق.', textAlign: TextAlign.center)))));
}

class DriverApp extends StatelessWidget {
  const DriverApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(debugShowCheckedModeBanner: false, title: 'مشواري للسائق',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF167647))),
    locale: const Locale('ar'), supportedLocales: const [Locale('ar'), Locale('fr'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates, home: const DriverAuthGate(),
    builder: (context, child) => Directionality(textDirection: Localizations.localeOf(context).languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr, child: child ?? const SizedBox.shrink()));
}

class DriverAuthGate extends StatelessWidget {
  const DriverAuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<AuthState>(stream: Supabase.instance.client.auth.onAuthStateChange,
    builder: (context, _) => Supabase.instance.client.auth.currentSession == null ? const DriverLoginScreen() : const DriverAccountGate());
}

class DriverLoginScreen extends StatefulWidget { const DriverLoginScreen({super.key}); @override State<DriverLoginScreen> createState()=>_DriverLoginScreenState(); }
class _DriverLoginScreenState extends State<DriverLoginScreen> {
  final phone=TextEditingController(text:'+213'), code=TextEditingController(); bool sent=false,busy=false; String? error;
  Future<void> submit() async { setState(()=>busy=true); try {
    if(!sent){ await Supabase.instance.client.auth.signInWithOtp(phone:phone.text.trim()); setState(()=>sent=true); }
    else { await Supabase.instance.client.auth.verifyOTP(phone:phone.text.trim(),token:code.text.trim(),type:OtpType.sms); }
  } on AuthException catch(e){setState(()=>error=e.message);} catch(_){setState(()=>error='تعذر تسجيل الدخول.');} finally{if(mounted)setState(()=>busy=false);} }
  @override void dispose(){phone.dispose();code.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(
    constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      const Icon(Icons.local_taxi,size:64,color:Color(0xFF167647)),const SizedBox(height:18),
      const Text('منصة السائق',textAlign:TextAlign.center,style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
      const SizedBox(height:22),TextField(controller:phone,enabled:!sent,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'رقم الهاتف الدولي',border:OutlineInputBorder())),
      if(sent) ...[const SizedBox(height:12),TextField(controller:code,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'رمز التحقق',border:OutlineInputBorder()))],
      if(error!=null) Text(error!,style:const TextStyle(color:Colors.red)),const SizedBox(height:16),
      FilledButton(onPressed:busy?null:submit,child:Text(busy?'يرجى الانتظار':sent?'تأكيد الرمز':'إرسال رمز التحقق')),
    ]))))));
}

class DriverAccountGate extends StatefulWidget { const DriverAccountGate({super.key}); @override State<DriverAccountGate> createState()=>_DriverAccountGateState(); }
class _DriverAccountGateState extends State<DriverAccountGate> {
  late Future<Map<String,dynamic>> account;
  @override void initState(){super.initState();account=load();}
  Future<Map<String,dynamic>> load() async {
    final db=Supabase.instance.client; final uid=db.auth.currentUser!.id;
    final p=await db.from('profiles').select('role,is_active').eq('id',uid).maybeSingle();
    final d=await db.from('driver_profiles').select('status,rejection_reason').eq('user_id',uid).maybeSingle();
    return {'profile':p,'driver':d};
  }
  @override Widget build(BuildContext context)=>FutureBuilder<Map<String,dynamic>>(future:account,builder:(context,s){
    if(s.connectionState!=ConnectionState.done)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final p=s.data?['profile'] as Map<String,dynamic>?; final d=s.data?['driver'] as Map<String,dynamic>?;
    if(p==null||p['is_active']!=true)return const AccountNotice(message:'الحساب غير نشط. تواصل مع الدعم.');
    if(d==null)return const DriverApplicationScreen();
    if(d['status']!='approved')return AccountNotice(message:d['status']=='pending'?'ملفك قيد المراجعة. ستتمكن من استقبال الرحلات بعد اعتماد الوثائق والمركبة.':'تم رفض الطلب: ${d['rejection_reason']??'راجع الإدارة لتصحيح الملف.'}');
    if(p['role']!='driver')return const AccountNotice(message:'حالة الحساب غير متطابقة. تواصل مع الدعم.');
    return const DriverHome();
  });
}

class DriverApplicationScreen extends StatefulWidget { const DriverApplicationScreen({super.key}); @override State<DriverApplicationScreen> createState()=>_DriverApplicationScreenState(); }
class _DriverApplicationScreenState extends State<DriverApplicationScreen> {
  final make=TextEditingController(),model=TextEditingController(),color=TextEditingController(),plate=TextEditingController();
  List<Map<String,dynamic>> categories=[]; String? category,docType='vehicle_registration',error; int capacity=4; bool busy=false;
  final List<Map<String,String>> uploaded=[];
  @override void initState(){super.initState();loadCategories();}
  Future<void> loadCategories() async {try{final rows=await Supabase.instance.client.from('ride_categories').select('code,display_name,min_capacity,max_capacity').eq('is_active',true);if(mounted)setState(()=>categories=(rows as List).cast<Map<String,dynamic>>());}catch(_){}}
  Future<void> uploadDocs() async {
    try {
      final files=await FilePicker.pickFiles(type:FileType.custom,allowedExtensions:['jpg','jpeg','png','pdf']);
      if(files.isEmpty)return;
      setState(()=>busy=true);
      final uid=Supabase.instance.client.auth.currentUser!.id;
      for(final f in files){
        final bytes=await f.readAsBytes();
        final path='$uid/${DateTime.now().microsecondsSinceEpoch}_${f.name.replaceAll(RegExp(r'[^A-Za-z0-9._-]'),'_')}';
        final ext=(f.extension??'').toLowerCase();
        final mime=ext=='pdf'?'application/pdf':ext=='png'?'image/png':'image/jpeg';
        await Supabase.instance.client.storage.from('driver-documents').uploadBinary(path,bytes,fileOptions:FileOptions(contentType:mime,upsert:false));
        uploaded.add({'document_type':docType??'supporting_document','storage_path':path});
      }
      if(mounted)setState(()=>error=null);
    }catch(e){if(mounted)setState(()=>error='تعذر رفع الوثائق: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> submit() async {
    if(category==null||uploaded.isEmpty){setState(()=>error='اختر فئة المركبة وارفع وثيقة واحدة على الأقل.');return;}
    setState(()=>busy=true);try{
      final response=await Supabase.instance.client.functions.invoke('submit-driver-application',body:{
        'vehicle':{'make':make.text.trim(),'model':model.text.trim(),'color':color.text.trim(),'plate_number':plate.text.trim(),'category_code':category,'passenger_capacity':capacity},
        'documents':uploaded,
      });
      if(response.status<200||response.status>=300)throw Exception('رفض الخادم الطلب. راجع المعلومات والوثائق.');
      if(mounted)Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const AccountNotice(message:'تم إرسال طلبك. سيظهر حسابك بعد مراجعة الإدارة للوثائق والمركبة.')));
    }catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}
  }
  @override void dispose(){make.dispose();model.dispose();color.dispose();plate.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تسجيل سائق')),
    body:ListView(padding:const EdgeInsets.all(18),children:[
      const Text('معلومات المركبة',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      TextField(controller:make,decoration:const InputDecoration(labelText:'الشركة المصنعة')),
      TextField(controller:model,decoration:const InputDecoration(labelText:'طراز المركبة')),
      TextField(controller:color,decoration:const InputDecoration(labelText:'اللون')),
      TextField(controller:plate,decoration:const InputDecoration(labelText:'رقم التسجيل')),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'فئة الرحلة'),items:categories.map((c)=>DropdownMenuItem(value:c['code'] as String,child:Text(c['display_name'] as String))).toList(),onChanged:(v)=>setState(()=>category=v)),
      const SizedBox(height:12),DropdownButtonFormField<int>(value:capacity,decoration:const InputDecoration(labelText:'عدد المقاعد'),items:List.generate(12,(i)=>i+1).map((v)=>DropdownMenuItem(value:v,child:Text('$v'))).toList(),onChanged:(v)=>setState(()=>capacity=v??4)),
      const Divider(height:32),const Text('وثائق المركبة والسائق',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      DropdownButtonFormField<String>(value:docType,decoration:const InputDecoration(labelText:'نوع الوثيقة'),items:const [DropdownMenuItem(value:'driver_identity',child:Text('هوية السائق')),DropdownMenuItem(value:'driving_license',child:Text('رخصة السياقة')),DropdownMenuItem(value:'vehicle_registration',child:Text('بطاقة ترقيم المركبة')),DropdownMenuItem(value:'insurance',child:Text('التأمين')),DropdownMenuItem(value:'other',child:Text('وثيقة أخرى'))],onChanged:(v)=>setState(()=>docType=v)),
      OutlinedButton.icon(onPressed:busy?null:uploadDocs,icon:const Icon(Icons.upload_file),label:Text('رفع الوثائق (${uploaded.length})')),
      for(final d in uploaded) ListTile(dense:true,leading:const Icon(Icons.description_outlined),title:Text(d['document_type']!),subtitle:Text(d['storage_path']!.split('/').last)),
      if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),const SizedBox(height:16),
      FilledButton(onPressed:busy?null:submit,child:Text(busy?'يرجى الانتظار...':'إرسال طلب الاعتماد')),
      const SizedBox(height:10),const Text('لن تتمكن من استقبال الرحلات حتى تراجع الإدارة الملف وتعتمد السائق والمركبة.',textAlign:TextAlign.center,style:TextStyle(color:Colors.black54,fontSize:12)),
    ]));
}

class AccountNotice extends StatelessWidget { const AccountNotice({super.key,required this.message}); final String message;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(actions:[IconButton(onPressed:()=>Supabase.instance.client.auth.signOut(),icon:const Icon(Icons.logout))]),body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Text(message,textAlign:TextAlign.center,style:const TextStyle(fontSize:18))))); }

class DriverHome extends StatefulWidget { const DriverHome({super.key}); @override State<DriverHome> createState()=>_DriverHomeState(); }
class _DriverHomeState extends State<DriverHome> {
  final db=Supabase.instance.client; Timer? locationTimer; bool online=false,busy=false; String? activeTripId,error;
  String get uid=>db.auth.currentUser!.id;
  @override void initState(){super.initState();restoreActiveTrip();}
  Future<void> restoreActiveTrip() async {
    try {
      final r=await db.functions.invoke('driver-active-trip',body:{});
      final active=(r.data as Map?)?['active_trip'];
      if(active is Map){activeTripId=active['trip_id'] as String?;online=activeTripId!=null;}
    }catch(e){error='تعذر استعادة حالة الرحلة: $e';}
    if(!mounted)return;setState((){});
    if(activeTripId!=null){
      try{await sendLocation(available:false);}catch(e){if(mounted)setState(()=>error='فعّل الموقع لمتابعة الرحلة: $e');}
      locationTimer=Timer.periodic(const Duration(seconds:12),(_)=>sendLocation(available:activeTripId==null).catchError((_){}));
    } else {
      try{await db.functions.invoke('update-driver-location',body:{'online':false,'available':false});}catch(_){}
    }
  }
  Stream<List<Map<String,dynamic>>> get offers=>db.from('driver_offers').stream(primaryKey:['id']).eq('driver_id',uid);
  Future<Position> currentPosition() async {
    if(!await Geolocator.isLocationServiceEnabled())throw Exception('فعّل خدمة الموقع.');
    var p=await Geolocator.checkPermission(); if(p==LocationPermission.denied)p=await Geolocator.requestPermission();
    if(p==LocationPermission.denied||p==LocationPermission.deniedForever)throw Exception('يلزم السماح بموقع الهاتف.');
    return Geolocator.getCurrentPosition(locationSettings:const LocationSettings(accuracy:LocationAccuracy.high));
  }
  Future<void> sendLocation({bool? available}) async {
    final pos=await currentPosition();
    await db.functions.invoke('update-driver-location',body:{'online':true,'available':available ?? (activeTripId == null),'latitude':pos.latitude,'longitude':pos.longitude,'accuracy_m':pos.accuracy,'heading':pos.heading});
  }
  Future<void> toggleOnline() async {
    if(online&&activeTripId!=null){setState(()=>error='لا يمكن إيقاف الموقع أثناء رحلة نشطة.');return;}
    setState(()=>busy=true); try {
      if(!online){await sendLocation(); locationTimer?.cancel(); locationTimer=Timer.periodic(const Duration(seconds:12),(_)=>sendLocation(available: activeTripId == null).catchError((_){}));}
      else {locationTimer?.cancel(); await db.functions.invoke('update-driver-location',body:{'online':false,'available':false});}
      setState(()=>online=!online);
    } catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<Map<String,dynamic>?> loadOffer(String id) async {
    try {final r=await db.functions.invoke('driver-offer-details',body:{'offer_id':id}); if(r.status<200||r.status>=300)return null; return Map<String,dynamic>.from(r.data as Map);}catch(_){return null;}
  }
  Future<void> respond(String id,String action) async {
    setState(()=>busy=true); try {final r=await db.functions.invoke('driver-response',body:{'offer_id':id,'action':action});
      if(action=='accept'&&r.data is Map){final result=(r.data as Map)['result']; if(result is Map)activeTripId=result['trip_id'] as String?;}
    }catch(e){setState(()=>error='تعذر تنفيذ العملية: $e');}finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> transition(String next) async {
    if(activeTripId==null)return; setState(()=>busy=true);
    try {await db.functions.invoke('transition-trip',body:{'trip_id':activeTripId,'next_status':next}); if(next=='driver_cancelled'){setState(()=>activeTripId=null);}}
    catch(e){setState(()=>error='تعذر تحديث حالة الرحلة: $e');}finally{if(mounted)setState(()=>busy=false);}
  }
  @override void dispose(){locationTimer?.cancel();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('مشواري للسائق'),actions:[IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DriverSupportScreen())),icon:const Icon(Icons.support_agent)),IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DriverHistoryScreen())),icon:const Icon(Icons.history)),IconButton(onPressed:()=>db.auth.signOut(),icon:const Icon(Icons.logout))]),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text(online?'أنت متصل وتستقبل الطلبات':'أنت غير متصل',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:12),
        FilledButton.icon(onPressed:busy||activeTripId!=null?null:toggleOnline,icon:Icon(online?Icons.pause_circle:Icons.play_circle),label:Text(activeTripId!=null?'رحلة نشطة':busy?'يرجى الانتظار':online?'إيقاف استقبال الرحلات':'بدء استقبال الرحلات')),
      ]))),
      if(error!=null) Padding(padding:const EdgeInsets.all(8),child:Text(error!,style:const TextStyle(color:Colors.red))),
      if(activeTripId!=null) ActiveTripCard(tripId:activeTripId!,busy:busy,onTransition:transition,onClear:()=>setState(()=>activeTripId=null),onCashCollected:() async {setState(()=>busy=true);try{await db.functions.invoke('mark-cash-collected',body:{'trip_id':activeTripId});setState(()=>activeTripId=null);}catch(e){setState(()=>error='تعذر تأكيد استلام المبلغ: $e');}finally{if(mounted)setState(()=>busy=false);}}),
      if(activeTripId==null) StreamBuilder<List<Map<String,dynamic>>>(stream:offers,builder:(context,snapshot){
        final rows=(snapshot.data??[]).where((o)=>o['status']=='offered'&&DateTime.tryParse(o['expires_at']?.toString()??'')?.isAfter(DateTime.now())==true).toList();
        if(!online)return const Card(child:ListTile(title:Text('فعّل الاتصال لاستقبال العروض')));
        if(rows.isEmpty)return const Card(child:ListTile(title:Text('بانتظار طلبات قريبة...')));
        return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[const Padding(padding:EdgeInsets.symmetric(vertical:12),child:Text('عروض الرحلات',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),
          for(final offer in rows) FutureBuilder<Map<String,dynamic>?>(future:loadOffer(offer['id'] as String),builder:(context,detail){
            if(detail.data==null)return const SizedBox.shrink(); final trip=detail.data!['trip'] as Map; final exp=DateTime.tryParse(offer['expires_at'].toString());
            return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
              const Text('طلب رحلة جديد',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),const SizedBox(height:10),
              Text('الانطلاق: ${trip['pickup_label']}'),Text('الوجهة: ${trip['dropoff_label']}'),const Divider(),
              Text('السعر المعروض: ${formatDzd(trip['quoted_fare_minor'])} دج'),
              if(exp!=null)Text('ينتهي العرض: ${TimeOfDay.fromDateTime(exp).format(context)}',style:const TextStyle(color:Colors.black54)),
              const SizedBox(height:12),Row(children:[Expanded(child:OutlinedButton(onPressed:busy?null:()=>respond(offer['id'] as String,'reject'),child:const Text('رفض'))),const SizedBox(width:10),Expanded(child:FilledButton(onPressed:busy?null:()=>respond(offer['id'] as String,'accept'),child:const Text('قبول')))]),
            ])));
          })
        ]);
      }),
    ]));
}

class ActiveTripCard extends StatelessWidget {
  const ActiveTripCard({super.key,required this.tripId,required this.busy,required this.onTransition,required this.onCashCollected,required this.onClear});
  final String tripId; final bool busy; final Future<void> Function(String) onTransition; final Future<void> Function() onCashCollected; final VoidCallback onClear;
  @override Widget build(BuildContext context)=>StreamBuilder<List<Map<String,dynamic>>>(
    stream:Supabase.instance.client.from('trips').stream(primaryKey:['id']).eq('id',tripId),
    builder:(context,s){final rows=s.data??[]; if(rows.isEmpty)return const Card(child:ListTile(title:Text('جارٍ تحميل الرحلة')));
      final trip=rows.first; final status=trip['status'] as String;
      final next=switch(status){'assigned'=>'driver_arriving','driver_arriving'=>'driver_arrived','driver_arrived'=>'in_progress','in_progress'=>'completed',_=>null};
      final lat=trip['pickup_lat']; final lng=trip['pickup_lng'];
      final label=switch(status){'assigned'=>'ابدأ التوجه إلى الراكب','driver_arriving'=>'تأكيد الوصول','driver_arrived'=>'بدء الرحلة','in_progress'=>'إنهاء الرحلة','completed'=>'اكتملت الرحلة',_=>status};
      return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('الرحلة الحالية',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),
        Text('من: ${trip['pickup_label']}'),Text('إلى: ${trip['dropoff_label']}'),const SizedBox(height:10),Text('الحالة: $status'),
        if(lat is num && lng is num)OutlinedButton.icon(onPressed:()=>launchUrl(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving'),mode:LaunchMode.externalApplication),icon:const Icon(Icons.navigation),label:const Text('الملاحة إلى نقطة الانطلاق')),
        if(next!=null)FilledButton(onPressed:busy?null:()=>onTransition(next),child:Text(label)),
        if(['assigned','driver_arriving','driver_arrived'].contains(status))OutlinedButton(onPressed:busy?null:()=>onTransition('driver_cancelled'),child:const Text('إلغاء الرحلة')),
        if(status=='completed')FilledButton.icon(onPressed:busy?null:onCashCollected,icon:const Icon(Icons.payments),label:const Text('تأكيد استلام المبلغ نقداً')),
        if(status=='passenger_cancelled'||status=='driver_cancelled')FilledButton(onPressed:onClear,child:const Text('العودة لاستقبال الرحلات')),
      ])));
    });
}


class DriverHistoryScreen extends StatelessWidget {
  const DriverHistoryScreen({super.key});
  @override Widget build(BuildContext context) {
    final uid=Supabase.instance.client.auth.currentUser!.id;
    return Scaffold(appBar:AppBar(title:const Text('سجل الرحلات')),body:FutureBuilder<List<Map<String,dynamic>>>(
      future:Supabase.instance.client.from('trips').select('id,status,pickup_label,dropoff_label,quoted_fare_minor,created_at').eq('driver_id',uid).order('created_at',ascending:false).limit(50),
      builder:(context,s){if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
        if(s.hasError)return const Center(child:Text('تعذر تحميل سجل الرحلات.'));
        final rows=s.data??[];if(rows.isEmpty)return const Center(child:Text('لا توجد رحلات سابقة.'));
        return ListView.builder(itemCount:rows.length,itemBuilder:(context,i){final r=rows[i];return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(
          title:Text('${r['pickup_label']} ← ${r['dropoff_label']}',maxLines:2,overflow:TextOverflow.ellipsis),
          subtitle:Text('${r['status']} · ${DateTime.parse(r['created_at'] as String).toLocal()}'),
          trailing:Text('${formatDzd(r['quoted_fare_minor'])} دج',style:const TextStyle(fontWeight:FontWeight.bold)),
        ));});
      }));
  }
}


class DriverSupportScreen extends StatefulWidget { const DriverSupportScreen({super.key}); @override State<DriverSupportScreen> createState()=>_DriverSupportScreenState(); }
class _DriverSupportScreenState extends State<DriverSupportScreen> {
  final description=TextEditingController(),reply=TextEditingController();String category='trip';String? ticketId,error;bool busy=false;
  Future<void> createTicket() async {setState(()=>busy=true);try{final r=await Supabase.instance.client.functions.invoke('create-support-ticket',body:{'category':category,'description':description.text.trim()});if(r.status<200||r.status>=300)throw Exception('تعذر إنشاء التذكرة.');setState(()=>ticketId=(r.data as Map)['ticket']['id'] as String);}catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}}
  Future<void> sendReply() async {if(ticketId==null||reply.text.trim().isEmpty)return;setState(()=>busy=true);try{final r=await Supabase.instance.client.functions.invoke('send-support-message',body:{'ticket_id':ticketId,'message':reply.text.trim()});if(r.status<200||r.status>=300)throw Exception('تعذر إرسال الرسالة.');setState(()=>reply.clear());}catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}}
  @override void dispose(){description.dispose();reply.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('مساعدة السائق')),body:ListView(padding:const EdgeInsets.all(18),children:[
    if(ticketId==null)...[const Text('تواصل مع فريق الدعم',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'نوع المشكلة'),items:const [DropdownMenuItem(value:'trip',child:Text('رحلة')),DropdownMenuItem(value:'payment',child:Text('الدفع والتحصيل')),DropdownMenuItem(value:'driver',child:Text('الحساب والمركبة')),DropdownMenuItem(value:'safety',child:Text('السلامة')),DropdownMenuItem(value:'other',child:Text('أخرى'))],onChanged:(v)=>setState(()=>category=v??'other')),
      TextField(controller:description,maxLines:5,maxLength:3000,decoration:const InputDecoration(labelText:'اشرح المشكلة',border:OutlineInputBorder())),FilledButton(onPressed:busy?null:createTicket,child:const Text('إرسال التذكرة'))]
    else ...[const Icon(Icons.check_circle_outline,color:Colors.green,size:54),const Text('تم إنشاء التذكرة',textAlign:TextAlign.center,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),SelectableText(ticketId!,textAlign:TextAlign.center),TextField(controller:reply,maxLines:3,decoration:const InputDecoration(labelText:'إضافة تفاصيل أخرى',border:OutlineInputBorder())),FilledButton(onPressed:busy?null:sendReply,child:const Text('إرسال رسالة'))],
    if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
  ]));
}
