# Driver Android app

Flutter application using Supabase phone OTP, driver onboarding with private document upload, admin approval gate, online/offline state, foreground GPS updates, realtime trip offers, accept/reject, and server-validated trip lifecycle transitions.

The app intentionally does not allow a driver to receive offers before the driver profile and vehicle are approved. Location updates currently run only while the app is foregrounded; an Android foreground service and FCM background notifications are mandatory before commercial launch. Android host files can be regenerated with `../scripts/bootstrap_android.sh`.
