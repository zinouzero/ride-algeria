#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for spec in "passenger_app passenger com.mashwari.passenger مشواري" "driver_app driver com.mashwari.driver مشواري للسائق"; do
  read -r folder project package label <<< "$spec"
  APP="$ROOT/$folder"
  rm -rf "$APP/android"
  (cd "$APP" && flutter create --platforms=android --org com.mashwari --project-name "$project" --no-pub .)
  python "$ROOT/scripts/configure_android.py" "$APP" "$package" "$label"
done
echo "Android projects regenerated. Configure android/key.properties and upload keystores before release signing."
