$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
if (-not $env:SUPABASE_PROJECT_REF) { throw 'Set SUPABASE_PROJECT_REF.' }
if (-not (Get-Command supabase -ErrorAction SilentlyContinue)) { throw 'Supabase CLI is required.' }
Push-Location $Root
supabase link --project-ref $env:SUPABASE_PROJECT_REF
supabase db push
$functions = @('create-quote','create-support-ticket','dispatch-trip','dispatch-worker','driver-active-trip','driver-offer-details','driver-response','mark-cash-collected','request-trip','review-cash-collection','review-driver-application','search-places','send-support-message','submit-driver-application','submit-rating','transition-trip','update-driver-location')
foreach ($function in $functions) { supabase functions deploy $function }
Pop-Location
Write-Host 'Backend deployed. Configure all function secrets and the secure dispatch scheduler before traffic.'
