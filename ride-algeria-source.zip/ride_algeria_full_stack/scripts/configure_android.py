from pathlib import Path
import sys

app = Path(sys.argv[1]).resolve()
package = sys.argv[2]
label = sys.argv[3]
manifest = app / 'android/app/src/main/AndroidManifest.xml'
gradle = app / 'android/app/build.gradle'

s = manifest.read_text(encoding='utf-8')
s = s.replace('android:label="passenger"', f'android:label="{label}"')
s = s.replace('android:label="driver"', f'android:label="{label}"')
needle = '<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
perms = '''\n    <uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />'''
if 'android.permission.ACCESS_FINE_LOCATION' not in s:
    s = s.replace(needle, needle + perms)
s = s.replace('android:usesCleartextTraffic="true"', 'android:usesCleartextTraffic="false"')
manifest.write_text(s, encoding='utf-8')

g = gradle.read_text(encoding='utf-8')
if 'keystorePropertiesFile' not in g:
    prefix = '''def keystoreProperties = new Properties()\ndef keystorePropertiesFile = rootProject.file('key.properties')\nif (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }\n\n'''
    g = prefix + g
if 'signingConfigs {' not in g:
    g = g.replace('    buildTypes {', '''    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties['keyAlias']
                keyPassword = keystoreProperties['keyPassword']
                storeFile = file(keystoreProperties['storeFile'])
                storePassword = keystoreProperties['storePassword']
            }
        }
    }
    buildTypes {''')
g = g.replace('signingConfig = signingConfigs.debug', 'signingConfig = signingConfigs.release')
g = g.replace('namespace = "com.example.' + ('passenger' if 'passenger' in package else 'driver') + '"', f'namespace = "{package}"')
g = g.replace('applicationId = "com.example.' + ('passenger' if 'passenger' in package else 'driver') + '"', f'applicationId = "{package}"')
gradle.write_text(g, encoding='utf-8')
