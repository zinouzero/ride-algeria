#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${SUPABASE_URL:?Set SUPABASE_URL}"
: "${SUPABASE_PUBLISHABLE_KEY:?Set SUPABASE_PUBLISHABLE_KEY}"
: "${MAP_TILE_URL:?Set MAP_TILE_URL}"
: "${MAP_ATTRIBUTION:?Set MAP_ATTRIBUTION}"
command -v flutter >/dev/null || { echo 'Flutter SDK is required.' >&2; exit 1; }
command -v node >/dev/null || { echo 'Node.js 20.9+ is required.' >&2; exit 1; }
node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>20||(a===20&&b>=9)?0:1)' || { echo 'Node.js 20.9+ is required.' >&2; exit 1; }
if [[ ! -f "$ROOT/passenger_app/android/gradlew" || ! -f "$ROOT/driver_app/android/gradlew" ]]; then
  "$ROOT/scripts/bootstrap_android.sh"
fi
for app in passenger_app driver_app; do
  [[ -f "$ROOT/$app/android/key.properties" ]] || { echo "Missing $app/android/key.properties; configure upload signing first." >&2; exit 1; }
  (cd "$ROOT/$app" && flutter pub get && flutter analyze)
done
(cd "$ROOT/passenger_app" && flutter build appbundle --release \
  --dart-define="SUPABASE_URL=$SUPABASE_URL" \
  --dart-define="SUPABASE_PUBLISHABLE_KEY=$SUPABASE_PUBLISHABLE_KEY" \
  --dart-define="MAP_TILE_URL=$MAP_TILE_URL" \
  --dart-define="MAP_ATTRIBUTION=$MAP_ATTRIBUTION")
(cd "$ROOT/driver_app" && flutter build appbundle --release \
  --dart-define="SUPABASE_URL=$SUPABASE_URL" \
  --dart-define="SUPABASE_PUBLISHABLE_KEY=$SUPABASE_PUBLISHABLE_KEY")
(cd "$ROOT/admin_console" && npm install && npm run typecheck && npm run build)
echo "Release bundles created. Complete the device, backend, privacy and store checks in docs/production-integrations.md."
