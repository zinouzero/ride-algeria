$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
foreach ($name in @('SUPABASE_URL','SUPABASE_PUBLISHABLE_KEY','MAP_TILE_URL','MAP_ATTRIBUTION')) {
  if (-not [Environment]::GetEnvironmentVariable($name)) { throw "Set environment variable $name before building." }
}
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) { throw 'Flutter SDK is required.' }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js 20.9+ is required.' }
$nodeVersion = (node -p "process.versions.node").Split('.')
if ([int]$nodeVersion[0] -lt 20 -or ([int]$nodeVersion[0] -eq 20 -and [int]$nodeVersion[1] -lt 9)) { throw 'Node.js 20.9+ is required.' }

$apps = @(
  @{ Folder='passenger_app'; Project='passenger'; Package='com.mashwari.passenger'; Label='مشواري' },
  @{ Folder='driver_app'; Project='driver'; Package='com.mashwari.driver'; Label='مشواري للسائق' }
)
foreach ($app in $apps) {
  $path = Join-Path $Root $app.Folder
  if (-not (Test-Path (Join-Path $path 'android/gradlew'))) {
    if (Test-Path (Join-Path $path 'android')) { Remove-Item (Join-Path $path 'android') -Recurse -Force }
    Push-Location $path
    flutter create --platforms=android --org com.mashwari --project-name $app.Project --no-pub .
    Pop-Location
    python (Join-Path $PSScriptRoot 'configure_android.py') $path $app.Package $app.Label
  }
  if (-not (Test-Path (Join-Path $path 'android/key.properties'))) { throw "Create $($app.Folder)/android/key.properties and its upload keystore first." }
  Push-Location $path
  flutter pub get
  flutter analyze
  Pop-Location
}
Push-Location (Join-Path $Root 'passenger_app')
flutter build appbundle --release `
  --dart-define="SUPABASE_URL=$env:SUPABASE_URL" `
  --dart-define="SUPABASE_PUBLISHABLE_KEY=$env:SUPABASE_PUBLISHABLE_KEY" `
  --dart-define="MAP_TILE_URL=$env:MAP_TILE_URL" `
  --dart-define="MAP_ATTRIBUTION=$env:MAP_ATTRIBUTION"
Pop-Location
Push-Location (Join-Path $Root 'driver_app')
flutter build appbundle --release `
  --dart-define="SUPABASE_URL=$env:SUPABASE_URL" `
  --dart-define="SUPABASE_PUBLISHABLE_KEY=$env:SUPABASE_PUBLISHABLE_KEY"
Pop-Location
Push-Location (Join-Path $Root 'admin_console')
npm install
npm run typecheck
npm run build
Pop-Location
Write-Host 'Build completed. Run live integration and device checks before publishing.'
