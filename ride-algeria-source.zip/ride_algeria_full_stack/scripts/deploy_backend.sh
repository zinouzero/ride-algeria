#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${SUPABASE_PROJECT_REF:?Set SUPABASE_PROJECT_REF}"
command -v supabase >/dev/null || { echo 'Supabase CLI is required.' >&2; exit 1; }
cd "$ROOT"
supabase link --project-ref "$SUPABASE_PROJECT_REF"
supabase db push
for fn in create-quote create-support-ticket dispatch-trip dispatch-worker driver-active-trip driver-offer-details driver-response mark-cash-collected request-trip review-cash-collection review-driver-application search-places send-support-message submit-driver-application submit-rating transition-trip update-driver-location; do
  supabase functions deploy "$fn"
done
echo 'Backend migrations and functions deployed. Set all provider and worker secrets in Supabase before enabling traffic.'
