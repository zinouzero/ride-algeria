import { getAdmin, getUser, json, corsHeaders } from "../_shared/common.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const user = await getUser(req);
  if (!user) return json({ error: "unauthorized" }, 401);

  let body: { quote_id?: string; payment_method?: string };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  if (!body.quote_id || !/^[0-9a-f-]{36}$/i.test(body.quote_id)) return json({ error: "invalid_quote_id" }, 400);
  if ((body.payment_method ?? "cash") !== "cash") return json({ error: "payment_method_not_enabled" }, 400);

  const idempotencyKey = req.headers.get("Idempotency-Key") ?? "";
  if (idempotencyKey.length < 8 || idempotencyKey.length > 128) return json({ error: "idempotency_key_required" }, 400);

  const db = getAdmin();
  const { data, error } = await db.rpc("create_trip_from_quote", {
    p_actor_id: user.id,
    p_quote_id: body.quote_id,
    p_idempotency_key: idempotencyKey,
  });
  if (error) {
    const message = error.message ?? "";
    if (message.includes("quote_not_found_or_expired")) return json({ error: "quote_not_found_or_expired" }, 404);
    if (message.includes("passenger_account_required")) return json({ error: "passenger_account_required" }, 403);
    if (message.includes("invalid_idempotency_key")) return json({ error: "invalid_idempotency_key" }, 400);
    if (message.includes("duplicate key") || message.includes("unique constraint")) return json({ error: "quote_already_used" }, 409);
    return json({ error: "trip_creation_failed" }, 500);
  }
  // Start dispatch immediately after the transaction commits. Dispatch failure does not
  // roll back a valid ride request; the passenger can still see the persisted trip.
  let dispatch: unknown = null;
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const authorization = req.headers.get("Authorization");
  if (url && anon && authorization) {
    try {
      const response = await fetch(`${url}/functions/v1/dispatch-trip`, {
        method: "POST",
        headers: { "Authorization": authorization, "apikey": anon, "Content-Type": "application/json" },
        body: JSON.stringify({ trip_id: (data as any)?.trip?.id }),
      });
      dispatch = await response.json();
    } catch { dispatch = { error: "dispatch_start_failed" }; }
  }
  return json({ ...(data as Record<string, unknown>), dispatch }, 201);
});
