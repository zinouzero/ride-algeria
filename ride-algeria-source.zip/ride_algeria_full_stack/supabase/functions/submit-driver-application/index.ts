import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  const v = b?.vehicle ?? {};
  const docs = Array.isArray(b?.documents) ? b.documents : [];
  if (typeof v.make !== 'string' || typeof v.model !== 'string' || typeof v.color !== 'string' ||
      typeof v.plate_number !== 'string' || typeof v.category_code !== 'string' ||
      !Number.isInteger(v.passenger_capacity) || docs.length < 1 || docs.length > 12) return json({ error: 'invalid_application' }, 400);
  const paths = docs.map((d: any) => d?.storage_path);
  if (paths.some((p: any) => typeof p !== 'string' || !p.startsWith(`${user.id}/`))) return json({ error: 'invalid_document_path' }, 400);
  const db = getAdmin();
  const { data: stored, error: storageError } = await db.storage.from('driver-documents').list(user.id, { limit: 100 });
  const storedPaths = new Set((stored ?? []).map((f: any) => `${user.id}/${f.name}`));
  if (storageError || paths.some((p: string) => !storedPaths.has(p))) return json({ error: 'driver_documents_missing' }, 422);
  const { data, error } = await db.rpc('submit_driver_application', {
    p_actor_id: user.id, p_make: v.make, p_model: v.model, p_color: v.color,
    p_plate_number: v.plate_number, p_category_code: v.category_code,
    p_capacity: v.passenger_capacity, p_documents: docs,
  });
  if (error) {
    const m = error.message ?? '';
    if (m.includes('application_already_exists')) return json({ error: 'application_already_exists' }, 409);
    if (m.includes('invalid_vehicle_category')) return json({ error: 'invalid_vehicle_category' }, 422);
    return json({ error: 'application_submission_failed' }, 400);
  }
  return json({ application: data }, 201);
});
