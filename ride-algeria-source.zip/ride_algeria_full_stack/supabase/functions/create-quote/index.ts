import { getAdmin,getUser,json,corsHeaders,validCoord } from "../_shared/common.ts";

Deno.serve(async(req)=>{
  if(req.method==="OPTIONS") return new Response("ok",{headers:corsHeaders});
  if(req.method!=="POST") return json({error:"method_not_allowed"},405);
  const user=await getUser(req); if(!user) return json({error:"unauthorized"},401);
  let b:any; try{b=await req.json()}catch{return json({error:"invalid_json"},400)}
  const {pickup_label, pickup_lat,pickup_lng,dropoff_label,dropoff_lat,dropoff_lng,category_code}=b??{};
  if(typeof pickup_label!=="string" || pickup_label.trim().length<2 || pickup_label.length>240 ||
     typeof dropoff_label!=="string" || dropoff_label.trim().length<2 || dropoff_label.length>240 ||
     !validCoord(pickup_lat,pickup_lng) || !validCoord(dropoff_lat,dropoff_lng) ||
     typeof category_code!=="string" || category_code.length>40) return json({error:"invalid_input"},400);

  const db=getAdmin();
  const {data:profile}=await db.from("profiles").select("id,is_active,role").eq("id",user.id).maybeSingle();
  if(!profile || !profile.is_active || profile.role!=="passenger") return json({error:"passenger_account_required"},403);

  // Resolve pickup and dropoff coverage in PostGIS; zone polygons are validated on write.
  const {data:zoneResult,error:zoneErr}=await db.rpc("resolve_service_zone_for_points",{
    p_pickup_lng:pickup_lng,p_pickup_lat:pickup_lat,p_dropoff_lng:dropoff_lng,p_dropoff_lat:dropoff_lat,
  });
  if(zoneErr) return json({error:"zone_lookup_failed"},500);
  if(zoneResult?.error) return json({error:zoneResult.error},422);
  const zone={id:zoneResult?.zone_id};
  if(!zone.id) return json({error:"service_zone_not_found"},422);

  const {data:enabled}=await db.from("zone_categories").select("category_code")
    .eq("zone_id",zone.id).eq("category_code",category_code).eq("is_enabled",true).maybeSingle();
  if(!enabled) return json({error:"category_unavailable"},422);
  const {data:rule}=await db.from("fare_rules").select("*").eq("zone_id",zone.id)
    .eq("category_code",category_code).eq("is_active",true)
    .lte("effective_from",new Date().toISOString())
    .or(`effective_until.is.null,effective_until.gt.${new Date().toISOString()}`)
    .order("version",{ascending:false}).limit(1).maybeSingle();
  if(!rule) return json({error:"fare_not_configured"},422);

  // Production quotes must come from a configured, licensed routing adapter.
  // The adapter contract is documented in replica/production-integrations.md.
  const routingUrl=Deno.env.get("ROUTING_ADAPTER_URL");
  const routingKey=Deno.env.get("ROUTING_ADAPTER_KEY");
  if(!routingUrl || !routingKey) return json({error:"routing_not_configured"},503);
  let route:any;
  try {
    const routeResponse=await fetch(routingUrl,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${routingKey}`},
      body:JSON.stringify({origin:{latitude:pickup_lat,longitude:pickup_lng},destination:{latitude:dropoff_lat,longitude:dropoff_lng},profile:"car"})});
    if(!routeResponse.ok) return json({error:"routing_provider_unavailable"},502);
    route=await routeResponse.json();
  } catch { return json({error:"routing_provider_unavailable"},502); }
  const distance=route?.distance_m, duration=route?.duration_s;
  if(!Number.isSafeInteger(distance) || distance<1 || distance>500000 ||
     !Number.isSafeInteger(duration) || duration<1 || duration>21600) return json({error:"invalid_route_response"},502);
  const km=Math.ceil(distance/1000);
  const mins=Math.ceil(duration/60);
  const base=Number(rule.base_fare_minor), perKm=Number(rule.per_km_minor), perMinute=Number(rule.per_minute_minor), minimum=Number(rule.minimum_fare_minor);
  if(![base,perKm,perMinute,minimum].every(Number.isSafeInteger)) return json({error:"fare_configuration_invalid"},500);
  const calculated=base+km*perKm+mins*perMinute;
  const fare=Math.max(minimum,calculated);
  if(!Number.isSafeInteger(fare) || fare<0) return json({error:"fare_calculation_overflow"},500);
  const expires=new Date(Date.now()+5*60*1000).toISOString();

  const {data:quote,error}=await db.from("ride_quotes").insert({
    passenger_id:user.id,zone_id:zone.id,category_code,
    pickup_label:pickup_label.trim(),pickup_lat,pickup_lng,
    dropoff_label:dropoff_label.trim(),dropoff_lat,dropoff_lng,
    route_distance_m:distance,route_duration_s:duration,
    fare_minor:fare,currency:rule.currency,fare_rule_version:rule.version,quote_expires_at:expires
  }).select("id,pickup_label,dropoff_label,route_distance_m,route_duration_s,fare_minor,currency,quote_expires_at").single();
  if(error) return json({error:"quote_create_failed"},500);
  return json({quote,estimate_type:"licensed_route_provider"},201);
});

