import {getAdmin,getUser,json,corsHeaders} from "../_shared/common.ts";
const allowed=new Set(["driver_arriving","driver_arrived","in_progress","completed","driver_cancelled","passenger_cancelled"]);
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 if(req.method!=="POST")return json({error:"method_not_allowed"},405);
 const user=await getUser(req);if(!user)return json({error:"unauthorized"},401);
 let b:any;try{b=await req.json()}catch{return json({error:"invalid_json"},400)}
 if(typeof b?.trip_id!=="string" || !allowed.has(b?.next_status))return json({error:"invalid_input"},400);
 const db=getAdmin();
 const {data,error}=await db.rpc("transition_trip",{p_trip_id:b.trip_id,p_actor_id:user.id,p_next_status:b.next_status,p_reason:typeof b.reason==="string"?b.reason.slice(0,300):null});
 if(error)return json({error:"transition_rejected"},409);
 return json({trip:data});
});
