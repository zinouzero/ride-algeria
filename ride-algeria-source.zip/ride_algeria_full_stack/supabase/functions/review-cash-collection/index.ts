import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof b?.trip_id !== 'string' || !['flag','confirm'].includes(b?.decision)) return json({ error: 'invalid_review' }, 400);
  const db = getAdmin();
  const { data: profile } = await db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle();
  if (!profile?.is_active || profile.role !== 'admin') return json({ error: 'admin_required' }, 403);
  const { data, error } = await db.rpc('review_cash_collection', {
    p_admin_id: user.id, p_trip_id: b.trip_id, p_decision: b.decision,
    p_note: typeof b.note === 'string' ? b.note.slice(0,500) : null,
  });
  if (error) return json({ error: 'cash_review_rejected' }, 409);
  return json({ collection: data });
});
