import { getAdmin, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const expected = Deno.env.get('DISPATCH_WORKER_SECRET');
  const supplied = req.headers.get('x-worker-secret');
  if (!expected || !supplied || supplied !== expected) return json({ error: 'unauthorized' }, 401);
  const db = getAdmin();
  const cutoff = new Date(Date.now() - 25_000).toISOString();
  const { data: trips, error } = await db.from('trips').select('id')
    .eq('status','searching').lt('dispatch_attempts',5)
    .or(`last_dispatch_at.is.null,last_dispatch_at.lte.${cutoff}`)
    .order('created_at',{ascending:true}).limit(50);
  if (error) return json({ error: 'dispatch_queue_lookup_failed' }, 500);
  const results = await Promise.all((trips ?? []).map(async (trip: any) => {
    const { data, error: rpcError } = await db.rpc('process_dispatch_attempt', { p_trip_id: trip.id });
    return { trip_id: trip.id, result: rpcError ? { error: 'dispatch_attempt_failed' } : data };
  }));
  return json({ processed: results.length, results });
});
