import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  const db = getAdmin();
  const { data: profile } = await db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle();
  if (!profile?.is_active || profile.role !== 'driver') return json({ error: 'driver_account_required' }, 403);
  const { data, error } = await db.rpc('get_driver_active_trip', { p_driver_id: user.id });
  if (error) return json({ error: 'active_trip_lookup_failed' }, 500);
  return json({ active_trip: data });
});
