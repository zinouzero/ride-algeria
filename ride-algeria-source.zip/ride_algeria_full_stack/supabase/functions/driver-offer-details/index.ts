import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req);
  if (!user) return json({ error: 'unauthorized' }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof body?.offer_id !== 'string') return json({ error: 'offer_id_required' }, 400);
  const db = getAdmin();
  const { data: driver } = await db.from('driver_profiles').select('status').eq('user_id', user.id).maybeSingle();
  if (!driver || driver.status !== 'approved') return json({ error: 'approved_driver_required' }, 403);
  const { data: offer } = await db.from('driver_offers').select('id,trip_id,status,expires_at')
    .eq('id', body.offer_id).eq('driver_id', user.id).maybeSingle();
  if (!offer || offer.status !== 'offered' || new Date(offer.expires_at).getTime() <= Date.now()) return json({ error: 'offer_not_available' }, 404);
  const { data: trip } = await db.from('trips').select('id,status,pickup_label,pickup_lat,pickup_lng,dropoff_label,dropoff_lat,dropoff_lng,quoted_fare_minor,currency,category_code')
    .eq('id', offer.trip_id).maybeSingle();
  if (!trip || !['searching','requested'].includes(trip.status)) return json({ error: 'trip_not_available' }, 409);
  return json({ offer: { id: offer.id, expires_at: offer.expires_at }, trip });
});
