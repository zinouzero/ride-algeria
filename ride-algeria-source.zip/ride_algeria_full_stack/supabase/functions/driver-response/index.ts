import {getAdmin,getUser,json,corsHeaders} from "../_shared/common.ts";
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 if(req.method!=="POST")return json({error:"method_not_allowed"},405);
 const user=await getUser(req);if(!user)return json({error:"unauthorized"},401);
 let b:any;try{b=await req.json()}catch{return json({error:"invalid_json"},400)}
 if(typeof b?.offer_id!=="string" || !["accept","reject"].includes(b.action))return json({error:"invalid_input"},400);
 const db=getAdmin();
 const {data:driver}=await db.from("driver_profiles").select("status").eq("user_id",user.id).maybeSingle();
 if(!driver || driver.status!=="approved")return json({error:"approved_driver_required"},403);
 const {data:offer}=await db.from("driver_offers").select("id,trip_id,driver_id,status,expires_at")
  .eq("id",b.offer_id).eq("driver_id",user.id).eq("status","offered").gt("expires_at",new Date().toISOString()).maybeSingle();
 if(!offer)return json({error:"offer_not_available"},404);
 if(b.action==="reject"){
   const {data:rejected,error}=await db.from("driver_offers").update({status:"rejected",responded_at:new Date().toISOString()})
    .eq("id",offer.id).eq("status","offered").select("id").maybeSingle();
   if(error)return json({error:"reject_failed"},500);
   if(!rejected)return json({error:"offer_not_available"},409);
   return json({offer_id:offer.id,status:"rejected"});
 }
 // Atomic claim is delegated to a DB function to avoid two drivers accepting at once.
 const {data,error}=await db.rpc("accept_driver_offer",{p_offer_id:offer.id,p_driver_id:user.id});
 if(error)return json({error:"accept_conflict_or_server_error"},409);
 return json({result:data},200);
});
