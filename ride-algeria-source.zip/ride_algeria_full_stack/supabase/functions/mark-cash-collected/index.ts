import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof body?.trip_id !== 'string') return json({ error: 'trip_id_required' }, 400);
  const db = getAdmin();
  const { data: profile } = await db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle();
  if (!profile || profile.role !== 'driver' || !profile.is_active) return json({ error: 'driver_account_required' }, 403);
  const { data, error } = await db.rpc('mark_cash_collected', { p_driver_id: user.id, p_trip_id: body.trip_id });
  if (error) return json({ error: 'cash_collection_rejected' }, 409);
  return json({ collection: data });
});
