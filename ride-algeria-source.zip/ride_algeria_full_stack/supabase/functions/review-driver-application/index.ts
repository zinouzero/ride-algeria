import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof b?.driver_id !== 'string' || !['approved','rejected'].includes(b?.decision)) return json({ error: 'invalid_review' }, 400);
  const reason = typeof b.reason === 'string' ? b.reason.trim().slice(0, 500) : null;
  if (b.decision === 'rejected' && !reason) return json({ error: 'rejection_reason_required' }, 400);
  const db = getAdmin();
  const { data: actor } = await db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle();
  if (!actor || actor.role !== 'admin' || !actor.is_active) return json({ error: 'admin_required' }, 403);
  const { data, error } = await db.rpc('review_driver_application', {
    p_admin_id: user.id, p_driver_id: b.driver_id, p_decision: b.decision, p_reason: reason,
  });
  if (error) {
    if ((error.message ?? '').includes('pending_application_not_found')) return json({ error: 'pending_application_not_found' }, 404);
    return json({ error: 'review_update_failed' }, 400);
  }
  return json(data);
});
