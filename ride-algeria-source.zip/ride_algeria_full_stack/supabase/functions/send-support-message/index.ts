import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  const message = typeof b?.message === 'string' ? b.message.trim() : '';
  if (typeof b?.ticket_id !== 'string' || message.length < 1 || message.length > 3000) return json({ error: 'invalid_message' }, 400);
  const db = getAdmin();
  const [{ data: ticket }, { data: profile }] = await Promise.all([
    db.from('support_tickets').select('id,requester_id,status,assigned_to').eq('id', b.ticket_id).maybeSingle(),
    db.from('profiles').select('role,is_active').eq('id', user.id).maybeSingle(),
  ]);
  if (!ticket || !profile?.is_active) return json({ error: 'ticket_not_found' }, 404);
  const staff = ['admin','support'].includes(profile.role);
  if (!staff && ticket.requester_id !== user.id) return json({ error: 'not_ticket_participant' }, 403);
  if (!staff && ['resolved','closed'].includes(ticket.status)) return json({ error: 'ticket_closed' }, 409);
  const { data, error } = await db.from('support_messages').insert({ ticket_id: ticket.id, sender_id: user.id, message }).select('id,created_at').single();
  if (error) return json({ error: 'message_send_failed' }, 500);
  await db.from('support_tickets').update({ status: staff ? 'pending' : 'open', updated_at: new Date().toISOString() }).eq('id', ticket.id);
  return json({ message: data }, 201);
});
