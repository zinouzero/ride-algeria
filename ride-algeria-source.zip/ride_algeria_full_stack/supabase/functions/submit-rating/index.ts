import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof body?.trip_id !== 'string' || !Number.isInteger(body?.stars) || body.stars < 1 || body.stars > 5 ||
      (body.comment != null && typeof body.comment !== 'string')) return json({ error: 'invalid_rating' }, 400);
  const db = getAdmin();
  const { data, error } = await db.rpc('submit_trip_rating', {
    p_passenger_id: user.id, p_trip_id: body.trip_id, p_stars: body.stars,
    p_comment: typeof body.comment === 'string' ? body.comment.slice(0,500) : null,
  });
  if (error) return json({ error: 'rating_rejected' }, 409);
  return json({ rating: data }, 201);
});
