import { createClient } from "https://esm.sh/@supabase/supabase-js@2.119.0";

export const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, idempotency-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
export function getAdmin() {
  const url=Deno.env.get("SUPABASE_URL"), key=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if(!url || !key) throw new Error("server_not_configured");
  return createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
}
export async function getUser(req: Request) {
  const url=Deno.env.get("SUPABASE_URL"), anon=Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  const auth=req.headers.get("Authorization") ?? "";
  if(!url || !anon || !auth.startsWith("Bearer ")) return null;
  const client=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data,error}=await client.auth.getUser();
  return error || !data.user ? null : data.user;
}
export function validCoord(lat: unknown,lng: unknown) {
  return typeof lat==="number" && typeof lng==="number" &&
    Number.isFinite(lat) && Number.isFinite(lng) &&
    lat>=-90 && lat<=90 && lng>=-180 && lng<=180;
}
export function haversineMeters(aLat:number,aLng:number,bLat:number,bLng:number) {
  const rad=(x:number)=>x*Math.PI/180, R=6371000;
  const dLat=rad(bLat-aLat), dLng=rad(bLng-aLng);
  const x=Math.sin(dLat/2)**2 + Math.cos(rad(aLat))*Math.cos(rad(bLat))*Math.sin(dLng/2)**2;
  return 2*R*Math.atan2(Math.sqrt(x),Math.sqrt(1-x));
}
