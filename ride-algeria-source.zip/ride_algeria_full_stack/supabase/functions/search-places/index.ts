import { getUser, json, corsHeaders, validCoord } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  if (!await getUser(req)) return json({ error: 'unauthorized' }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  const query = typeof body?.query === 'string' ? body.query.trim() : '';
  if (query.length < 2 || query.length > 120) return json({ error: 'invalid_query' }, 400);
  const endpoint = Deno.env.get('GEOCODING_ADAPTER_URL');
  const key = Deno.env.get('GEOCODING_ADAPTER_KEY');
  if (!endpoint || !key) return json({ error: 'geocoding_not_configured' }, 503);
  try {
    const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
      body: JSON.stringify({ query, language: ['ar','fr'], country_code: 'dz', limit: 8 }) });
    if (!response.ok) return json({ error: 'geocoding_provider_unavailable' }, 502);
    const payload = await response.json();
    const results = Array.isArray(payload?.results) ? payload.results : [];
    const places = results.slice(0,8).filter((p: any) => typeof p?.label === 'string' && p.label.length <= 240 && validCoord(p?.latitude,p?.longitude))
      .map((p: any) => ({ label: p.label, latitude: p.latitude, longitude: p.longitude, provider_place_id: typeof p.provider_place_id === 'string' ? p.provider_place_id.slice(0,200) : null }));
    return json({ places });
  } catch { return json({ error: 'geocoding_provider_unavailable' }, 502); }
});
