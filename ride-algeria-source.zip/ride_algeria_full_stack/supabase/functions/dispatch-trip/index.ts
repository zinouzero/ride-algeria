import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let body: any; try { body = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  if (typeof body?.trip_id !== 'string') return json({ error: 'trip_id_required' }, 400);
  const db = getAdmin();
  const { data: trip } = await db.from('trips').select('id,passenger_id,status').eq('id', body.trip_id).eq('passenger_id', user.id).maybeSingle();
  if (!trip) return json({ error: 'trip_not_found' }, 404);
  if (!['searching','requested'].includes(trip.status)) return json({ error: 'trip_not_dispatchable' }, 409);
  const { data, error } = await db.rpc('process_dispatch_attempt', { p_trip_id: trip.id });
  if (error) return json({ error: 'dispatch_failed' }, 500);
  return json({ trip_id: trip.id, dispatch: data }, 202);
});
