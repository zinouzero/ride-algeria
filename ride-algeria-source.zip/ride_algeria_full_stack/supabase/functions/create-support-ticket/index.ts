import { getAdmin, getUser, json, corsHeaders } from '../_shared/common.ts';
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
  const user = await getUser(req); if (!user) return json({ error: 'unauthorized' }, 401);
  let b: any; try { b = await req.json(); } catch { return json({ error: 'invalid_json' }, 400); }
  const category = typeof b?.category === 'string' ? b.category.trim() : '';
  const description = typeof b?.description === 'string' ? b.description.trim() : '';
  if (!['trip','payment','driver','safety','account','other'].includes(category) || description.length < 8 || description.length > 3000) return json({ error: 'invalid_ticket' }, 400);
  const db = getAdmin();
  const { data: profile } = await db.from('profiles').select('is_active').eq('id', user.id).maybeSingle();
  if (!profile?.is_active) return json({ error: 'active_account_required' }, 403);
  if (b.trip_id != null) {
    const { data: trip } = await db.from('trips').select('id').eq('id', b.trip_id)
      .or(`passenger_id.eq.${user.id},driver_id.eq.${user.id}`).maybeSingle();
    if (!trip) return json({ error: 'trip_not_found' }, 404);
  }
  const { data, error } = await db.from('support_tickets').insert({
    requester_id: user.id, trip_id: b.trip_id ?? null, category, description, status: 'open',
  }).select('id,status,created_at').single();
  if (error) return json({ error: 'ticket_create_failed' }, 500);
  return json({ ticket: data }, 201);
});
