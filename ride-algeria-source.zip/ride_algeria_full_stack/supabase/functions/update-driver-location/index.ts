import {getAdmin,getUser,json,corsHeaders,validCoord} from "../_shared/common.ts";
Deno.serve(async(req)=>{
 if(req.method==="OPTIONS")return new Response("ok",{headers:corsHeaders});
 if(req.method!=="POST")return json({error:"method_not_allowed"},405);
 const user=await getUser(req);if(!user)return json({error:"unauthorized"},401);
 let b:any;try{b=await req.json()}catch{return json({error:"invalid_json"},400)}
 const online=b?.online!==false;
 if(online && (!validCoord(b?.latitude,b?.longitude) || typeof b?.accuracy_m!=="number" || b.accuracy_m<0 || b.accuracy_m>10000))
  return json({error:"invalid_location"},400);
 const db=getAdmin();
 const {data:driver}=await db.from("driver_profiles").select("status").eq("user_id",user.id).maybeSingle();
 if(!driver || driver.status!=="approved")return json({error:"approved_driver_required"},403);
 const now=new Date().toISOString();
 const {error}=await db.from("driver_presence").upsert({
  driver_id:user.id,is_online:online,is_available:online && b.available===true,
  latitude:validCoord(b?.latitude,b?.longitude)?b.latitude:null,
  longitude:validCoord(b?.latitude,b?.longitude)?b.longitude:null,
  accuracy_m:typeof b.accuracy_m==="number"?b.accuracy_m:null,
  heading:typeof b.heading==="number"?b.heading:null,
  last_location_at:online?now:null,updated_at:now
 });
 if(error)return json({error:"location_update_failed"},500);
 return json({ok:true,recorded_at:now});
});
