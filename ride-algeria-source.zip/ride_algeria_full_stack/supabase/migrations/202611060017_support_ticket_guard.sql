create or replace function public.audit_configuration_change()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_before jsonb; v_after jsonb; v_id text; v_actor uuid;
begin
  v_actor:=auth.uid();
  if tg_op='INSERT' then v_after:=to_jsonb(new);
  elsif tg_op='UPDATE' then v_before:=to_jsonb(old); v_after:=to_jsonb(new);
  else v_before:=to_jsonb(old); end if;
  if tg_table_name='ride_categories' then v_id:=coalesce(v_after->>'code',v_before->>'code');
  elsif tg_table_name='zone_categories' then v_id:=coalesce(v_after->>'zone_id',v_before->>'zone_id')||':'||coalesce(v_after->>'category_code',v_before->>'category_code');
  else v_id:=coalesce(v_after->>'id',v_before->>'id'); end if;
  insert into public.admin_audit_log(admin_id,action,target_type,target_id,before_data,after_data)
  values(v_actor,lower(tg_op),tg_table_name,v_id,v_before,v_after);
  if tg_op='DELETE' then return old; else return new; end if;
end;
$$;

-- Support agents can operate ticket workflow but cannot rewrite the customer's original report.
create or replace function public.guard_support_ticket_content()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_role public.account_role;
begin
  if auth.uid() is not null then
    select role into v_role from public.profiles where id=auth.uid() and is_active=true;
    if v_role is null or v_role not in ('admin','support') then raise exception 'staff_required'; end if;
    if v_role='support' and (
      new.requester_id is distinct from old.requester_id or
      new.trip_id is distinct from old.trip_id or
      new.category is distinct from old.category or
      new.description is distinct from old.description or
      new.created_at is distinct from old.created_at
    ) then raise exception 'support_ticket_content_is_immutable'; end if;
  end if;
  if new.assigned_to is not null and not exists(
    select 1 from public.profiles p where p.id=new.assigned_to and p.is_active=true and p.role in ('admin','support')
  ) then raise exception 'invalid_support_assignee'; end if;
  return new;
end;
$$;
drop trigger if exists support_ticket_content_guard on public.support_tickets;
create trigger support_ticket_content_guard before update on public.support_tickets
for each row execute function public.guard_support_ticket_content();
drop trigger if exists audit_support_ticket_changes on public.support_tickets;
create trigger audit_support_ticket_changes after update on public.support_tickets
for each row execute function public.audit_configuration_change();
