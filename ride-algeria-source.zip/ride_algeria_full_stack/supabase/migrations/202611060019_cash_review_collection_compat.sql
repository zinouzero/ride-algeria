-- A driver may declare receipt while an admin has already flagged the row for review.
create or replace function public.mark_cash_collected(p_driver_id uuid,p_trip_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip public.trips%rowtype; v_cash public.cash_collections%rowtype;
begin
  select * into v_trip from public.trips where id=p_trip_id for update;
  if not found then raise exception 'trip_not_found'; end if;
  if v_trip.driver_id is distinct from p_driver_id then raise exception 'not_assigned_driver'; end if;
  if v_trip.status<>'completed' then raise exception 'trip_not_completed'; end if;
  select * into v_cash from public.cash_collections where trip_id=p_trip_id for update;
  if not found then raise exception 'cash_collection_not_initialized'; end if;
  if v_cash.declared_collected_at is not null then
    return jsonb_build_object('trip_id',p_trip_id,'status',v_cash.status,'amount_minor',v_cash.amount_minor,'currency',v_cash.currency);
  end if;
  if v_cash.status not in ('due','under_review') then raise exception 'cash_collection_not_collectible'; end if;
  update public.cash_collections set
    status=case when status='under_review' then 'under_review'::public.payment_status else 'collected'::public.payment_status end,
    declared_collected_at=now(),updated_at=now()
   where trip_id=p_trip_id returning * into v_cash;
  insert into public.payment_ledger(trip_id,entry_type,amount_minor,currency,created_by)
  values(p_trip_id,'cash_collected',v_cash.amount_minor,v_cash.currency,p_driver_id);
  return jsonb_build_object('trip_id',p_trip_id,'status',v_cash.status,'amount_minor',v_cash.amount_minor,'currency',v_cash.currency);
end;
$$;
revoke all on function public.mark_cash_collected(uuid,uuid) from public,anon,authenticated;
grant execute on function public.mark_cash_collected(uuid,uuid) to service_role;
