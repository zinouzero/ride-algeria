-- Operational constraints and helper indexes.
-- Expired/rejected/cancelled drivers may be offered again; only active offers are unique.
alter table public.driver_offers drop constraint if exists driver_offers_trip_id_driver_id_key;
drop index if exists public.driver_offer_trip_driver_unique;
create unique index if not exists driver_offer_active_trip_driver_unique
on public.driver_offers(trip_id,driver_id) where status in ('offered','accepted');
create index if not exists driver_offers_expiry_idx on public.driver_offers(status,expires_at);
create index if not exists driver_locations_trip_time_idx on public.driver_locations(trip_id,recorded_at desc);

drop policy if exists "offers driver self read" on public.driver_offers;
create policy "offers driver self read" on public.driver_offers
for select to authenticated using (driver_id=auth.uid());
drop policy if exists "trips passenger or assigned driver read" on public.trips;
drop policy if exists "trips participant read" on public.trips;
create policy "trips participant read" on public.trips
for select to authenticated using (passenger_id=auth.uid() or driver_id=auth.uid());
