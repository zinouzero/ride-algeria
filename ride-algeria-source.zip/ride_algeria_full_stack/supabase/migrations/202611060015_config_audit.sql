-- Record operator changes to zones, categories, zone mappings and fare rules.
create or replace function public.audit_configuration_change()
returns trigger language plpgsql security definer set search_path=public
as $$
declare v_before jsonb; v_after jsonb; v_id text; v_actor uuid;
begin
  v_actor:=auth.uid();
  if tg_op='INSERT' then v_after:=to_jsonb(new);
  elsif tg_op='UPDATE' then v_before:=to_jsonb(old); v_after:=to_jsonb(new);
  else v_before:=to_jsonb(old); end if;
  if tg_table_name='ride_categories' then v_id:=coalesce(v_after->>'code',v_before->>'code');
  elsif tg_table_name='zone_categories' then v_id:=coalesce(v_after->>'zone_id',v_before->>'zone_id')||':'||coalesce(v_after->>'category_code',v_before->>'category_code');
  else v_id:=coalesce(v_after->>'id',v_before->>'id'); end if;
  insert into public.admin_audit_log(admin_id,action,target_type,target_id,before_data,after_data)
  values(v_actor,lower(tg_op),tg_table_name,v_id,v_before,v_after);
  if tg_op='DELETE' then return old; else return new; end if;
end;
$$;

revoke all on function public.audit_configuration_change() from public,anon,authenticated;

drop trigger if exists audit_service_zones on public.service_zones;
create trigger audit_service_zones after insert or update or delete on public.service_zones
for each row execute function public.audit_configuration_change();
drop trigger if exists audit_ride_categories on public.ride_categories;
create trigger audit_ride_categories after insert or update or delete on public.ride_categories
for each row execute function public.audit_configuration_change();
drop trigger if exists audit_zone_categories on public.zone_categories;
create trigger audit_zone_categories after insert or update or delete on public.zone_categories
for each row execute function public.audit_configuration_change();
drop trigger if exists audit_fare_rules on public.fare_rules;
create trigger audit_fare_rules after insert or update or delete on public.fare_rules
for each row execute function public.audit_configuration_change();
