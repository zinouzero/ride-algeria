-- Ratings are validated server-side against a completed trip owned by the passenger.
drop policy if exists "ratings passenger insert" on public.ratings;
create or replace function public.submit_trip_rating(
  p_passenger_id uuid,p_trip_id uuid,p_stars smallint,p_comment text default null
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip public.trips%rowtype; v_driver public.driver_profiles%rowtype; v_rating public.ratings%rowtype;
begin
  if p_stars not between 1 and 5 then raise exception 'invalid_rating'; end if;
  select * into v_trip from public.trips where id=p_trip_id for update;
  if not found or v_trip.passenger_id<>p_passenger_id then raise exception 'trip_not_found'; end if;
  if v_trip.status<>'completed' or v_trip.driver_id is null then raise exception 'trip_not_completed'; end if;
  insert into public.ratings(trip_id,passenger_id,driver_id,stars,comment)
  values(p_trip_id,p_passenger_id,v_trip.driver_id,p_stars,left(trim(p_comment),500)) returning * into v_rating;
  select * into v_driver from public.driver_profiles where user_id=v_trip.driver_id for update;
  update public.driver_profiles set
    rating_avg=round(((rating_avg*rating_count)+p_stars)/(rating_count+1),2),
    rating_count=rating_count+1,updated_at=now()
  where user_id=v_trip.driver_id;
  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
  values(p_trip_id,p_passenger_id,'passenger_rated','completed','completed',jsonb_build_object('stars',p_stars));
  return jsonb_build_object('rating_id',v_rating.id,'stars',v_rating.stars);
end;
$$;
revoke all on function public.submit_trip_rating(uuid,uuid,smallint,text) from public,anon,authenticated;
grant execute on function public.submit_trip_rating(uuid,uuid,smallint,text) to service_role;
