-- Atomic trip creation + idempotency. This closes the duplicate-trip race in the
-- earlier Edge Function implementation. All writes commit or roll back together.
create or replace function public.create_trip_from_quote(
  p_actor_id uuid,
  p_quote_id uuid,
  p_idempotency_key text
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_quote public.ride_quotes%rowtype;
  v_profile public.profiles%rowtype;
  v_trip public.trips%rowtype;
  v_response jsonb;
begin
  if p_idempotency_key is null or length(p_idempotency_key) < 8 or length(p_idempotency_key) > 128 then
    raise exception 'invalid_idempotency_key';
  end if;

  select * into v_profile from public.profiles
   where id=p_actor_id and role='passenger' and is_active=true;
  if not found then raise exception 'passenger_account_required'; end if;

  insert into public.idempotency_keys(actor_id,operation,idempotency_key,response_body)
  values(p_actor_id,'request_trip',p_idempotency_key,null)
  on conflict(actor_id,operation,idempotency_key) do nothing;

  select response_body into v_response from public.idempotency_keys
   where actor_id=p_actor_id and operation='request_trip' and idempotency_key=p_idempotency_key
   for update;
  if v_response is not null then return v_response; end if;

  select * into v_quote from public.ride_quotes
   where id=p_quote_id and passenger_id=p_actor_id and quote_expires_at>now()
   for update;
  if not found then raise exception 'quote_not_found_or_expired'; end if;

  insert into public.trips(
    passenger_id,quote_id,zone_id,category_code,status,
    pickup_label,pickup_lat,pickup_lng,dropoff_label,dropoff_lat,dropoff_lng,
    quoted_fare_minor,currency,payment_method
  ) values (
    p_actor_id,v_quote.id,v_quote.zone_id,v_quote.category_code,'searching',
    v_quote.pickup_label,v_quote.pickup_lat,v_quote.pickup_lng,
    v_quote.dropoff_label,v_quote.dropoff_lat,v_quote.dropoff_lng,
    v_quote.fare_minor,v_quote.currency,'cash'
  ) returning * into v_trip;

  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
  values(v_trip.id,p_actor_id,'trip_requested',null,'searching',jsonb_build_object('payment_method','cash'));

  v_response := jsonb_build_object('trip',jsonb_build_object(
    'id',v_trip.id,'status',v_trip.status,'quoted_fare_minor',v_trip.quoted_fare_minor,
    'currency',v_trip.currency,'created_at',v_trip.created_at
  ));
  update public.idempotency_keys set response_body=v_response
   where actor_id=p_actor_id and operation='request_trip' and idempotency_key=p_idempotency_key;
  return v_response;
end;
$$;
revoke all on function public.create_trip_from_quote(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.create_trip_from_quote(uuid,uuid,text) to service_role;
