-- Passengers may cancel while dispatch is still searching as well as after assignment.
create or replace function public.transition_trip(
  p_trip_id uuid,p_actor_id uuid,p_next_status public.trip_status,p_reason text default null
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip public.trips%rowtype; v_previous_status public.trip_status; v_is_passenger boolean; v_is_driver boolean; v_allowed boolean:=false;
begin
  select * into v_trip from public.trips where id=p_trip_id for update;
  if not found then raise exception 'trip_not_found'; end if;
  v_previous_status := v_trip.status;
  v_is_passenger := p_actor_id=v_trip.passenger_id;
  v_is_driver := v_trip.driver_id is not null and p_actor_id=v_trip.driver_id;
  if not (v_is_passenger or v_is_driver) then raise exception 'not_trip_participant'; end if;

  if p_next_status='passenger_cancelled' then
    v_allowed := v_is_passenger and v_trip.status in ('requested','searching','assigned','driver_arriving','driver_arrived');
  elsif p_next_status='driver_cancelled' then
    v_allowed := v_is_driver and v_trip.status in ('assigned','driver_arriving','driver_arrived');
  elsif p_next_status in ('driver_arriving','driver_arrived','in_progress','completed') then
    v_allowed := v_is_driver and (
      (v_trip.status='assigned' and p_next_status='driver_arriving') or
      (v_trip.status='driver_arriving' and p_next_status='driver_arrived') or
      (v_trip.status='driver_arrived' and p_next_status='in_progress') or
      (v_trip.status='in_progress' and p_next_status='completed')
    );
  end if;
  if not v_allowed then raise exception 'invalid_trip_transition'; end if;

  update public.trips set status=p_next_status,updated_at=now(),
    arrived_at=case when p_next_status='driver_arrived' then now() else arrived_at end,
    started_at=case when p_next_status='in_progress' then now() else started_at end,
    completed_at=case when p_next_status='completed' then now() else completed_at end,
    cancelled_at=case when p_next_status in ('driver_cancelled','passenger_cancelled') then now() else cancelled_at end,
    cancellation_reason=case when p_next_status in ('driver_cancelled','passenger_cancelled') then left(p_reason,300) else cancellation_reason end
  where id=p_trip_id returning * into v_trip;

  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
  values(p_trip_id,p_actor_id,p_next_status::text,v_previous_status,p_next_status,jsonb_build_object('reason',left(p_reason,300)));

  if p_next_status='completed' then
    insert into public.cash_collections(trip_id,driver_id,amount_minor,currency,status)
    values(v_trip.id,v_trip.driver_id,coalesce(v_trip.final_fare_minor,v_trip.quoted_fare_minor),v_trip.currency,'due')
    on conflict (trip_id) do nothing;
    insert into public.payment_ledger(trip_id,entry_type,amount_minor,currency,created_by)
    values(v_trip.id,'fare_due',coalesce(v_trip.final_fare_minor,v_trip.quoted_fare_minor),v_trip.currency,p_actor_id);
  end if;
  if p_next_status in ('driver_cancelled','passenger_cancelled') and v_trip.driver_id is not null then
    update public.driver_presence set is_available=true,updated_at=now() where driver_id=v_trip.driver_id;
    update public.driver_offers set status='cancelled',responded_at=now()
      where trip_id=v_trip.id and status='offered';
  end if;
  return jsonb_build_object('trip_id',v_trip.id,'status',p_next_status);
end;
$$;
revoke all on function public.transition_trip(uuid,uuid,public.trip_status,text) from public,anon,authenticated;
grant execute on function public.transition_trip(uuid,uuid,public.trip_status,text) to service_role;
