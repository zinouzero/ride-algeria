-- Security hardening for initial schema draft.
-- Apply after 202611060001_initial_schema.sql in a disposable dev project first.

-- Prevent a user from escalating role or changing identity/security-controlled fields
-- through the broad self-update profile policy.
create or replace function public.prevent_profile_privilege_changes()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if auth.uid() is not null and (
    new.role is distinct from old.role or
    new.is_active is distinct from old.is_active or
    new.phone_e164 is distinct from old.phone_e164
  ) then
    raise exception 'Protected profile fields cannot be changed by the account owner';
  end if;
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists profiles_protect_privileged_fields on public.profiles;
create trigger profiles_protect_privileged_fields
before update on public.profiles
for each row execute function public.prevent_profile_privilege_changes();

-- Replace unrestricted self-update policy with explicit ownership check.
drop policy if exists "profile update self" on public.profiles;
create policy "profile update self" on public.profiles
for update using (id = auth.uid())
with check (id = auth.uid());

-- Authenticated users can read only active public service configuration.
create policy "active zones readable" on public.service_zones
for select to authenticated using (is_active = true);
create policy "active categories readable" on public.ride_categories
for select to authenticated using (is_active = true);
create policy "enabled zone categories readable" on public.zone_categories
for select to authenticated using (
  is_enabled = true and exists (
    select 1 from public.service_zones z where z.id = zone_id and z.is_active = true
  )
);
create policy "active fare rules readable" on public.fare_rules
for select to authenticated using (
  is_active = true and effective_from <= now()
  and (effective_until is null or effective_until > now())
);

-- Device tokens can only be inserted/removed by their owner; no update policy.
-- Driver documents, precise locations, offers, financial ledger and audit remain
-- server-only by default (RLS enabled and no client policies).
-- Do not expose service_role to Flutter or browser code.

-- Basic indexes for frequent operational filters.
create index if not exists trips_active_passenger_idx
on public.trips(passenger_id, updated_at desc)
where status not in ('completed','passenger_cancelled','driver_cancelled','no_driver_found','quote_expired');
create index if not exists driver_presence_available_idx
on public.driver_presence(is_available,last_location_at desc)
where is_online = true and is_available = true;
