-- Durable dispatch retries: expire old offers and retry up to five rounds.
alter table public.trips add column if not exists dispatch_attempts smallint not null default 0 check (dispatch_attempts between 0 and 5);
alter table public.trips add column if not exists last_dispatch_at timestamptz;
create index if not exists trips_dispatch_retry_idx on public.trips(status,last_dispatch_at)
where status='searching' and dispatch_attempts<5;

create or replace function public.process_dispatch_attempt(p_trip_id uuid)
returns jsonb language plpgsql security definer set search_path=public,extensions
as $$
declare
  v_trip public.trips%rowtype;
  v_candidates jsonb;
  v_count integer:=0;
  v_attempt smallint;
  v_expiry timestamptz:=now()+interval '25 seconds';
begin
  select * into v_trip from public.trips where id=p_trip_id for update skip locked;
  if not found then return jsonb_build_object('status','busy_or_missing'); end if;
  if v_trip.status not in ('searching','requested') then return jsonb_build_object('status',v_trip.status); end if;

  update public.driver_offers set status='expired',responded_at=now()
   where trip_id=p_trip_id and status='offered' and expires_at<=now();
  if exists(select 1 from public.driver_offers where trip_id=p_trip_id and status in ('offered','accepted')) then
    return jsonb_build_object('status','searching','message','active_offers_exist');
  end if;

  v_attempt:=least(v_trip.dispatch_attempts+1,5);
  select coalesce(jsonb_agg(jsonb_build_object('driver_id',c.driver_id)), '[]'::jsonb)
    into v_candidates from public.find_dispatch_candidates(p_trip_id) c;
  if jsonb_array_length(v_candidates)=0 then
    update public.trips set dispatch_attempts=v_attempt,last_dispatch_at=now(),updated_at=now()
      where id=p_trip_id;
    if v_attempt>=5 then
      update public.trips set status='no_driver_found',updated_at=now() where id=p_trip_id;
      insert into public.trip_events(trip_id,event_type,from_status,to_status,metadata)
      values(p_trip_id,'no_driver_found',v_trip.status,'no_driver_found',jsonb_build_object('attempts',v_attempt));
      return jsonb_build_object('status','no_driver_found','attempts',v_attempt);
    end if;
    insert into public.trip_events(trip_id,event_type,from_status,to_status,metadata)
    values(p_trip_id,'dispatch_no_candidates',v_trip.status,'searching',jsonb_build_object('attempt',v_attempt));
    return jsonb_build_object('status','searching','attempts',v_attempt,'offers_sent',0);
  end if;

  insert into public.driver_offers(trip_id,driver_id,status,expires_at)
  select p_trip_id,(item->>'driver_id')::uuid,'offered',v_expiry
  from jsonb_array_elements(v_candidates) item
  on conflict (trip_id,driver_id) where status in ('offered','accepted') do nothing;
  get diagnostics v_count = row_count;
  update public.trips set dispatch_attempts=v_attempt,last_dispatch_at=now(),updated_at=now()
    where id=p_trip_id;
  insert into public.trip_events(trip_id,event_type,from_status,to_status,metadata)
  values(p_trip_id,'dispatch_offers_created',v_trip.status,'searching',jsonb_build_object('attempt',v_attempt,'candidate_count',v_count,'expires_at',v_expiry));
  return jsonb_build_object('status','searching','attempts',v_attempt,'offers_sent',v_count,'offer_expires_at',v_expiry);
end;
$$;
revoke all on function public.process_dispatch_attempt(uuid) from public,anon,authenticated;
grant execute on function public.process_dispatch_attempt(uuid) to service_role;

-- Consistent lock order (trip row, then offer row) avoids deadlocks with dispatch retries.
create or replace function public.accept_driver_offer(p_offer_id uuid,p_driver_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip_id uuid; v_old_status public.trip_status; v_offer public.driver_offers%rowtype; v_trip public.trips%rowtype; v_vehicle public.vehicles%rowtype;
begin
  select trip_id into v_trip_id from public.driver_offers where id=p_offer_id and driver_id=p_driver_id;
  if not found then raise exception 'offer_not_available'; end if;
  select * into v_trip from public.trips where id=v_trip_id for update;
  if not found or v_trip.status not in ('searching','requested') or v_trip.driver_id is not null then raise exception 'trip_already_claimed'; end if;
  select * into v_offer from public.driver_offers where id=p_offer_id and driver_id=p_driver_id
    and status='offered' and expires_at>now() for update;
  if not found then raise exception 'offer_not_available'; end if;

  perform 1 from public.driver_profiles where user_id=p_driver_id and status='approved' for update;
  if not found then raise exception 'driver_not_approved'; end if;
  perform 1 from public.driver_presence where driver_id=p_driver_id and is_online=true and is_available=true
    and last_location_at>now()-interval '90 seconds' for update;
  if not found then raise exception 'driver_not_available'; end if;
  select * into v_vehicle from public.vehicles where driver_id=p_driver_id and is_active=true
    and category_code=v_trip.category_code
    and passenger_capacity >= (select max_capacity from public.ride_categories where code=v_trip.category_code)
    order by created_at asc limit 1 for update;
  if not found then raise exception 'matching_vehicle_required'; end if;

  v_old_status:=v_trip.status;
  update public.trips set driver_id=p_driver_id,vehicle_id=v_vehicle.id,status='assigned',assigned_at=now(),updated_at=now()
   where id=v_trip_id returning * into v_trip;
  update public.driver_offers set status='accepted',responded_at=now() where id=p_offer_id;
  update public.driver_offers set status='cancelled',responded_at=now() where trip_id=v_trip_id and id<>p_offer_id and status='offered';
  update public.driver_presence set is_available=false,updated_at=now() where driver_id=p_driver_id;
  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
   values(v_trip_id,p_driver_id,'driver_assigned',v_old_status,'assigned',jsonb_build_object('vehicle_id',v_vehicle.id));
  return jsonb_build_object('trip_id',v_trip_id,'driver_id',p_driver_id,'vehicle_id',v_vehicle.id,'status','assigned');
end;
$$;
revoke all on function public.accept_driver_offer(uuid,uuid) from public,anon,authenticated;
grant execute on function public.accept_driver_offer(uuid,uuid) to service_role;
