-- Atomic acceptance: one winning driver per trip, and only the offered driver can accept.
create or replace function public.accept_driver_offer(p_offer_id uuid,p_driver_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_offer public.driver_offers%rowtype; v_trip public.trips%rowtype;
begin
  select * into v_offer from public.driver_offers
   where id=p_offer_id and driver_id=p_driver_id and status='offered'
     and expires_at>now() for update;
  if not found then raise exception 'offer_not_available'; end if;

  update public.trips set driver_id=p_driver_id,status='assigned',assigned_at=now(),updated_at=now()
   where id=v_offer.trip_id and status in ('searching','requested') and driver_id is null
   returning * into v_trip;
  if not found then
    update public.driver_offers set status='cancelled' where id=p_offer_id;
    raise exception 'trip_already_claimed';
  end if;

  update public.driver_offers set status='accepted' where id=p_offer_id;
  update public.driver_offers set status='cancelled'
   where trip_id=v_trip.id and id<>p_offer_id and status='offered';
  update public.driver_presence set is_available=false,updated_at=now() where driver_id=p_driver_id;
  insert into public.trip_events(trip_id,actor_id,event_type,metadata)
   values(v_trip.id,p_driver_id,'driver_assigned',jsonb_build_object('driver_id',p_driver_id));
  return jsonb_build_object('trip_id',v_trip.id,'driver_id',p_driver_id,'status','assigned');
end;
$$;
revoke all on function public.accept_driver_offer(uuid,uuid) from public,anon,authenticated;
grant execute on function public.accept_driver_offer(uuid,uuid) to service_role;

-- Keep trip lifecycle transitions constrained and evented.
create or replace function public.transition_trip(p_trip_id uuid,p_actor_id uuid,p_next_status public.trip_status,p_reason text default null)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip public.trips%rowtype; v_allowed boolean:=false;
begin
 select * into v_trip from public.trips where id=p_trip_id for update;
 if not found then raise exception 'trip_not_found'; end if;
 if p_actor_id<>v_trip.passenger_id and (v_trip.driver_id is null or p_actor_id<>v_trip.driver_id)
 then raise exception 'not_trip_participant'; end if;

 v_allowed := case v_trip.status
  when 'assigned' then p_next_status in ('driver_arriving','driver_cancelled','passenger_cancelled')
  when 'driver_arriving' then p_next_status in ('driver_arrived','driver_cancelled','passenger_cancelled')
  when 'driver_arrived' then p_next_status in ('in_progress','driver_cancelled','passenger_cancelled')
  when 'in_progress' then p_next_status='completed'
  else false end;
 if not v_allowed then raise exception 'invalid_trip_transition'; end if;

 update public.trips set status=p_next_status,updated_at=now(),
  arrived_at=case when p_next_status='driver_arrived' then now() else arrived_at end,
  started_at=case when p_next_status='in_progress' then now() else started_at end,
  completed_at=case when p_next_status='completed' then now() else completed_at end,
  cancelled_at=case when p_next_status in ('driver_cancelled','passenger_cancelled') then now() else cancelled_at end,
  cancellation_reason=case when p_next_status in ('driver_cancelled','passenger_cancelled') then p_reason else cancellation_reason end
 where id=p_trip_id returning * into v_trip;
 insert into public.trip_events(trip_id,actor_id,event_type,metadata)
 values(p_trip_id,p_actor_id,p_next_status::text,jsonb_build_object('reason',p_reason));
 return jsonb_build_object('trip_id',p_trip_id,'status',p_next_status);
end;
$$;
revoke all on function public.transition_trip(uuid,uuid,public.trip_status,text) from public,anon,authenticated;
grant execute on function public.transition_trip(uuid,uuid,public.trip_status,text) to service_role;
