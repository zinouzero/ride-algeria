-- Geospatial dispatch: shortlist by true geodesic distance with a GiST index.
create schema if not exists extensions;
create extension if not exists postgis with schema extensions;
alter table public.driver_presence add column if not exists location extensions.geography(Point,4326);

create or replace function public.sync_driver_presence_location()
returns trigger language plpgsql set search_path=public,extensions
as $$
begin
  if new.latitude is null or new.longitude is null then
    new.location := null;
  else
    new.location := extensions.st_setsrid(extensions.st_makepoint(new.longitude,new.latitude),4326)::extensions.geography;
  end if;
  return new;
end;
$$;
drop trigger if exists driver_presence_sync_location on public.driver_presence;
create trigger driver_presence_sync_location before insert or update of latitude,longitude
on public.driver_presence for each row execute function public.sync_driver_presence_location();
update public.driver_presence set latitude=latitude;
create index if not exists driver_presence_location_gix on public.driver_presence using gist(location)
where is_online=true and is_available=true;

create or replace function public.find_dispatch_candidates(p_trip_id uuid)
returns table(driver_id uuid,distance_m double precision)
language sql stable security definer set search_path=public,extensions
as $$
  select dp.driver_id,
    min(extensions.st_distance(dp.location,
      extensions.st_setsrid(extensions.st_makepoint(t.pickup_lng,t.pickup_lat),4326)::extensions.geography)) as distance_m
  from public.trips t
  join public.driver_presence dp on dp.is_online=true and dp.is_available=true
    and dp.last_location_at > now()-interval '90 seconds'
    and dp.location is not null
    and extensions.st_dwithin(dp.location,
      extensions.st_setsrid(extensions.st_makepoint(t.pickup_lng,t.pickup_lat),4326)::extensions.geography,12000)
  join public.driver_profiles d on d.user_id=dp.driver_id and d.status='approved'
  join public.vehicles v on v.driver_id=dp.driver_id and v.is_active=true and v.category_code=t.category_code
  join public.ride_categories c on c.code=t.category_code and v.passenger_capacity>=c.max_capacity
  where t.id=p_trip_id and t.status in ('requested','searching') and t.driver_id is null
  group by dp.driver_id
  order by distance_m asc
  limit 5;
$$;
revoke all on function public.find_dispatch_candidates(uuid) from public,anon,authenticated;
grant execute on function public.find_dispatch_candidates(uuid) to service_role;
