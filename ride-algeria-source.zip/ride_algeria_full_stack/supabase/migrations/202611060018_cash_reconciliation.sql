-- Admin can flag or confirm driver-declared cash receipts; cannot fabricate a receipt.
create or replace function public.review_cash_collection(
  p_admin_id uuid,p_trip_id uuid,p_decision text,p_note text default null
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_admin public.profiles%rowtype; v_cash public.cash_collections%rowtype; v_next public.payment_status;
begin
  select * into v_admin from public.profiles where id=p_admin_id and role='admin' and is_active=true;
  if not found then raise exception 'admin_required'; end if;
  if p_decision not in ('flag','confirm') then raise exception 'invalid_cash_review_decision'; end if;
  select * into v_cash from public.cash_collections where trip_id=p_trip_id for update;
  if not found then raise exception 'cash_collection_not_found'; end if;
  if p_decision='confirm' and v_cash.declared_collected_at is null then raise exception 'driver_receipt_not_declared'; end if;
  if p_decision='flag' then v_next:='under_review'; else v_next:='collected'; end if;
  update public.cash_collections set status=v_next,reviewed_at=case when p_decision='confirm' then now() else null end,
    review_note=left(trim(p_note),500),updated_at=now()
  where trip_id=p_trip_id returning * into v_cash;
  insert into public.admin_audit_log(admin_id,action,target_type,target_id,after_data)
  values(p_admin_id,'cash_'||p_decision,'cash_collection',p_trip_id::text,
    jsonb_build_object('status',v_cash.status,'review_note',v_cash.review_note,'amount_minor',v_cash.amount_minor));
  return jsonb_build_object('trip_id',p_trip_id,'status',v_cash.status,'reviewed_at',v_cash.reviewed_at);
end;
$$;
revoke all on function public.review_cash_collection(uuid,uuid,text,text) from public,anon,authenticated;
grant execute on function public.review_cash_collection(uuid,uuid,text,text) to service_role;
