-- Driver onboarding: private document bucket and a server-only atomic application RPC.
alter table public.driver_profiles add column if not exists rejection_reason text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('driver-documents','driver-documents',false,10485760,array['image/jpeg','image/png','application/pdf'])
on conflict(id) do update set public=false,file_size_limit=10485760,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "driver upload own documents" on storage.objects;
create policy "driver upload own documents" on storage.objects
for insert to authenticated with check (
  bucket_id='driver-documents' and (storage.foldername(name))[1]=auth.uid()::text
);
drop policy if exists "driver read own documents" on storage.objects;
create policy "driver read own documents" on storage.objects
for select to authenticated using (
  bucket_id='driver-documents' and (storage.foldername(name))[1]=auth.uid()::text
);
drop policy if exists "staff read driver documents storage" on storage.objects;
create policy "staff read driver documents storage" on storage.objects
for select to authenticated using (bucket_id='driver-documents' and public.is_staff());

create or replace function public.submit_driver_application(
  p_actor_id uuid,
  p_make text,
  p_model text,
  p_color text,
  p_plate_number text,
  p_category_code text,
  p_capacity smallint,
  p_documents jsonb
) returns jsonb
language plpgsql security definer set search_path=public
as $$
declare v_profile public.profiles%rowtype; v_doc jsonb; v_driver public.driver_profiles%rowtype; v_vehicle public.vehicles%rowtype;
begin
  select * into v_profile from public.profiles where id=p_actor_id and is_active=true for update;
  if not found then raise exception 'active_profile_required'; end if;
  if v_profile.role not in ('passenger','driver') then raise exception 'invalid_account_role'; end if;
  if exists(select 1 from public.driver_profiles where user_id=p_actor_id) then raise exception 'application_already_exists'; end if;
  if coalesce(length(trim(p_make)),0) not between 1 and 60 or coalesce(length(trim(p_model)),0) not between 1 and 60 or
     coalesce(length(trim(p_color)),0) not between 1 and 40 or coalesce(length(trim(p_plate_number)),0) not between 3 and 24 then
    raise exception 'invalid_vehicle_details';
  end if;
  if p_documents is null or jsonb_typeof(p_documents)<>'array' or jsonb_array_length(p_documents)<1 then raise exception 'documents_required'; end if;
  if not exists(select 1 from public.ride_categories c where c.code=p_category_code and c.is_active=true
    and p_capacity between c.min_capacity and c.max_capacity) then raise exception 'invalid_vehicle_category'; end if;

  insert into public.driver_profiles(user_id,status) values(p_actor_id,'pending') returning * into v_driver;
  insert into public.vehicles(driver_id,category_code,make,model,color,plate_number,passenger_capacity)
  values(p_actor_id,p_category_code,trim(p_make),trim(p_model),trim(p_color),upper(trim(p_plate_number)),p_capacity)
  returning * into v_vehicle;

  for v_doc in select value from jsonb_array_elements(p_documents) loop
    if coalesce(v_doc->>'document_type','')='' or coalesce(v_doc->>'storage_path','') not like p_actor_id::text||'/%' then
      raise exception 'invalid_document_reference';
    end if;
    insert into public.driver_documents(driver_id,document_type,storage_path,expires_at)
    values(p_actor_id,left(v_doc->>'document_type',60),v_doc->>'storage_path',nullif(v_doc->>'expires_at','')::timestamptz);
  end loop;
  update public.profiles set role='driver',updated_at=now() where id=p_actor_id;
  return jsonb_build_object('driver_id',p_actor_id,'status','pending','vehicle_id',v_vehicle.id);
end;
$$;
revoke all on function public.submit_driver_application(uuid,text,text,text,text,text,smallint,jsonb) from public,anon,authenticated;
grant execute on function public.submit_driver_application(uuid,text,text,text,text,text,smallint,jsonb) to service_role;


create or replace function public.review_driver_application(
  p_admin_id uuid,p_driver_id uuid,p_decision public.driver_status,p_reason text default null
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_admin public.profiles%rowtype; v_driver public.driver_profiles%rowtype;
begin
  if p_decision not in ('approved','rejected') then raise exception 'invalid_review_decision'; end if;
  if p_decision='rejected' and coalesce(length(trim(p_reason)),0)<5 then raise exception 'rejection_reason_required'; end if;
  select * into v_admin from public.profiles where id=p_admin_id and role='admin' and is_active=true;
  if not found then raise exception 'admin_required'; end if;
  select * into v_driver from public.driver_profiles where user_id=p_driver_id for update;
  if not found or v_driver.status<>'pending' then raise exception 'pending_application_not_found'; end if;
  update public.driver_profiles set status=p_decision,
    approved_at=case when p_decision='approved' then now() else null end,
    rejection_reason=case when p_decision='rejected' then left(trim(p_reason),500) else null end,
    updated_at=now()
  where user_id=p_driver_id;
  if p_decision='rejected' then update public.vehicles set is_active=false,updated_at=now() where driver_id=p_driver_id; end if;
  insert into public.admin_audit_log(admin_id,action,target_type,target_id,after_data)
  values(p_admin_id,'driver_'||p_decision::text,'driver',p_driver_id::text,jsonb_build_object('decision',p_decision,'reason',p_reason));
  return jsonb_build_object('driver_id',p_driver_id,'status',p_decision);
end;
$$;
revoke all on function public.review_driver_application(uuid,uuid,public.driver_status,text) from public,anon,authenticated;
grant execute on function public.review_driver_application(uuid,uuid,public.driver_status,text) to service_role;
