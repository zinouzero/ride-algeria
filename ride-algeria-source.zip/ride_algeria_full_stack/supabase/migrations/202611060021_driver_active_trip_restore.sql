-- Restore a driver's active lifecycle or unconfirmed cash receipt after app restart.
create or replace function public.get_driver_active_trip(p_driver_id uuid)
returns jsonb language plpgsql stable security definer set search_path=public
as $$
declare v_trip public.trips%rowtype;
begin
  select * into v_trip from public.trips
   where driver_id=p_driver_id and status in ('assigned','driver_arriving','driver_arrived','in_progress')
   order by assigned_at desc limit 1;
  if found then return jsonb_build_object('trip_id',v_trip.id,'status',v_trip.status); end if;
  select t.* into v_trip from public.trips t
   join public.cash_collections c on c.trip_id=t.id
   where t.driver_id=p_driver_id and t.status='completed'
     and c.status in ('due','under_review') and c.declared_collected_at is null
   order by t.completed_at desc limit 1;
  if found then return jsonb_build_object('trip_id',v_trip.id,'status',v_trip.status); end if;
  return null;
end;
$$;
revoke all on function public.get_driver_active_trip(uuid) from public,anon,authenticated;
grant execute on function public.get_driver_active_trip(uuid) to service_role;
