-- Upgrade already-provisioned databases from the original all-history unique index.
alter table public.driver_offers drop constraint if exists driver_offers_trip_id_driver_id_key;
drop index if exists public.driver_offer_trip_driver_unique;
create unique index if not exists driver_offer_active_trip_driver_unique
on public.driver_offers(trip_id,driver_id) where status in ('offered','accepted');
create index if not exists driver_offers_expiry_idx on public.driver_offers(status,expires_at);

-- Enable authenticated realtime streams for passenger/driver trip state and offers.
do $$
declare t text;
begin
  if exists(select 1 from pg_publication where pubname='supabase_realtime') then
    foreach t in array array['trips','driver_offers','driver_presence','trip_events'] loop
      if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then
        execute format('alter publication supabase_realtime add table public.%I',t);
      end if;
    end loop;
  end if;
end $$;
