-- Staff access is explicit and role-derived from profiles; never trust JWT metadata.
create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_active=true and p.role in ('admin','support')); $$;
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_active=true and p.role='admin'); $$;
revoke all on function public.is_staff() from public,anon;
revoke all on function public.is_admin() from public,anon;
grant execute on function public.is_staff() to authenticated,service_role;
grant execute on function public.is_admin() to authenticated,service_role;

-- Staff read surfaces needed by the operations console.
do $$ declare t text; begin
  foreach t in array array['profiles','driver_profiles','vehicles','driver_documents','trips',
    'driver_presence','driver_offers','trip_events','driver_locations','cash_collections',
    'payment_ledger','ratings','support_tickets','support_messages'] loop
    execute format('drop policy if exists %I on public.%I', 'staff read '||t, t);
    execute format('create policy %I on public.%I for select to authenticated using (public.is_staff())', 'staff read '||t, t);
  end loop;
end $$;

-- Admin-only configuration management. Support agents cannot change commercial rules.
do $$ declare t text; begin
  foreach t in array array['service_zones','ride_categories','zone_categories','fare_rules'] loop
    execute format('drop policy if exists %I on public.%I', 'admin manage '||t, t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', 'admin manage '||t, t);
  end loop;
end $$;

-- Support staff can update ticket workflow and add messages; requester policies remain.
drop policy if exists "staff update support tickets" on public.support_tickets;
create policy "staff update support tickets" on public.support_tickets
for update to authenticated using (public.is_staff()) with check (public.is_staff());
drop policy if exists "staff insert support messages" on public.support_messages;
create policy "staff insert support messages" on public.support_messages
for insert to authenticated with check (public.is_staff() and sender_id=auth.uid());
drop policy if exists "staff read audit" on public.admin_audit_log;
create policy "staff read audit" on public.admin_audit_log
for select to authenticated using (public.is_admin());

-- No client-facing mutation policy is added for driver approvals, financial entries,
-- driver locations, trip state, dispatch offers, or audit writes. Those remain server-only.
