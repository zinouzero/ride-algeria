-- Validate service-zone GeoJSON and resolve pickup/dropoff coverage in PostGIS.
alter table public.service_zones add column if not exists boundary_geom extensions.geometry(Geometry,4326);
create or replace function public.validate_service_zone_geometry()
returns trigger language plpgsql set search_path=public,extensions
as $$
declare v_geom extensions.geometry;
begin
  v_geom:=extensions.st_setsrid(extensions.st_geomfromgeojson(new.boundary_geojson::text),4326);
  if extensions.st_geometrytype(v_geom) not in ('ST_Polygon','ST_MultiPolygon') or extensions.st_isempty(v_geom) or not extensions.st_isvalid(v_geom) then
    raise exception 'invalid_service_zone_geometry';
  end if;
  if extensions.st_xmin(v_geom) < -180 or extensions.st_xmax(v_geom) > 180 or
     extensions.st_ymin(v_geom) < -90 or extensions.st_ymax(v_geom) > 90 then
    raise exception 'service_zone_coordinates_out_of_range';
  end if;
  new.boundary_geom:=v_geom;
  return new;
end;
$$;
drop trigger if exists service_zone_geometry_validate on public.service_zones;
create trigger service_zone_geometry_validate before insert or update of boundary_geojson
on public.service_zones for each row execute function public.validate_service_zone_geometry();
update public.service_zones set boundary_geojson=boundary_geojson;
create index if not exists service_zones_boundary_gix on public.service_zones using gist(boundary_geom);

create or replace function public.resolve_service_zone_for_points(
  p_pickup_lng double precision,p_pickup_lat double precision,
  p_dropoff_lng double precision,p_dropoff_lat double precision
) returns jsonb language plpgsql stable security definer set search_path=public,extensions
as $$
declare v_zone_id uuid; v_pickup extensions.geometry; v_dropoff extensions.geometry;
begin
  v_pickup:=extensions.st_setsrid(extensions.st_makepoint(p_pickup_lng,p_pickup_lat),4326);
  v_dropoff:=extensions.st_setsrid(extensions.st_makepoint(p_dropoff_lng,p_dropoff_lat),4326);
  select z.id into v_zone_id from public.service_zones z
   where z.is_active=true and z.country_code='DZ'
     and extensions.st_covers(z.boundary_geom,v_pickup)
   order by z.created_at asc limit 1;
  if v_zone_id is null then return jsonb_build_object('error','pickup_outside_service_area'); end if;
  if not exists(select 1 from public.service_zones z where z.id=v_zone_id and
    extensions.st_covers(z.boundary_geom,v_dropoff)) then
    return jsonb_build_object('error','dropoff_outside_service_area');
  end if;
  return jsonb_build_object('zone_id',v_zone_id);
end;
$$;
revoke all on function public.resolve_service_zone_for_points(double precision,double precision,double precision,double precision) from public,anon,authenticated;
grant execute on function public.resolve_service_zone_for_points(double precision,double precision,double precision,double precision) to service_role;
