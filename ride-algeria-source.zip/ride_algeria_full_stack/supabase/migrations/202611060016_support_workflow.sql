-- All support ticket creation goes through the validated Edge Function so trip links are checked.
drop policy if exists "support requester insert" on public.support_tickets;
-- Requesters can still read their own tickets; staff can read/update through the staff policies.
create index if not exists support_tickets_status_updated_idx on public.support_tickets(status,updated_at desc);
create index if not exists support_messages_ticket_created_idx on public.support_messages(ticket_id,created_at);
