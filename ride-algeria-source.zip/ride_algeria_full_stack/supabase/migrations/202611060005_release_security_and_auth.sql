-- Release hardening pass 1. Apply only after reviewing the target Supabase project.
-- Auth signup is phone-first. Client metadata can never assign privileged roles.
create or replace function public.bootstrap_profile_from_auth()
returns trigger
language plpgsql
security definer
set search_path = public, auth
as $$
declare v_phone text; v_first text; v_last text;
begin
  v_phone := nullif(trim(coalesce(new.phone, new.raw_user_meta_data->>'phone_e164', '')), '');
  if v_phone is null then
    raise exception 'phone_number_required';
  end if;
  v_first := left(coalesce(nullif(trim(new.raw_user_meta_data->>'first_name'), ''), 'مستخدم'), 80);
  v_last := left(nullif(trim(new.raw_user_meta_data->>'last_name'), ''), 80);
  insert into public.profiles(id, role, first_name, last_name, phone_e164, email)
  values(new.id, 'passenger', v_first, v_last, v_phone, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;
revoke all on function public.bootstrap_profile_from_auth() from public, anon, authenticated;
drop trigger if exists on_auth_user_created_profile on auth.users;
create trigger on_auth_user_created_profile
  after insert on auth.users
  for each row execute function public.bootstrap_profile_from_auth();

-- Fix acceptance: lock driver presence, require an approved/available driver and
-- an active vehicle in the requested category, then atomically claim the trip.
create or replace function public.accept_driver_offer(p_offer_id uuid,p_driver_id uuid)
returns jsonb language plpgsql security definer set search_path=public
as $$
declare
  v_offer public.driver_offers%rowtype;
  v_trip public.trips%rowtype;
  v_vehicle public.vehicles%rowtype;
begin
  select * into v_offer from public.driver_offers
   where id=p_offer_id and driver_id=p_driver_id and status='offered'
     and expires_at>now() for update;
  if not found then raise exception 'offer_not_available'; end if;

  perform 1 from public.driver_profiles
   where user_id=p_driver_id and status='approved' for update;
  if not found then raise exception 'driver_not_approved'; end if;

  perform 1 from public.driver_presence
   where driver_id=p_driver_id and is_online=true and is_available=true
     and last_location_at > now() - interval '90 seconds'
   for update;
  if not found then raise exception 'driver_not_available'; end if;

  select * into v_trip from public.trips where id=v_offer.trip_id for update;
  if not found or v_trip.status not in ('searching','requested') or v_trip.driver_id is not null
    then raise exception 'trip_already_claimed'; end if;

  select * into v_vehicle from public.vehicles
   where driver_id=p_driver_id and is_active=true
     and category_code=v_trip.category_code
     and passenger_capacity >= (select max_capacity from public.ride_categories where code=v_trip.category_code)
   order by created_at asc limit 1 for update;
  if not found then raise exception 'matching_vehicle_required'; end if;

  update public.trips set driver_id=p_driver_id,vehicle_id=v_vehicle.id,
    status='assigned',assigned_at=now(),updated_at=now()
   where id=v_trip.id returning * into v_trip;
  update public.driver_offers set status='accepted',responded_at=now() where id=p_offer_id;
  update public.driver_offers set status='cancelled',responded_at=now()
   where trip_id=v_trip.id and id<>p_offer_id and status='offered';
  update public.driver_presence set is_available=false,updated_at=now() where driver_id=p_driver_id;
  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
   values(v_trip.id,p_driver_id,'driver_assigned','searching','assigned',jsonb_build_object('vehicle_id',v_vehicle.id));
  return jsonb_build_object('trip_id',v_trip.id,'driver_id',p_driver_id,'vehicle_id',v_vehicle.id,'status','assigned');
end;
$$;
revoke all on function public.accept_driver_offer(uuid,uuid) from public,anon,authenticated;
grant execute on function public.accept_driver_offer(uuid,uuid) to service_role;

-- Participant and role-specific state transitions; no client can mark its own
-- ride completed or impersonate the other participant's lifecycle actions.
create or replace function public.transition_trip(
  p_trip_id uuid,p_actor_id uuid,p_next_status public.trip_status,p_reason text default null
) returns jsonb language plpgsql security definer set search_path=public
as $$
declare v_trip public.trips%rowtype; v_previous_status public.trip_status; v_is_passenger boolean; v_is_driver boolean; v_allowed boolean:=false;
begin
  select * into v_trip from public.trips where id=p_trip_id for update;
  if not found then raise exception 'trip_not_found'; end if;
  v_previous_status := v_trip.status;
  v_is_passenger := p_actor_id=v_trip.passenger_id;
  v_is_driver := v_trip.driver_id is not null and p_actor_id=v_trip.driver_id;
  if not (v_is_passenger or v_is_driver) then raise exception 'not_trip_participant'; end if;

  if p_next_status='passenger_cancelled' then
    v_allowed := v_is_passenger and v_trip.status in ('requested','searching','assigned','driver_arriving','driver_arrived');
  elsif p_next_status='driver_cancelled' then
    v_allowed := v_is_driver and v_trip.status in ('assigned','driver_arriving','driver_arrived');
  elsif p_next_status in ('driver_arriving','driver_arrived','in_progress','completed') then
    v_allowed := v_is_driver and (
      (v_trip.status='assigned' and p_next_status='driver_arriving') or
      (v_trip.status='driver_arriving' and p_next_status='driver_arrived') or
      (v_trip.status='driver_arrived' and p_next_status='in_progress') or
      (v_trip.status='in_progress' and p_next_status='completed')
    );
  end if;
  if not v_allowed then raise exception 'invalid_trip_transition'; end if;

  update public.trips set status=p_next_status,updated_at=now(),
    arrived_at=case when p_next_status='driver_arrived' then now() else arrived_at end,
    started_at=case when p_next_status='in_progress' then now() else started_at end,
    completed_at=case when p_next_status='completed' then now() else completed_at end,
    cancelled_at=case when p_next_status in ('driver_cancelled','passenger_cancelled') then now() else cancelled_at end,
    cancellation_reason=case when p_next_status in ('driver_cancelled','passenger_cancelled') then left(p_reason,300) else cancellation_reason end
  where id=p_trip_id returning * into v_trip;

  insert into public.trip_events(trip_id,actor_id,event_type,from_status,to_status,metadata)
  values(p_trip_id,p_actor_id,p_next_status::text,v_previous_status,p_next_status,jsonb_build_object('reason',left(p_reason,300)));

  if p_next_status='completed' then
    insert into public.cash_collections(trip_id,driver_id,amount_minor,currency,status)
    values(v_trip.id,v_trip.driver_id,coalesce(v_trip.final_fare_minor,v_trip.quoted_fare_minor),v_trip.currency,'due')
    on conflict (trip_id) do nothing;
    insert into public.payment_ledger(trip_id,entry_type,amount_minor,currency,created_by)
    values(v_trip.id,'fare_due',coalesce(v_trip.final_fare_minor,v_trip.quoted_fare_minor),v_trip.currency,p_actor_id);
  end if;
  if p_next_status in ('driver_cancelled','passenger_cancelled') then
    update public.driver_presence set is_available=true,updated_at=now() where driver_id=v_trip.driver_id;
  end if;
  return jsonb_build_object('trip_id',v_trip.id,'status',p_next_status);
end;
$$;
revoke all on function public.transition_trip(uuid,uuid,public.trip_status,text) from public,anon,authenticated;
grant execute on function public.transition_trip(uuid,uuid,public.trip_status,text) to service_role;

-- Protect identity, status and operational fields from self-service profile edits.
