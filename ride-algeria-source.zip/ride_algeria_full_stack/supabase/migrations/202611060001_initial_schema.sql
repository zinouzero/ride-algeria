-- Yassir Go alternative: initial PostgreSQL schema draft
-- Apply only after review in a development project. Do not paste service-role keys into clients.
-- Supabase-oriented: auth.users is the authentication source.
create extension if not exists pgcrypto;

create type public.account_role as enum ('passenger','driver','admin','support');
create type public.driver_status as enum ('pending','approved','rejected','suspended');
create type public.trip_status as enum (
  'draft','quoted','requested','searching','assigned','driver_arriving',
  'driver_arrived','in_progress','completed','passenger_cancelled',
  'driver_cancelled','no_driver_found','quote_expired','support_review'
);
create type public.offer_status as enum ('offered','accepted','rejected','expired','cancelled');
create type public.payment_status as enum ('due','collected','under_review','refunded','void');
create type public.support_status as enum ('open','pending','resolved','closed');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.account_role not null default 'passenger',
  first_name text not null,
  last_name text,
  phone_e164 text not null unique,
  email text,
  preferred_language text not null default 'ar',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  platform text not null check (platform in ('android','ios','web')),
  push_token text not null unique,
  last_seen_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);
create index devices_user_idx on public.devices(user_id);

create table public.driver_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  status public.driver_status not null default 'pending',
  rating_avg numeric(3,2) not null default 5.00 check (rating_avg between 0 and 5),
  rating_count integer not null default 0 check (rating_count >= 0),
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.driver_profiles(user_id) on delete restrict,
  category_code text not null,
  make text not null,
  model text not null,
  color text not null,
  plate_number text not null,
  passenger_capacity smallint not null check (passenger_capacity between 1 and 12),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (plate_number)
);
create index vehicles_driver_idx on public.vehicles(driver_id);
create index vehicles_category_active_idx on public.vehicles(category_code,is_active);

create table public.driver_documents (
  id uuid primary key default gen_random_uuid(),
  driver_id uuid not null references public.driver_profiles(user_id) on delete cascade,
  document_type text not null,
  storage_path text not null,
  expires_at timestamptz,
  verified_at timestamptz,
  rejected_reason text,
  created_at timestamptz not null default now()
);
create index driver_documents_driver_idx on public.driver_documents(driver_id);

create table public.service_zones (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null,
  country_code char(2) not null default 'DZ',
  boundary_geojson jsonb not null,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ride_categories (
  code text primary key,
  display_name text not null,
  description text,
  min_capacity smallint not null default 1,
  max_capacity smallint not null default 4,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  check (min_capacity > 0 and max_capacity >= min_capacity)
);

create table public.zone_categories (
  zone_id uuid not null references public.service_zones(id) on delete cascade,
  category_code text not null references public.ride_categories(code) on delete restrict,
  is_enabled boolean not null default true,
  primary key(zone_id,category_code)
);

create table public.fare_rules (
  id uuid primary key default gen_random_uuid(),
  zone_id uuid not null references public.service_zones(id) on delete restrict,
  category_code text not null references public.ride_categories(code) on delete restrict,
  currency char(3) not null default 'DZD',
  base_fare_minor bigint not null check (base_fare_minor >= 0),
  per_km_minor bigint not null check (per_km_minor >= 0),
  per_minute_minor bigint not null check (per_minute_minor >= 0),
  minimum_fare_minor bigint not null check (minimum_fare_minor >= 0),
  cancellation_fee_minor bigint not null default 0 check (cancellation_fee_minor >= 0),
  version integer not null,
  effective_from timestamptz not null,
  effective_until timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(zone_id,category_code,version),
  check (effective_until is null or effective_until > effective_from)
);
create index fare_rules_active_idx on public.fare_rules(zone_id,category_code,is_active,effective_from desc);

create table public.saved_places (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id) on delete cascade,
  label text not null,
  address_text text not null,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  provider_place_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index saved_places_passenger_idx on public.saved_places(passenger_id,created_at desc);

create table public.ride_quotes (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id) on delete restrict,
  zone_id uuid not null references public.service_zones(id) on delete restrict,
  category_code text not null references public.ride_categories(code) on delete restrict,
  pickup_label text not null,
  pickup_lat double precision not null check (pickup_lat between -90 and 90),
  pickup_lng double precision not null check (pickup_lng between -180 and 180),
  dropoff_label text not null,
  dropoff_lat double precision not null check (dropoff_lat between -90 and 90),
  dropoff_lng double precision not null check (dropoff_lng between -180 and 180),
  route_distance_m integer not null check (route_distance_m >= 0),
  route_duration_s integer not null check (route_duration_s >= 0),
  fare_minor bigint not null check (fare_minor >= 0),
  currency char(3) not null default 'DZD',
  fare_rule_version integer not null,
  quote_expires_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index ride_quotes_owner_idx on public.ride_quotes(passenger_id,created_at desc);
create index ride_quotes_expiry_idx on public.ride_quotes(quote_expires_at);

create table public.trips (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id) on delete restrict,
  driver_id uuid references public.driver_profiles(user_id) on delete restrict,
  vehicle_id uuid references public.vehicles(id) on delete restrict,
  quote_id uuid not null unique references public.ride_quotes(id) on delete restrict,
  zone_id uuid not null references public.service_zones(id) on delete restrict,
  category_code text not null references public.ride_categories(code) on delete restrict,
  status public.trip_status not null default 'requested',
  pickup_label text not null,
  pickup_lat double precision not null,
  pickup_lng double precision not null,
  dropoff_label text not null,
  dropoff_lat double precision not null,
  dropoff_lng double precision not null,
  quoted_fare_minor bigint not null check (quoted_fare_minor >= 0),
  final_fare_minor bigint check (final_fare_minor is null or final_fare_minor >= 0),
  currency char(3) not null default 'DZD',
  payment_method text not null default 'cash' check (payment_method in ('cash','card','wallet')),
  requested_at timestamptz not null default now(),
  assigned_at timestamptz,
  arrived_at timestamptz,
  started_at timestamptz,
  completed_at timestamptz,
  cancelled_at timestamptz,
  cancellation_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (final_fare_minor is null or final_fare_minor >= 0)
);
create index trips_passenger_history_idx on public.trips(passenger_id,created_at desc);
create index trips_driver_history_idx on public.trips(driver_id,created_at desc);
create index trips_dispatch_idx on public.trips(status,zone_id,requested_at);
create index trips_status_updated_idx on public.trips(status,updated_at);

create table public.driver_presence (
  driver_id uuid primary key references public.driver_profiles(user_id) on delete cascade,
  is_online boolean not null default false,
  is_available boolean not null default false,
  latitude double precision,
  longitude double precision,
  accuracy_m numeric(8,2),
  heading numeric(6,2),
  last_location_at timestamptz,
  updated_at timestamptz not null default now(),
  check (latitude is null or latitude between -90 and 90),
  check (longitude is null or longitude between -180 and 180)
);
create index driver_presence_online_idx on public.driver_presence(is_online,is_available,last_location_at);

create table public.driver_offers (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  driver_id uuid not null references public.driver_profiles(user_id) on delete restrict,
  status public.offer_status not null default 'offered',
  offered_at timestamptz not null default now(),
  expires_at timestamptz not null,
  responded_at timestamptz,
  rejection_reason text,
  created_at timestamptz not null default now(),
  unique(trip_id,driver_id)
);
create index driver_offers_driver_idx on public.driver_offers(driver_id,status,expires_at);
create index driver_offers_trip_idx on public.driver_offers(trip_id,status);

create table public.trip_events (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  event_type text not null,
  from_status public.trip_status,
  to_status public.trip_status,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
create index trip_events_trip_idx on public.trip_events(trip_id,created_at);

create table public.driver_locations (
  id bigint generated always as identity primary key,
  driver_id uuid not null references public.driver_profiles(user_id) on delete cascade,
  trip_id uuid references public.trips(id) on delete cascade,
  latitude double precision not null check (latitude between -90 and 90),
  longitude double precision not null check (longitude between -180 and 180),
  accuracy_m numeric(8,2),
  heading numeric(6,2),
  recorded_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index driver_locations_trip_idx on public.driver_locations(trip_id,recorded_at desc);
create index driver_locations_driver_idx on public.driver_locations(driver_id,recorded_at desc);

create table public.cash_collections (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null unique references public.trips(id) on delete restrict,
  driver_id uuid not null references public.driver_profiles(user_id) on delete restrict,
  amount_minor bigint not null check (amount_minor >= 0),
  currency char(3) not null default 'DZD',
  status public.payment_status not null default 'due',
  declared_collected_at timestamptz,
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index cash_collections_driver_idx on public.cash_collections(driver_id,status,created_at);

create table public.payment_ledger (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete restrict,
  entry_type text not null check (entry_type in ('fare_due','cash_collected','commission_due','adjustment','refund')),
  amount_minor bigint not null,
  currency char(3) not null default 'DZD',
  reference text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index payment_ledger_trip_idx on public.payment_ledger(trip_id,created_at);

create table public.ratings (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null unique references public.trips(id) on delete restrict,
  passenger_id uuid not null references public.profiles(id) on delete restrict,
  driver_id uuid not null references public.driver_profiles(user_id) on delete restrict,
  stars smallint not null check (stars between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);
create index ratings_driver_idx on public.ratings(driver_id,created_at desc);

create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete restrict,
  trip_id uuid references public.trips(id) on delete set null,
  category text not null,
  description text not null,
  status public.support_status not null default 'open',
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index support_tickets_requester_idx on public.support_tickets(requester_id,status,created_at desc);
create index support_tickets_assignee_idx on public.support_tickets(assigned_to,status);

create table public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid references public.profiles(id) on delete set null,
  message text not null,
  created_at timestamptz not null default now()
);
create index support_messages_ticket_idx on public.support_messages(ticket_id,created_at);

create table public.idempotency_keys (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references public.profiles(id) on delete cascade,
  idempotency_key text not null,
  operation text not null,
  response_body jsonb,
  created_at timestamptz not null default now(),
  unique(actor_id,operation,idempotency_key)
);
create index idempotency_created_idx on public.idempotency_keys(created_at);

create table public.admin_audit_log (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references public.profiles(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id text not null,
  before_data jsonb,
  after_data jsonb,
  created_at timestamptz not null default now()
);
create index admin_audit_created_idx on public.admin_audit_log(created_at desc);
create index admin_audit_target_idx on public.admin_audit_log(target_type,target_id,created_at desc);

-- Enable RLS on every client-exposed table. Privileged mutations must be performed
-- through server-side Edge Functions using a service role stored only as a secret.
alter table public.profiles enable row level security;
alter table public.devices enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.driver_documents enable row level security;
alter table public.service_zones enable row level security;
alter table public.ride_categories enable row level security;
alter table public.zone_categories enable row level security;
alter table public.fare_rules enable row level security;
alter table public.saved_places enable row level security;
alter table public.ride_quotes enable row level security;
alter table public.trips enable row level security;
alter table public.driver_presence enable row level security;
alter table public.driver_offers enable row level security;
alter table public.trip_events enable row level security;
alter table public.driver_locations enable row level security;
alter table public.cash_collections enable row level security;
alter table public.payment_ledger enable row level security;
alter table public.ratings enable row level security;
alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.idempotency_keys enable row level security;
alter table public.admin_audit_log enable row level security;

-- Basic self-read/self-update policies. Production policies must be extended with
-- role checks and immutable-column protections before exposing tables to clients.
create policy "profile read self" on public.profiles
for select using (id = auth.uid());
create policy "profile update self" on public.profiles
for update using (id = auth.uid())
with check (id = auth.uid());

create policy "device owner access" on public.devices
for select using (user_id = auth.uid());
create policy "device insert self" on public.devices
for insert with check (user_id = auth.uid());
create policy "device delete self" on public.devices
for delete using (user_id = auth.uid());

create policy "saved places owner access" on public.saved_places
for select using (passenger_id = auth.uid());
create policy "saved places insert self" on public.saved_places
for insert with check (passenger_id = auth.uid());
create policy "saved places update self" on public.saved_places
for update using (passenger_id = auth.uid())
with check (passenger_id = auth.uid());
create policy "saved places delete self" on public.saved_places
for delete using (passenger_id = auth.uid());

create policy "quotes owner read" on public.ride_quotes
for select using (passenger_id = auth.uid());

create policy "trips passenger or assigned driver read" on public.trips
for select using (passenger_id = auth.uid() or driver_id = auth.uid());

create policy "driver profile self read" on public.driver_profiles
for select using (user_id = auth.uid());
create policy "vehicle driver self read" on public.vehicles
for select using (driver_id = auth.uid());

create policy "offers driver self read" on public.driver_offers
for select using (driver_id = auth.uid());

create policy "trip events participant read" on public.trip_events
for select using (
  exists (
    select 1 from public.trips t
    where t.id = trip_events.trip_id
      and (t.passenger_id = auth.uid() or t.driver_id = auth.uid())
  )
);

create policy "ratings passenger or driver read" on public.ratings
for select using (passenger_id = auth.uid() or driver_id = auth.uid());
create policy "ratings passenger insert" on public.ratings
for insert with check (passenger_id = auth.uid());

create policy "support requester read" on public.support_tickets
for select using (requester_id = auth.uid());
create policy "support requester insert" on public.support_tickets
for insert with check (requester_id = auth.uid());

create policy "support message participant read" on public.support_messages
for select using (
  exists (
    select 1 from public.support_tickets st
    where st.id = support_messages.ticket_id
      and (st.requester_id = auth.uid() or st.assigned_to = auth.uid())
  )
);

-- NOTE: No direct client write policies are created for trips, driver presence,
-- dispatch offers, driver locations, fare rules, payment ledger or admin audit.
-- Add narrowly scoped server functions and explicit policies only after threat review.
