# مشواري — Ride Algeria

منصة نقل حضري مستقلة للسوق الجزائري، بهوية وتصميم وكود مستقلين. الحزمة تجمع تطبيق الراكب، تطبيق السائق، لوحة العمليات والدعم، وقاعدة البيانات ووظائف الخادم.

## محتويات المشروع

- `passenger_app/` — Flutter Android: تسجيل هاتف OTP، اختيار نقطة الانطلاق من GPS، اختيار الوجهة على الخريطة، طلب عروض الأسعار من الخادم، إنشاء الرحلة ومتابعة الحالة وإلغاء الرحلة.
- `driver_app/` — Flutter Android: تسجيل هاتف OTP، التحقق من اعتماد السائق، الاتصال/الانقطاع، تحديث الموقع، استقبال عروض الرحلات عبر Realtime، قبول/رفض، وتحديث مراحل الرحلة.
- `admin_console/` — Next.js: تسجيل دخول OTP، تحقق دور الإدارة/الدعم، مؤشرات الرحلات والسائقين وتذاكر الدعم.
- `supabase/` — 21 migrations ووظائف Edge للمصادقة التشغيلية، البحث الجغرافي، التسعير، الطلب، التوزيع، قبول العروض، تحديث الموقع، تسجيل السائق ومراجعته، وتغيير الحالة، وتسوية تحصيل الدفع النقدي، التقييمات الموثقة، تذاكر الدعم، وإعادة توزيع الطلبات المنتهية الصلاحية.
- `tests/` — فحوصات ثابتة آلية للملفات والقيود الأساسية.
- `docs/` — وثائق هندسية وتكاملات لازمة للإطلاق.

## الهوية والمنتج

اسم التطبيق التجاري المؤقت: **مشواري**. هذا اسم عمل وليس تحققاً قانونياً من توفر العلامة أو الاسم التجاري. لا توجد علاقة رسمية مع ياسير ولا نسخ لشعاره أو كوده أو واجهاته الخاصة.

## البنية التشغيلية

- Android passenger + Android driver: Flutter/Dart (Dart 3.11+ / Flutter 3.41+).
- Admin: Next.js 16 + React 19 + TypeScript.
- Backend: Supabase Auth + PostgreSQL + RLS + Edge Functions + Realtime.
- Routing: adapter خاص يربط مزود مسارات مرخصاً تجارياً ويغطي مناطق الخدمة في الجزائر.
- Maps: MapLibre-compatible tiles via provider URL configured at build time.
- Payment: cash-first. مبالغ DZD تُخزن بالسنتيم (100 سنتيم = 1 دج). لا توجد معالجة بطاقات أو محفظة في هذه النسخة.

## التهيئة

0. جهّز Android host files من مجلد المشروع: `bash scripts/bootstrap_android.sh` (يتطلب Flutter SDK).
1. أنشئ مشروع Supabase مملوكاً لك، واضبط Auth Phone OTP ومزود SMS صالحاً للجزائر.
2. اربط Supabase CLI بالمشروع ثم طبّق migrations بالترتيب من `0001` إلى `0021`.
3. أضف Edge Function secrets من `.env.example` إلى إعدادات Supabase. لا تضع `service_role` في تطبيقات الهاتف أو لوحة الويب.
4. انشر جميع وظائف `supabase/functions/*`، بما فيها `driver-offer-details`.
5. اختر مزود خرائط ومسارات بعد التحقق من التغطية الفعلية، شروط الاستخدام التجاري، الأسعار، وسياسة تخزين بيانات المواقع. نفّذ عقد routing adapter المبين في `docs/production-integrations.md`.
6. هيئ `MAP_TILE_URL` و`MAP_ATTRIBUTION` عند بناء تطبيقَي Flutter.
7. أنشئ حسابات الإدارة والسائقين، ثم عيّن الأدوار واعتماد المركبات من إجراء إداري آمن. لا تمنح دور admin من بيانات التسجيل أو metadata.
8. شغّل لوحة الإدارة مع متغيرات `NEXT_PUBLIC_SUPABASE_URL` و`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` فقط.

## النشر والبناء

بعد إنشاء مشروع Supabase وضبط الأسرار في لوحة المشروع، نفّذ `scripts/deploy_backend.sh` (أو `scripts/deploy_backend.ps1` على Windows) مع متغير `SUPABASE_PROJECT_REF`. لبناء تطبيقات Android الموقّعة ولوحة الإدارة استخدم `scripts/build_release.sh` (أو `scripts/build_release.ps1` على Windows) بعد تجهيز مفاتيح الرفع ومتغيرات البناء.

## أوامر البناء

لإنشاء Android Gradle wrapper والمشروع الأصلي، جهّز المنصتين أولاً: `bash scripts/bootstrap_android.sh`. أنشئ مفتاح رفع خاصاً بك ولا ترسله في المحادثة أو تضعه في Git:

```bash
keytool -genkeypair -v -keystore passenger_app/android/app/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
keytool -genkeypair -v -keystore driver_app/android/app/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

أنشئ `android/key.properties` داخل كل تطبيق مع `storePassword`, `keyPassword`, `keyAlias=upload`, و`storeFile=upload-keystore.jks`. ثم يمكن تشغيل `scripts/build_release.sh` بعد ضبط متغيرات البيئة.

Passenger:

```bash
cd passenger_app
flutter pub get
flutter build appbundle --release \\
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \\
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY \\
  --dart-define=MAP_TILE_URL=https://YOUR_PROVIDER/{z}/{x}/{y}.png \\
  --dart-define=MAP_ATTRIBUTION="Your provider"
```

Driver:

```bash
cd driver_app
flutter pub get
flutter build appbundle --release \\
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \\
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

Admin:

```bash
cd admin_console
cp .env.example .env.local
npm install
npm run build
```

## الاختبارات المتاحة

```bash
python tests/run_checks.py
```

هذه تفحّص سلامة البنية وبعض ثوابت الأمان وتحوّل TypeScript نحو JavaScript لفحص الصياغة. ليست بديلاً عن اختبار PostgreSQL/Supabase حقيقي، ولا عن بناء Flutter على Android SDK، ولا عن اختبار أجهزة وشبكة حقيقية.

## حالة الإطلاق

هذه ليست نسخة تجريبية ببيانات وهمية: مسار الطلب يعتمد على الخادم، ولا يوجد سعر وهمي أو سائق وهمي، والتسعير يرفض العمل إذا لم تُضبط خدمة المسارات. لكنها حزمة مصدر مهيأة للإطلاق وليست بعد ملف AAB موقّعاً أو إصدار متجر معتمداً: **لا تُنشر قبل اجتياز بوابات الإطلاق الحقيقية**. لا يمكن إصدار حكم إنتاجي قبل إتمام تكامل مزود الخرائط والمسارات وSMS وPush، إعداد Firebase/FCM، إنشاء حسابات التشغيل، مراجعة سياسات الخصوصية والشروط والتراخيص والتأمين والامتثال المحلي، ثم تشغيل اختبارات التكامل والأمن والأداء على مشروع Supabase وأجهزة Android فعلية. لا يوجد أي سعر تجريبي أو سائق وهمي مفعّل في مسار التطبيق الافتراضي؛ الخادم يرفض إنشاء السعر عند غياب routing adapter.
