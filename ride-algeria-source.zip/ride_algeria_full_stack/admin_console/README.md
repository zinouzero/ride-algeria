# Operations admin console

Next.js 16 App Router, React 19, Supabase SSR cookies and server-verified claims. Includes phone OTP login, role-gated dashboard, driver document review, service-zone/category/fare configuration, audit-triggered changes, and support ticket handling.

Requires Node.js 20.9 or newer. Configure `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` in `.env.local`. Do not expose service-role keys to this application.
