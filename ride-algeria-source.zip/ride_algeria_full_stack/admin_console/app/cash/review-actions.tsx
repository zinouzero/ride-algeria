'use client';
import { useState } from 'react';
import { getSupabaseBrowserClient } from '../../lib/supabase-browser';
export default function CashReviewActions({tripId,declared,status}:{tripId:string,declared:boolean,status:string}){
  const [note,setNote]=useState('');const [busy,setBusy]=useState(false);const [message,setMessage]=useState('');
  async function review(decision:'flag'|'confirm'){
    setBusy(true);setMessage('');try{const {error}=await getSupabaseBrowserClient().functions.invoke('review-cash-collection',{body:{trip_id:tripId,decision,note:note.trim()}});if(error)throw error;window.location.reload();}catch(e){setMessage(e instanceof Error?e.message:'تعذر تنفيذ المراجعة.');}finally{setBusy(false);}}
  return <div className="cash-actions"><input value={note} onChange={e=>setNote(e.target.value)} placeholder="ملاحظة المراجعة" />
    <button className="secondary" disabled={busy} onClick={()=>review('flag')}>وضع تحت المراجعة</button>
    {declared&&<button disabled={busy} onClick={()=>review('confirm')}>تأكيد التحصيل</button>}
    {message&&<small>{message}</small>}
  </div>;
}
