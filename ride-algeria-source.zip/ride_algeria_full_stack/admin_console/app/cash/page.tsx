import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '../../lib/supabase-server';
import CashReviewActions from './review-actions';
const money=(n:number)=>new Intl.NumberFormat('ar-DZ',{maximumFractionDigits:2}).format(n/100);
export default async function CashPage(){
  const db=await createSupabaseServerClient();const {data:{user}}=await db.auth.getUser();if(!user)redirect('/login');
  const {data:profile}=await db.from('profiles').select('role,is_active').eq('id',user.id).maybeSingle();if(!profile?.is_active||profile.role!=='admin')redirect('/');
  const {data:collections}=await db.from('cash_collections').select('trip_id,driver_id,amount_minor,currency,status,declared_collected_at,reviewed_at,review_note,created_at').order('created_at',{ascending:false}).limit(100);
  const tripIds=(collections??[]).map(x=>x.trip_id);const driverIds=(collections??[]).map(x=>x.driver_id);
  const [{data:trips},{data:drivers}]=await Promise.all([
    tripIds.length?db.from('trips').select('id,pickup_label,dropoff_label,completed_at').in('id',tripIds):Promise.resolve({data:[]}),
    driverIds.length?db.from('profiles').select('id,first_name,last_name,phone_e164').in('id',driverIds):Promise.resolve({data:[]}),
  ]);
  const tripMap=new Map((trips??[]).map(t=>[t.id,t]));const driverMap=new Map((drivers??[]).map(d=>[d.id,d]));
  const due=(collections??[]).filter(c=>c.status==='due').reduce((a,c)=>a+c.amount_minor,0);
  const collected=(collections??[]).filter(c=>c.status==='collected').reduce((a,c)=>a+c.amount_minor,0);
  const review=(collections??[]).filter(c=>c.status==='under_review').reduce((a,c)=>a+c.amount_minor,0);
  return <main className="dashboard" dir="rtl"><header className="topbar"><div><span className="eyebrow">المحاسبة التشغيلية</span><h1>تحصيل الدفع النقدي</h1><p>مبالغ الرحلات المكتملة وتأكيدات السائقين.</p></div><Link href="/">العودة للوحة الرئيسية</Link></header>
    <section className="stat-grid"><article className="stat-card"><span>مستحق التحصيل</span><strong>{money(due)} دج</strong></article><article className="stat-card"><span>مُحصّل</span><strong>{money(collected)} دج</strong></article><article className="stat-card"><span>تحت المراجعة</span><strong>{money(review)} دج</strong></article><article className="stat-card"><span>عدد السجلات</span><strong>{(collections??[]).length}</strong></article></section>
    {(collections??[]).map(c=>{const trip=tripMap.get(c.trip_id);const driver=driverMap.get(c.driver_id);return <section className="panel cash-card" key={c.trip_id}>
      <div className="panel-heading"><div><h2>{driver?.first_name??'السائق'} {driver?.last_name??''} · {driver?.phone_e164??''}</h2><p>{trip?.pickup_label??'—'} ← {trip?.dropoff_label??'—'}</p></div><span className="status">{c.status}</span></div>
      <strong className="cash-amount">{money(c.amount_minor)} دج</strong><p>الرحلة: {c.trip_id} · {c.declared_collected_at?`صرّح بالتحصيل: ${new Date(c.declared_collected_at).toLocaleString('ar-DZ')}`:'لم يصرّح السائق بالتحصيل بعد'}</p>
      {c.review_note&&<p>ملاحظة: {c.review_note}</p>}
      <CashReviewActions tripId={c.trip_id} declared={Boolean(c.declared_collected_at)} status={c.status}/>
    </section>;})}
    {(collections??[]).length===0&&<section className="panel empty">لا توجد تحصيلات مسجلة بعد.</section>}
  </main>;
}
