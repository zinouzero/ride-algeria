import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '../../lib/supabase-server';
import SupportThread from './support-thread';
export default async function SupportPage(){
  const db=await createSupabaseServerClient();const {data:{user}}=await db.auth.getUser();if(!user)redirect('/login');
  const {data:profile}=await db.from('profiles').select('role,is_active').eq('id',user.id).maybeSingle();
  if(!profile?.is_active||!['admin','support'].includes(profile.role))redirect('/access-denied');
  const {data:tickets}=await db.from('support_tickets').select('id,requester_id,trip_id,category,description,status,created_at').in('status',['open','pending','resolved','closed']).order('updated_at',{ascending:false}).limit(40);
  const ids=(tickets??[]).map(t=>t.requester_id);const ticketIds=(tickets??[]).map(t=>t.id);
  const [{data:people},{data:messages}]=await Promise.all([
    ids.length?db.from('profiles').select('id,first_name,last_name,phone_e164').in('id',ids):Promise.resolve({data:[]}),
    ticketIds.length?db.from('support_messages').select('id,ticket_id,sender_id,message,created_at').in('ticket_id',ticketIds).order('created_at',{ascending:true}):Promise.resolve({data:[]}),
  ]);
  const personById=new Map((people??[]).map(p=>[p.id,p]));
  return <main className="dashboard" dir="rtl"><header className="topbar"><div><span className="eyebrow">خدمة العملاء</span><h1>تذاكر الدعم</h1><p>تابع طلبات الزبائن وردّ عليها وسجّل حلها.</p></div><Link href="/">العودة للوحة الرئيسية</Link></header>
    {(tickets??[]).length===0&&<section className="panel empty">لا توجد تذاكر دعم.</section>}
    {(tickets??[]).map(ticket=>{const person=personById.get(ticket.requester_id);const thread=(messages??[]).filter(m=>m.ticket_id===ticket.id);return <SupportThread key={ticket.id} ticket={{...ticket,requesterName:person?.first_name??person?.phone_e164??ticket.requester_id}} messages={thread}/>;})}
  </main>;
}
