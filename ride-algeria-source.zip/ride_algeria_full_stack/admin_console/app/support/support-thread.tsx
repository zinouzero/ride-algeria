'use client';
import { useState } from 'react';
import { getSupabaseBrowserClient } from '../../lib/supabase-browser';
type Message={id:string,message:string,created_at:string,sender_id:string|null};
export default function SupportThread({ticket,messages}:{ticket:any,messages:Message[]}) {
  const [reply,setReply]=useState(''); const [busy,setBusy]=useState(false); const [status,setStatus]=useState(ticket.status); const [notice,setNotice]=useState('');
  async function send(){if(!reply.trim())return;setBusy(true);setNotice('');try{const {error}=await getSupabaseBrowserClient().functions.invoke('send-support-message',{body:{ticket_id:ticket.id,message:reply.trim()}});if(error)throw error;setReply('');window.location.reload();}catch(e){setNotice(e instanceof Error?e.message:'تعذر إرسال الرد.');}finally{setBusy(false);}}
  async function updateStatus(next:string){setBusy(true);setNotice('');try{const {error}=await getSupabaseBrowserClient().from('support_tickets').update({status:next,updated_at:new Date().toISOString()}).eq('id',ticket.id);if(error)throw error;setStatus(next);window.location.reload();}catch(e){setNotice(e instanceof Error?e.message:'تعذر تحديث الحالة.');}finally{setBusy(false);}}
  return <section className="panel support-thread"><div className="panel-heading"><div><h2>{ticket.category} · {ticket.requesterName}</h2><p>{ticket.description}</p><small>{ticket.id} · {ticket.status}</small></div><span className="status">{status}</span></div>
    <div className="message-list">{messages.map(m=><article key={m.id}><p>{m.message}</p><small>{m.sender_id===ticket.requester_id?'الزبون':'فريق الدعم'} · {new Date(m.created_at).toLocaleString('ar-DZ')}</small></article>)}{messages.length===0&&<small>لا توجد ردود بعد.</small>}</div>
    <textarea rows={3} value={reply} onChange={e=>setReply(e.target.value)} placeholder="اكتب رد فريق الدعم..." />
    <div className="support-actions"><button disabled={busy||!reply.trim()} onClick={send}>إرسال الرد</button><button className="secondary" disabled={busy} onClick={()=>updateStatus('resolved')}>وضع علامة محلول</button><button className="secondary" disabled={busy} onClick={()=>updateStatus('closed')}>إغلاق التذكرة</button></div>
    {notice&&<small>{notice}</small>}
  </section>;
}
