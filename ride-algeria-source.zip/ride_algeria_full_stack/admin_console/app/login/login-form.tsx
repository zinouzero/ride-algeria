'use client';
import { FormEvent, useState } from 'react';
import { getSupabaseBrowserClient } from '../../lib/supabase-browser';

export default function LoginForm() {
  const [phone, setPhone] = useState('+213');
  const [token, setToken] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setMessage('');
    try {
      const supabase = getSupabaseBrowserClient();
      if (!sent) {
        const { error } = await supabase.auth.signInWithOtp({ phone: phone.trim() });
        if (error) throw error;
        setSent(true); setMessage('تم إرسال رمز التحقق إذا كان الرقم مهيأً لدى مزود الرسائل.');
      } else {
        const { error } = await supabase.auth.verifyOtp({ phone: phone.trim(), token: token.trim(), type: 'sms' });
        if (error) throw error;
        window.location.assign('/');
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : 'تعذر تسجيل الدخول'); }
    finally { setBusy(false); }
  }
  return <form onSubmit={submit} className="login-form">
    <label>رقم الهاتف الدولي</label>
    <input value={phone} onChange={e=>setPhone(e.target.value)} inputMode="tel" autoComplete="tel" required disabled={sent}/>
    {sent && <><label>رمز التحقق</label><input value={token} onChange={e=>setToken(e.target.value)} inputMode="numeric" autoComplete="one-time-code" maxLength={8} required /></>}
    <button disabled={busy}>{busy ? 'يرجى الانتظار...' : sent ? 'تأكيد الدخول' : 'إرسال رمز الدخول'}</button>
    {message && <p role="status">{message}</p>}
  </form>;
}
