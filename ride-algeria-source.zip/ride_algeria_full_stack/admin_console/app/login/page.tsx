import LoginForm from './login-form';
export default function LoginPage() {
  return <main className="login-wrap" dir="rtl"><section className="login-card">
    <div className="brand-mark">ر</div><h1>دخول فريق التشغيل</h1>
    <p>استعمل رقم الهاتف المسجل في حساب الإدارة أو الدعم.</p>
    <LoginForm />
    <small>الدخول محصور في الحسابات التي فعّلها مسؤول النظام.</small>
  </section></main>;
}
