export default function AccessDeniedPage() {
  return <main className="login-wrap" dir="rtl"><section className="login-card">
    <h1>الحساب غير مخوّل</h1>
    <p>تم تسجيل الدخول، لكن الحساب لا يملك صلاحية الإدارة أو الدعم. تواصل مع مسؤول النظام لتصحيح الدور.</p>
    <form action="/auth/signout" method="post"><button>تسجيل الخروج</button></form>
  </section></main>;
}
