import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '../lib/supabase-server';

const number = (value: number | null | undefined) => new Intl.NumberFormat('ar-DZ').format(value ?? 0);
const money = (value: number | null | undefined) => new Intl.NumberFormat('ar-DZ',{maximumFractionDigits:2}).format((value ?? 0)/100);
export default async function DashboardPage() {
  const supabase = await createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/login');
  const { data: profile } = await supabase.from('profiles').select('first_name,role,is_active').eq('id', user.id).maybeSingle();
  if (!profile || !profile.is_active || !['admin','support'].includes(profile.role)) redirect('/access-denied');
  const [active, pending, drivers, tickets, recent] = await Promise.all([
    supabase.from('trips').select('id', { count: 'exact', head: true }).in('status', ['searching','assigned','driver_arriving','driver_arrived','in_progress']),
    supabase.from('driver_profiles').select('user_id', { count: 'exact', head: true }).eq('status','pending'),
    supabase.from('driver_profiles').select('user_id', { count: 'exact', head: true }).eq('status','approved'),
    supabase.from('support_tickets').select('id', { count: 'exact', head: true }).in('status',['open','pending']),
    supabase.from('trips').select('id,status,pickup_label,dropoff_label,quoted_fare_minor,currency,created_at').order('created_at',{ascending:false}).limit(12),
  ]);
  const stats = [
    ['الرحلات النشطة', active.count], ['طلبات السائقين', pending.count],
    ['السائقون المعتمدون', drivers.count], ['تذاكر الدعم المفتوحة', tickets.count],
  ];
  return <main className="dashboard" dir="rtl">
    <header className="topbar"><div><span className="eyebrow">مركز العمليات</span><h1>لوحة إدارة مشواري</h1><p>مرحباً {profile.first_name} — صلاحية {profile.role === 'admin' ? 'مدير' : 'دعم'}</p></div>
      <div className="top-actions"><a href="/drivers">طلبات السائقين</a><a href="/settings">مناطق وأسعار</a><a href="/support">الدعم</a><a href="/cash">التحصيل النقدي</a><form action="/auth/signout" method="post"><button className="secondary">تسجيل الخروج</button></form></div></header>
    <section className="stat-grid">{stats.map(([label,value])=><article className="stat-card" key={label}><span>{label}</span><strong>{number(value as number | null)}</strong></article>)}</section>
    <section className="panel"><div className="panel-heading"><div><h2>آخر الرحلات</h2><p>آخر 12 طلباً مسجلاً في النظام</p></div><span className="live-dot">بيانات مباشرة من قاعدة البيانات</span></div>
      <div className="table-wrap"><table><thead><tr><th>رقم الرحلة</th><th>الانطلاق</th><th>الوجهة</th><th>الحالة</th><th>السعر المعروض</th><th>التاريخ</th></tr></thead><tbody>
      {(recent.data ?? []).map((trip:any)=><tr key={trip.id}><td className="mono">{trip.id.slice(0,8)}</td><td>{trip.pickup_label}</td><td>{trip.dropoff_label}</td><td><span className="status">{trip.status}</span></td><td>{money(trip.quoted_fare_minor)} دج</td><td>{new Date(trip.created_at).toLocaleString('ar-DZ')}</td></tr>)}
      {(!recent.data || recent.data.length===0) && <tr><td colSpan={6} className="empty">لا توجد رحلات مسجلة بعد.</td></tr>}
      </tbody></table></div>
    </section>
    <footer>مشواري · لوحة داخلية محمية · لا تُعرض مفاتيح الخادم في المتصفح</footer>
  </main>;
}
