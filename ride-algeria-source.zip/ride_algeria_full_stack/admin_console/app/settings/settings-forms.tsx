'use client';
import { useState } from 'react';
import { getSupabaseBrowserClient } from '../../lib/supabase-browser';
type Zone={id:string,name:string,city:string,is_active:boolean};
type Category={code:string,display_name:string,min_capacity:number,max_capacity:number,is_active:boolean};
export default function SettingsForms({zones,categories}:{zones:Zone[],categories:Category[]}) {
  const [zoneName,setZoneName]=useState(''),[city,setCity]=useState(''),[geo,setGeo]=useState('');
  const [code,setCode]=useState(''),[categoryName,setCategoryName]=useState(''),[minCap,setMinCap]=useState('1'),[maxCap,setMaxCap]=useState('4');
  const [zoneId,setZoneId]=useState(zones[0]?.id??''),[categoryCode,setCategoryCode]=useState(categories[0]?.code??'');
  const [base,setBase]=useState(''),[perKm,setPerKm]=useState(''),[perMin,setPerMin]=useState(''),[minimum,setMinimum]=useState(''),[version,setVersion]=useState('1');
  const [busy,setBusy]=useState(false),[message,setMessage]=useState('');
  async function run(action:()=>Promise<void>) {setBusy(true);setMessage('');try{await action();setMessage('تم الحفظ.');window.location.reload();}catch(e){setMessage(e instanceof Error?e.message:'تعذر الحفظ.');}finally{setBusy(false);}}
  async function addZone(){await run(async()=>{let boundary:any;try{boundary=JSON.parse(geo)}catch{throw new Error('صيغة GeoJSON غير صحيحة.')}if(!['Polygon','MultiPolygon'].includes(boundary?.type))throw new Error('يجب أن يكون الحد Polygon أو MultiPolygon.');const {error}=await getSupabaseBrowserClient().from('service_zones').insert({name:zoneName.trim(),city:city.trim(),country_code:'DZ',boundary_geojson:boundary,is_active:true});if(error)throw error;});}
  async function addCategory(){await run(async()=>{const {error}=await getSupabaseBrowserClient().from('ride_categories').insert({code:code.trim().toLowerCase(),display_name:categoryName.trim(),min_capacity:Number(minCap),max_capacity:Number(maxCap),is_active:true});if(error)throw error;});}
  async function enableCategory(){await run(async()=>{const {error}=await getSupabaseBrowserClient().from('zone_categories').upsert({zone_id:zoneId,category_code:categoryCode,is_enabled:true},{onConflict:'zone_id,category_code'});if(error)throw error;});}
  async function toggleZone(z:Zone){await run(async()=>{const {error}=await getSupabaseBrowserClient().from('service_zones').update({is_active:!z.is_active}).eq('id',z.id);if(error)throw error;});}
  async function toggleCategory(c:Category){await run(async()=>{const {error}=await getSupabaseBrowserClient().from('ride_categories').update({is_active:!c.is_active}).eq('code',c.code);if(error)throw error;});}
  async function addFare(){await run(async()=>{const values=[base,perKm,perMin,minimum].map(Number);if(values.some(v=>!Number.isFinite(v)||v<0))throw new Error('أدخل مبالغ صحيحة غير سالبة.');const {error}=await getSupabaseBrowserClient().from('fare_rules').insert({zone_id:zoneId,category_code:categoryCode,currency:'DZD',base_fare_minor:Math.round(values[0]*100),per_km_minor:Math.round(values[1]*100),per_minute_minor:Math.round(values[2]*100),minimum_fare_minor:Math.round(values[3]*100),version:Number(version),effective_from:new Date().toISOString(),is_active:true});if(error)throw error;});}
  return <div className="settings-grid">
    <section className="panel"><h2>إضافة منطقة خدمة</h2><p>ارسم حدود المنطقة من مزوّد GIS ثم الصق GeoJSON موثوقاً بإحداثيات WGS84.</p>
      <label>اسم المنطقة<input value={zoneName} onChange={e=>setZoneName(e.target.value)} /></label>
      <label>المدينة/الولاية<input value={city} onChange={e=>setCity(e.target.value)} /></label>
      <label>حدود GeoJSON<textarea rows={7} value={geo} onChange={e=>setGeo(e.target.value)} placeholder='{"type":"Polygon","coordinates":[...]}' /></label>
      <button disabled={busy||!zoneName||!city||!geo} onClick={addZone}>حفظ المنطقة</button>
    </section>
    <section className="panel"><h2>إضافة فئة مركبة</h2>
      <label>رمز داخلي<input value={code} onChange={e=>setCode(e.target.value)} placeholder="standard" /></label>
      <label>اسم الفئة<input value={categoryName} onChange={e=>setCategoryName(e.target.value)} /></label>
      <div className="two-fields"><label>أقل مقاعد<input type="number" min="1" max="12" value={minCap} onChange={e=>setMinCap(e.target.value)} /></label><label>أقصى مقاعد<input type="number" min="1" max="12" value={maxCap} onChange={e=>setMaxCap(e.target.value)} /></label></div>
      <button disabled={busy||!code||!categoryName} onClick={addCategory}>حفظ الفئة</button>
    </section>
    <section className="panel"><h2>مناطق الخدمة الحالية</h2>{zones.map(z=><div className="config-row" key={z.id}><span>{z.name} — {z.city}</span><button disabled={busy} onClick={()=>toggleZone(z)}>{z.is_active?'تعطيل':'تفعيل'}</button></div>)}</section>
    <section className="panel"><h2>فئات الرحلات الحالية</h2>{categories.map(c=><div className="config-row" key={c.code}><span>{c.display_name} · {c.min_capacity}-{c.max_capacity}</span><button disabled={busy} onClick={()=>toggleCategory(c)}>{c.is_active?'تعطيل':'تفعيل'}</button></div>)}</section>
    <section className="panel span-two"><h2>ربط الفئة بالمنطقة</h2>
      <label>منطقة الخدمة<select value={zoneId} onChange={e=>setZoneId(e.target.value)}>{zones.map(z=><option key={z.id} value={z.id}>{z.name} — {z.city}{z.is_active?'':' (غير نشطة)'}</option>)}</select></label>
      <label>الفئة<select value={categoryCode} onChange={e=>setCategoryCode(e.target.value)}>{categories.map(c=><option key={c.code} value={c.code}>{c.display_name} ({c.code})</option>)}</select></label>
      <button disabled={busy||!zoneId||!categoryCode} onClick={enableCategory}>تفعيل الفئة في المنطقة</button>
    </section>
    <section className="panel span-two"><h2>تعرفة الرحلة</h2><p>أدخل المبالغ بالدينار الجزائري. تُخزّن داخلياً بالسنتيم (×100).</p>
      <div className="fare-fields"><label>السعر الأساسي (دج)<input type="number" min="0" value={base} onChange={e=>setBase(e.target.value)} /></label>
      <label>لكل كيلومتر (دج)<input type="number" min="0" value={perKm} onChange={e=>setPerKm(e.target.value)} /></label>
      <label>لكل دقيقة (دج)<input type="number" min="0" value={perMin} onChange={e=>setPerMin(e.target.value)} /></label>
      <label>الحد الأدنى (دج)<input type="number" min="0" value={minimum} onChange={e=>setMinimum(e.target.value)} /></label>
      <label>نسخة التعرفة<input type="number" min="1" value={version} onChange={e=>setVersion(e.target.value)} /></label></div>
      <button disabled={busy||!zoneId||!categoryCode||!base||!perKm||!perMin||!minimum} onClick={addFare}>حفظ التعرفة</button>
    </section>
    {message&&<p className="form-message span-two">{message}</p>}
  </div>;
}
