import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '../../lib/supabase-server';
import SettingsForms from './settings-forms';
export default async function SettingsPage() {
  const db = await createSupabaseServerClient();
  const { data: { user } } = await db.auth.getUser();
  if (!user) redirect('/login');
  const { data: profile } = await db.from('profiles').select('role,is_active').eq('id',user.id).maybeSingle();
  if (!profile?.is_active || profile.role !== 'admin') redirect('/');
  const [{data:zones},{data:categories}] = await Promise.all([
    db.from('service_zones').select('id,name,city,is_active').order('created_at',{ascending:false}),
    db.from('ride_categories').select('code,display_name,min_capacity,max_capacity,is_active').order('created_at',{ascending:false}),
  ]);
  return <main className="dashboard" dir="rtl">
    <header className="topbar"><div><span className="eyebrow">إعدادات التشغيل</span><h1>مناطق الخدمة والأسعار</h1><p>لا تقبل الرحلات في منطقة حتى تهيّئ الحدود والفئات والتعرفة.</p></div><Link href="/">العودة للوحة الرئيسية</Link></header>
    <SettingsForms zones={zones ?? []} categories={categories ?? []} />
  </main>;
}
