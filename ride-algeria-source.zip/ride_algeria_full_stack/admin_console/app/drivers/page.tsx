import Link from 'next/link';
import { redirect } from 'next/navigation';
import { createSupabaseServerClient } from '../../lib/supabase-server';
import ReviewActions from './review-actions';

export default async function DriversPage() {
  const db = await createSupabaseServerClient();
  const { data: { user } } = await db.auth.getUser();
  if (!user) redirect('/login');
  const { data: actor } = await db.from('profiles').select('role,is_active').eq('id',user.id).maybeSingle();
  if (!actor?.is_active || actor.role !== 'admin') redirect('/');
  const { data: pending } = await db.from('driver_profiles').select('user_id,status,created_at').eq('status','pending').order('created_at',{ascending:true});
  const ids = (pending ?? []).map(x => x.user_id);
  const [{ data: profiles }, { data: vehicles }, { data: docs }] = await Promise.all([
    ids.length ? db.from('profiles').select('id,first_name,last_name,phone_e164').in('id',ids) : Promise.resolve({data:[]}),
    ids.length ? db.from('vehicles').select('driver_id,make,model,color,plate_number,category_code,passenger_capacity').in('driver_id',ids) : Promise.resolve({data:[]}),
    ids.length ? db.from('driver_documents').select('driver_id,document_type,storage_path,expires_at').in('driver_id',ids) : Promise.resolve({data:[]}),
  ]);
  const profileById = new Map((profiles ?? []).map(x => [x.id,x]));
  const vehicleById = new Map((vehicles ?? []).map(x => [x.driver_id,x]));
  const docsById = new Map<string, any[]>();
  for (const doc of docs ?? []) {
    const signed = await db.storage.from('driver-documents').createSignedUrl(doc.storage_path, 300);
    docsById.set(doc.driver_id,[...(docsById.get(doc.driver_id) ?? []),{...doc,signedUrl:signed.data?.signedUrl ?? null}]);
  }
  return <main className="dashboard" dir="rtl">
    <header className="topbar"><div><span className="eyebrow">إدارة السائقين</span><h1>طلبات اعتماد السائقين</h1><p>مراجعة بيانات المركبة والوثائق قبل تفعيل استقبال الرحلات.</p></div><Link href="/">العودة للوحة الرئيسية</Link></header>
    {(pending ?? []).length === 0 && <section className="panel empty">لا توجد طلبات اعتماد معلّقة حالياً.</section>}
    {(pending ?? []).map(item => {
      const profile = profileById.get(item.user_id);
      const vehicle = vehicleById.get(item.user_id);
      const driverDocs = docsById.get(item.user_id) ?? [];
      return <section className="panel" key={item.user_id}>
        <div className="panel-heading"><div><h2>{profile?.first_name ?? 'سائق'} {profile?.last_name ?? ''}</h2><p>{profile?.phone_e164 ?? item.user_id}</p></div><span className="status">قيد المراجعة</span></div>
        <div className="vehicle-info"><strong>المركبة</strong><p>{vehicle ? `${vehicle.make} ${vehicle.model} · ${vehicle.color} · ${vehicle.plate_number} · ${vehicle.passenger_capacity} مقاعد · ${vehicle.category_code}` : 'بيانات المركبة غير مكتملة'}</p></div>
        <div className="docs-list"><strong>الوثائق المرفوعة</strong>{driverDocs.map(doc=><div key={doc.storage_path}>{doc.document_type} — {doc.signedUrl ? <a href={doc.signedUrl} target="_blank" rel="noreferrer">عرض الوثيقة</a> : 'تعذر إنشاء رابط مؤقت'}</div>)}</div>
        <ReviewActions driverId={item.user_id} />
      </section>;
    })}
  </main>;
}
