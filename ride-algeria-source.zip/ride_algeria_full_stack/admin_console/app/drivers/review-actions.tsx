'use client';
import { useState } from 'react';
import { getSupabaseBrowserClient } from '../../lib/supabase-browser';

export default function ReviewActions({ driverId }: { driverId: string }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  async function review(decision: 'approved' | 'rejected') {
    if (decision === 'rejected' && reason.trim().length < 5) { setMessage('اكتب سبب الرفض بوضوح.'); return; }
    setBusy(true); setMessage('');
    try {
      const { error } = await getSupabaseBrowserClient().functions.invoke('review-driver-application', {
        body: { driver_id: driverId, decision, reason: reason.trim() },
      });
      if (error) throw error;
      setMessage(decision === 'approved' ? 'تم اعتماد السائق.' : 'تم رفض الطلب.');
      window.location.reload();
    } catch (e) { setMessage(e instanceof Error ? e.message : 'تعذر تنفيذ المراجعة.'); }
    finally { setBusy(false); }
  }
  return <div className="review-actions">
    <input value={reason} onChange={e => setReason(e.target.value)} placeholder="سبب الرفض (عند الرفض)" />
    <div><button disabled={busy} onClick={() => review('approved')}>اعتماد السائق</button>
      <button className="danger" disabled={busy} onClick={() => review('rejected')}>رفض الطلب</button></div>
    {message && <small>{message}</small>}
  </div>;
}
