import type { ReactNode } from 'react';
import './style.css';
export const metadata={title:'Ride Algeria Operations',description:'Operations console scaffold'};
export default function RootLayout({children}:{children:ReactNode}){return <html lang="ar" dir="rtl"><body>{children}</body></html>}
