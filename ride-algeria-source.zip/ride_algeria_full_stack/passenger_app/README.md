# Passenger Android app

Flutter application using Supabase phone OTP, GPS pickup, licensed map tiles, geocoding adapter search, server-generated category quotes, cash trip requests, dispatch initiation and realtime trip status.

Configure `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `MAP_TILE_URL`, and `MAP_ATTRIBUTION` through `--dart-define`. Configure server-only routing/geocoding secrets in Supabase. Android host files can be regenerated with `../scripts/bootstrap_android.sh` if the Flutter SDK version requires a fresh wrapper. The destination picker requires a licensed geocoding adapter or a manual map tap. This app does not use mock prices or mock trips.
