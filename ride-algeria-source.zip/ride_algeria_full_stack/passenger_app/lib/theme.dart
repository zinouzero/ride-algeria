import 'package:flutter/material.dart';
abstract final class AppTokens {
  static const bg=Color(0xFFF7F8FA), surface=Color(0xFFFFFFFF);
  static const text=Color(0xFF17212B), muted=Color(0xFF5C6672);
  static const accent=Color(0xFF2457C5), border=Color(0xFFD9DEE5);
}
ThemeData buildAppTheme()=>ThemeData(
  useMaterial3:true, colorScheme:ColorScheme.fromSeed(seedColor:AppTokens.accent),
  scaffoldBackgroundColor:AppTokens.bg,
  appBarTheme:const AppBarTheme(backgroundColor:AppTokens.bg,foregroundColor:AppTokens.text),
  inputDecorationTheme:InputDecorationTheme(
    filled:true,fillColor:AppTokens.surface,
    border:OutlineInputBorder(borderRadius:BorderRadius.circular(12)),
  ),
  cardTheme:CardThemeData(color:AppTokens.surface,elevation:0,
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16),
      side:const BorderSide(color:AppTokens.border))),
);
