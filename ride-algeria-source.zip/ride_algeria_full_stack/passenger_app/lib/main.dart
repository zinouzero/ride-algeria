import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabasePublishableKey = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
const mapTileUrl = String.fromEnvironment('MAP_TILE_URL');
const mapAttribution = String.fromEnvironment('MAP_ATTRIBUTION', defaultValue: 'Map data provider');
const appTitle = 'مشواري';
String formatDzd(dynamic minor) { final value=(num.tryParse(minor.toString())??0)/100; return value==value.roundToDouble()?value.toStringAsFixed(0):value.toStringAsFixed(2); }

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabasePublishableKey.isEmpty) {
    runApp(const ConfigurationApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  runApp(const MashwariApp());
}

class ConfigurationApp extends StatelessWidget {
  const ConfigurationApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: appTitle,
    home: const Scaffold(body: Center(child: Padding(padding: EdgeInsets.all(28), child: Text(
      'إعدادات تشغيل التطبيق غير مكتملة. يلزم ربط مشروع الخادم ومفتاح التطبيق العام ومزوّد الخرائط قبل تشغيل الخدمة.',
      textAlign: TextAlign.center, style: TextStyle(fontSize: 17),
    )))),
  );
}

class MashwariApp extends StatelessWidget {
  const MashwariApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: appTitle, theme: ThemeData(
      useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2457C5)),
      scaffoldBackgroundColor: const Color(0xFFF7F8FA), fontFamily: 'NotoSansArabic'),
    locale: const Locale('ar'), supportedLocales: const [Locale('ar'), Locale('fr'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: const AuthGate(),
    builder: (context, child) => Directionality(textDirection: Localizations.localeOf(context).languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr, child: child ?? const SizedBox.shrink()),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: Supabase.instance.client.auth.onAuthStateChange,
    builder: (context, snapshot) => Supabase.instance.client.auth.currentSession == null
      ? const PhoneLoginScreen() : const BookingScreen(),
  );
}

class PhoneLoginScreen extends StatefulWidget {
  const PhoneLoginScreen({super.key});
  @override
  State<PhoneLoginScreen> createState() => _PhoneLoginScreenState();
}
class _PhoneLoginScreenState extends State<PhoneLoginScreen> {
  final phone = TextEditingController(text: '+213');
  final code = TextEditingController();
  bool sent = false, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      final auth = Supabase.instance.client.auth;
      if (!sent) {
        await auth.signInWithOtp(phone: phone.text.trim());
        setState(() => sent = true);
      } else {
        await auth.verifyOTP(phone: phone.text.trim(), token: code.text.trim(), type: OtpType.sms);
      }
    } on AuthException catch (e) { setState(() => error = e.message); }
      catch (_) { setState(() => error = 'تعذر إكمال تسجيل الدخول. حاول مرة أخرى.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override
  void dispose() { phone.dispose(); code.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(
    padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Icon(Icons.local_taxi_rounded, size: 64, color: Color(0xFF2457C5)),
        const SizedBox(height: 22), const Text('مرحبا بك في مشواري', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), const Text('سجّل برقم هاتفك للمتابعة', textAlign: TextAlign.center),
        const SizedBox(height: 28), TextField(controller: phone, enabled: !sent, keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'رقم الهاتف الدولي', border: OutlineInputBorder(), prefixIcon: Icon(Icons.phone))),
        if (sent) ...[const SizedBox(height: 12), TextField(controller: code, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'رمز التحقق', border: OutlineInputBorder(), prefixIcon: Icon(Icons.lock_outline)))],
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 18), FilledButton(onPressed: busy ? null : submit,
          child: Text(busy ? 'يرجى الانتظار...' : sent ? 'تأكيد الرمز' : 'إرسال رمز التحقق')),
        const SizedBox(height: 14), const Text('قد تُطبق رسوم الرسائل حسب شركة الاتصالات.', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    ))))));
}

class BookingScreen extends StatefulWidget { const BookingScreen({super.key}); @override State<BookingScreen> createState() => _BookingScreenState(); }
class _BookingScreenState extends State<BookingScreen> {
  final mapController = MapController();
  final destinationSearch = TextEditingController();
  Timer? searchTimer;
  List<Map<String,dynamic>> suggestions = [];
  LatLng? pickup, dropoff;
  String pickupLabel = 'موقعي الحالي', dropoffLabel = 'اضغط على الخريطة لتحديد الوجهة';
  bool locating = false, loading = false, selectingPickup = false;
  String? error;
  Future<void> searchPlaces(String query) async {
    searchTimer?.cancel();
    if (query.trim().length < 2) { setState(() => suggestions = []); return; }
    searchTimer = Timer(const Duration(milliseconds: 350), () async {
      try {
        final result = await Supabase.instance.client.functions.invoke('search-places', body: {'query': query.trim()});
        final rows = (result.data as Map)['places'] as List? ?? [];
        if (mounted) setState(() => suggestions = rows.cast<Map<String,dynamic>>());
      } catch (_) { if (mounted) setState(() => suggestions = []); }
    });
  }
  void choosePlace(Map<String,dynamic> place) {
    final point = LatLng((place['latitude'] as num).toDouble(), (place['longitude'] as num).toDouble());
    setState(() { dropoff = point; dropoffLabel = place['label'] as String; destinationSearch.text = dropoffLabel; suggestions = []; error = null; });
    mapController.move(point, 15);
  }
  Future<void> locate() async {
    setState(() { locating = true; error = null; });
    try {
      if (!await Geolocator.isLocationServiceEnabled()) throw Exception('فعّل خدمة تحديد الموقع في الهاتف.');
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) throw Exception('يلزم السماح بالوصول إلى الموقع.');
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      final point = LatLng(pos.latitude, pos.longitude);
      setState(() { pickup = point; selectingPickup = false; pickupLabel = 'موقعي الحالي'; });
      mapController.move(point, 15);
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => locating = false); }
  }
  Future<void> openQuotes() async {
    if (pickup == null || dropoff == null) { setState(() => error = 'حدد موقع الانطلاق والوجهة أولاً.'); return; }
    setState(() { loading = true; error = null; });
    try {
      final response = await Supabase.instance.client.from('ride_categories').select('code,display_name,max_capacity').eq('is_active', true);
      final categories = (response as List).cast<Map<String,dynamic>>();
      if (categories.isEmpty) throw Exception('لا توجد فئات رحلات مفعّلة في منطقة الخدمة.');
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => QuoteScreen(
        pickup: pickup!, dropoff: dropoff!, pickupLabel: pickupLabel, dropoffLabel: dropoffLabel, categories: categories)));
    } on PostgrestException catch (e) { setState(() => error = e.message); }
      catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override
  void dispose() { searchTimer?.cancel(); destinationSearch.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text(appTitle), actions: [IconButton(onPressed: () => Navigator.push(context,MaterialPageRoute(builder:(_)=>const SupportScreen())),icon:const Icon(Icons.support_agent)),IconButton(onPressed: () => Navigator.push(context,MaterialPageRoute(builder:(_)=>const PassengerHistoryScreen())), icon: const Icon(Icons.history)),IconButton(onPressed: () async => Supabase.instance.client.auth.signOut(), icon: const Icon(Icons.logout))]),
    body: Column(children: [Expanded(child: mapTileUrl.isEmpty ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('مزوّد الخرائط غير مهيأ.')))
      : FlutterMap(mapController: mapController, options: MapOptions(initialCenter: const LatLng(36.75, 3.05), initialZoom: 6,
          onTap: (_, point) => setState(() { if (selectingPickup) { pickup = point; pickupLabel = '${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}'; selectingPickup = false; } else { dropoff = point; dropoffLabel = '${point.latitude.toStringAsFixed(5)}, ${point.longitude.toStringAsFixed(5)}'; destinationSearch.text = dropoffLabel; suggestions = []; } error = null; })),
        children: [TileLayer(urlTemplate: mapTileUrl, userAgentPackageName: 'com.mashwari.passenger'),
          MarkerLayer(markers: [if (pickup != null) Marker(point: pickup!, width: 42, height: 42, child: const Icon(Icons.my_location, color: Colors.blue, size: 34)),
            if (dropoff != null) Marker(point: dropoff!, width: 42, height: 42, child: const Icon(Icons.location_on, color: Colors.red, size: 38))]),
          RichAttributionWidget(attributions: [TextSourceAttribution(mapAttribution)])])),
      Container(color: Colors.white, padding: const EdgeInsets.fromLTRB(18, 16, 18, 20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [const Icon(Icons.trip_origin, color: Colors.green), const SizedBox(width: 10), Expanded(child: Text(pickupLabel, maxLines: 1, overflow: TextOverflow.ellipsis)), TextButton(onPressed: locating ? null : locate, child: Text(locating ? '...' : 'موقعي')),TextButton(onPressed:()=>setState(()=>selectingPickup=true),child:const Text('تعديل'))]),
        const Divider(height: 8),
        if(selectingPickup)const Padding(padding:EdgeInsets.only(bottom:8),child:Text('اضغط على الخريطة لتحديد نقطة الانطلاق الجديدة.',style:TextStyle(color:Color(0xFF2457C5)))),
        TextField(controller: destinationSearch, onChanged: searchPlaces, decoration: const InputDecoration(
          labelText: 'ابحث عن الوجهة أو اخترها من الخريطة', prefixIcon: Icon(Icons.search), border: OutlineInputBorder(), isDense: true)),
        if (suggestions.isNotEmpty) Container(constraints: const BoxConstraints(maxHeight: 180), decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.black12), borderRadius: BorderRadius.circular(10)),
          child: ListView(shrinkWrap: true, children: suggestions.map((place) => ListTile(dense: true, leading: const Icon(Icons.place_outlined), title: Text(place['label'] as String, maxLines: 2, overflow: TextOverflow.ellipsis), onTap: () => choosePlace(place))).toList())),
        Row(children: [const Icon(Icons.location_on, color: Colors.red), const SizedBox(width: 10), Expanded(child: Text(dropoffLabel, maxLines: 1, overflow: TextOverflow.ellipsis))]),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(error!, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 12), FilledButton(onPressed: loading ? null : openQuotes, child: Text(loading ? 'جارٍ التحضير...' : 'عرض الرحلات المتاحة')),
      ]))]));
}

class QuoteScreen extends StatefulWidget {
  const QuoteScreen({super.key, required this.pickup, required this.dropoff, required this.pickupLabel, required this.dropoffLabel, required this.categories});
  final LatLng pickup, dropoff; final String pickupLabel, dropoffLabel; final List<Map<String,dynamic>> categories;
  @override State<QuoteScreen> createState() => _QuoteScreenState();
}
class _QuoteScreenState extends State<QuoteScreen> {
  final Map<String,Map<String,dynamic>> quotes = {};
  bool loading = true, requesting = false; String? error;
  @override void initState() { super.initState(); loadQuotes(); }
  Future<void> loadQuotes() async {
    for (final category in widget.categories) {
      try {
        final result = await Supabase.instance.client.functions.invoke('create-quote', body: {
          'pickup_label': widget.pickupLabel, 'pickup_lat': widget.pickup.latitude, 'pickup_lng': widget.pickup.longitude,
          'dropoff_label': widget.dropoffLabel, 'dropoff_lat': widget.dropoff.latitude, 'dropoff_lng': widget.dropoff.longitude,
          'category_code': category['code'],
        });
        if (result.status >= 200 && result.status < 300 && result.data is Map && result.data['quote'] is Map) {
          quotes[category['code'] as String] = Map<String,dynamic>.from(result.data['quote'] as Map)..['display_name'] = category['display_name'];
        }
      } catch (_) { /* A category can be unavailable in this service zone. */ }
    }
    if (mounted) setState(() { loading = false; if (quotes.isEmpty) error = 'تعذر الحصول على أسعار. تأكد من منطقة الخدمة وإعداد التوجيه والأسعار.'; });
  }
  Future<void> request(Map<String,dynamic> quote) async {
    setState(() { requesting = true; error = null; });
    try {
      final result = await Supabase.instance.client.functions.invoke('request-trip', body: {'quote_id': quote['id'], 'payment_method': 'cash'},
        headers: {'Idempotency-Key': const Uuid().v4()});
      if (result.status < 200 || result.status >= 300) throw Exception('تعذر تسجيل طلب الرحلة.');
      final trip = Map<String,dynamic>.from((result.data as Map)['trip'] as Map);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => TripStatusScreen(tripId: trip['id'] as String)));
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => requesting = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('اختيار فئة الرحلة')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(18), children: [
      Text('من ${widget.pickupLabel}'), const Divider(), Text('إلى ${widget.dropoffLabel}'), const SizedBox(height: 20),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
      for (final quote in quotes.values) Card(child: ListTile(
        leading: const Icon(Icons.local_taxi, size: 32), title: Text(quote['display_name'] as String),
        subtitle: Text('${((quote['route_distance_m'] as num)/1000).toStringAsFixed(1)} كم · ${((quote['route_duration_s'] as num)/60).ceil()} دقيقة'),
        trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text('${formatDzd(quote['fare_minor'])} دج', style: const TextStyle(fontWeight: FontWeight.bold)),
          TextButton(onPressed: requesting ? null : () => request(quote), child: const Text('اطلب'))]),
      )),
      const Padding(padding: EdgeInsets.all(12), child: Text('الدفع نقداً للسائق بعد انتهاء الرحلة. السعر محسوب من مسار الطريق المزوّد من خدمة التوجيه.', textAlign: TextAlign.center)),
    ]));
}

class TripStatusScreen extends StatefulWidget { const TripStatusScreen({super.key, required this.tripId}); final String tripId; @override State<TripStatusScreen> createState() => _TripStatusScreenState(); }
class _TripStatusScreenState extends State<TripStatusScreen> {
  late final Stream<List<Map<String,dynamic>>> stream;
  String status = 'searching'; bool busy = false, rated = false;
  @override void initState() { super.initState(); stream = Supabase.instance.client.from('trips').stream(primaryKey: ['id']).eq('id', widget.tripId); }
  String label(String s) => switch(s) { 'searching' => 'نبحث عن سائق قريب', 'assigned' => 'تم تعيين سائق', 'driver_arriving' => 'السائق في الطريق إليك', 'driver_arrived' => 'السائق وصل إلى نقطة الانطلاق', 'in_progress' => 'الرحلة جارية', 'completed' => 'اكتملت الرحلة', 'no_driver_found' => 'لم نعثر على سائق متاح', 'passenger_cancelled' => 'تم إلغاء الرحلة', 'driver_cancelled' => 'ألغى السائق الرحلة', _ => s };
  Future<void> cancel() async {
    setState(() => busy = true);
    try { await Supabase.instance.client.functions.invoke('transition-trip', body: {'trip_id': widget.tripId, 'next_status': 'passenger_cancelled', 'reason': 'passenger_cancelled_in_app'}); }
    catch (_) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر إلغاء الرحلة.'))); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('حالة الرحلة')),
    body: StreamBuilder<List<Map<String,dynamic>>>(stream: stream, builder: (context,snapshot) {
      final rows = snapshot.data ?? const [];
      if (rows.isNotEmpty) status = rows.first['status'] as String? ?? status;
      final terminal = ['completed','no_driver_found','passenger_cancelled','driver_cancelled'].contains(status);
      return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(status == 'completed' ? Icons.check_circle : Icons.local_taxi, size: 72, color: const Color(0xFF2457C5)),
        const SizedBox(height: 20), Text(label(status), textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12), if (snapshot.hasError) const Text('تعذر تحديث حالة الرحلة. تحقق من الاتصال.'),
        if (!terminal) FilledButton.tonal(onPressed: busy ? null : cancel, child: Text(busy ? 'يرجى الانتظار' : 'إلغاء الرحلة')),
        if (status == 'completed' && !rated) RatingPanel(tripId: widget.tripId, onSubmitted: () => setState(() => rated = true)),
        if (terminal && (status != 'completed' || rated)) FilledButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('العودة')),
      ])));
    }));
}


class RatingPanel extends StatefulWidget {
  const RatingPanel({super.key, required this.tripId, required this.onSubmitted});
  final String tripId; final VoidCallback onSubmitted;
  @override State<RatingPanel> createState() => _RatingPanelState();
}
class _RatingPanelState extends State<RatingPanel> {
  int stars = 5; bool busy = false; String? error;
  final comment = TextEditingController();
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      final result = await Supabase.instance.client.functions.invoke('submit-rating', body: {
        'trip_id': widget.tripId, 'stars': stars, 'comment': comment.text.trim(),
      });
      if (result.status < 200 || result.status >= 300) throw Exception('تعذر إرسال التقييم.');
      widget.onSubmitted();
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ','')); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override void dispose() { comment.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
    const Text('قيّم تجربتك', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), Row(mainAxisAlignment: MainAxisAlignment.center, children: List.generate(5,(i)=>IconButton(
      onPressed: busy ? null : () => setState(() => stars=i+1), icon: Icon(i<stars?Icons.star:Icons.star_border,color:Colors.amber,size:32)))),
    TextField(controller: comment, maxLength: 500, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظة (اختيارية)', border: OutlineInputBorder())),
    if(error!=null) Text(error!,style:const TextStyle(color:Colors.red)),
    const SizedBox(height:8), FilledButton(onPressed:busy?null:submit,child:Text(busy?'يرجى الانتظار':'إرسال التقييم')),
  ])));
}


class PassengerHistoryScreen extends StatelessWidget {
  const PassengerHistoryScreen({super.key});
  @override Widget build(BuildContext context) {
    final uid=Supabase.instance.client.auth.currentUser!.id;
    return Scaffold(appBar:AppBar(title:const Text('سجل الرحلات')),body:FutureBuilder<List<Map<String,dynamic>>>(
      future:Supabase.instance.client.from('trips').select('id,status,pickup_label,dropoff_label,quoted_fare_minor,currency,created_at').eq('passenger_id',uid).order('created_at',ascending:false).limit(50),
      builder:(context,s){if(s.connectionState!=ConnectionState.done)return const Center(child:CircularProgressIndicator());
        if(s.hasError)return const Center(child:Text('تعذر تحميل سجل الرحلات.'));
        final rows=s.data??[];if(rows.isEmpty)return const Center(child:Text('لا توجد رحلات سابقة.'));
        return ListView.builder(itemCount:rows.length,itemBuilder:(context,i){final r=rows[i];return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(
          title:Text('${r['pickup_label']} ← ${r['dropoff_label']}',maxLines:2,overflow:TextOverflow.ellipsis),
          subtitle:Text('${r['status']} · ${DateTime.parse(r['created_at'] as String).toLocal()}'),
          trailing:Text('${formatDzd(r['quoted_fare_minor'])} دج',style:const TextStyle(fontWeight:FontWeight.bold)),
        ));});
      }));
  }
}


class SupportScreen extends StatefulWidget { const SupportScreen({super.key}); @override State<SupportScreen> createState()=>_SupportScreenState(); }
class _SupportScreenState extends State<SupportScreen> {
  final description=TextEditingController(),reply=TextEditingController();String category='trip';String? ticketId,error;bool busy=false;
  Future<void> createTicket() async {setState(()=>busy=true);try{final r=await Supabase.instance.client.functions.invoke('create-support-ticket',body:{'category':category,'description':description.text.trim()});if(r.status<200||r.status>=300)throw Exception('تعذر إنشاء التذكرة.');setState(()=>ticketId=(r.data as Map)['ticket']['id'] as String);}catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}}
  Future<void> sendReply() async {if(ticketId==null||reply.text.trim().isEmpty)return;setState(()=>busy=true);try{final r=await Supabase.instance.client.functions.invoke('send-support-message',body:{'ticket_id':ticketId,'message':reply.text.trim()});if(r.status<200||r.status>=300)throw Exception('تعذر إرسال الرسالة.');setState(()=>reply.clear());}catch(e){setState(()=>error=e.toString().replaceFirst('Exception: ',''));}finally{if(mounted)setState(()=>busy=false);}}
  @override void dispose(){description.dispose();reply.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('مساعدة ودعم')) ,body:ListView(padding:const EdgeInsets.all(18),children:[
    if(ticketId==null)...[const Text('كيف نقدروا نعاونك؟',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),DropdownButtonFormField<String>(value:category,decoration:const InputDecoration(labelText:'نوع المشكلة'),items:const [DropdownMenuItem(value:'trip',child:Text('رحلة')),DropdownMenuItem(value:'payment',child:Text('الدفع')),DropdownMenuItem(value:'driver',child:Text('السائق')),DropdownMenuItem(value:'safety',child:Text('السلامة')),DropdownMenuItem(value:'account',child:Text('الحساب')),DropdownMenuItem(value:'other',child:Text('أخرى'))],onChanged:(v)=>setState(()=>category=v??'other')),
      TextField(controller:description,maxLines:5,maxLength:3000,decoration:const InputDecoration(labelText:'اشرح المشكلة',border:OutlineInputBorder())),FilledButton(onPressed:busy?null:createTicket,child:Text(busy?'يرجى الانتظار':'إرسال التذكرة'))]
    else ...[const Icon(Icons.check_circle_outline,color:Colors.green,size:54),const Text('تم إنشاء التذكرة',textAlign:TextAlign.center,style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),SelectableText(ticketId!,textAlign:TextAlign.center),TextField(controller:reply,maxLines:3,decoration:const InputDecoration(labelText:'إضافة تفاصيل أخرى (اختياري)',border:OutlineInputBorder())),FilledButton(onPressed:busy?null:sendReply,child:const Text('إرسال رسالة'))],
    if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
  ]));
}
