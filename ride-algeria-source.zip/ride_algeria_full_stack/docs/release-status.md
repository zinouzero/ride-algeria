# Release status — source package

## Implemented in source

- Passenger Android application with phone OTP, GPS/map pickup selection, geocoding search, server quote, cash ride request, realtime trip status, cancellation, history, rating and support.
- Driver Android application with phone OTP, document/vehicle onboarding, admin approval gate, active-trip restoration after restart, foreground location heartbeat, realtime offers, accept/reject, trip lifecycle, external pickup navigation, cash receipt declaration, history and support.
- Next.js operations console with OTP, role checks, overview, driver approval, zone/category/fare setup, cash review and support tickets.
- 21 ordered Supabase migrations and 17 configured Edge Functions.
- PostGIS zone validation and driver candidate search, atomic offer acceptance, retry queue, trip lifecycle, cash ledger, ratings, support authorization and audit triggers.
- Release/deploy scripts for Bash and PowerShell.

## Checks actually run in the authoring environment

- 25 static checks passed.
- Dart source delimiter-balance check passed (not a Dart compiler/analyzer).
- TypeScript source syntax transpilation passed for the included `.ts` and `.tsx` files (not a full Next.js typecheck/build).
- Both Flutter `pubspec.yaml` files parsed successfully.
- Admin `package.json` parsed successfully.
- Supabase `config.toml` parsed successfully; all 17 Edge Function folders have matching configuration entries.
- SQL migration structure checks passed (balanced parentheses/dollar-quoted blocks and statement endings; not a PostgreSQL parser or execution test).

## Not run / not yet proven

This environment does not have Flutter, Dart, Android SDK/Gradle, Supabase CLI, or PostgreSQL. Network package installation also timed out. Therefore no signed APK/AAB, Next production build, SQL migration execution, live RLS test, Supabase integration test, or physical-device test was produced here. Do not treat the source package as approved for public launch until those checks pass.

## Mandatory launch gates

1. Create and configure the production Supabase project; apply all 21 migrations; deploy all 17 Edge Functions; test RLS with separate passenger, driver, support and admin accounts.
2. Configure an Algerian-capable SMS OTP provider and verify Djezzy, Mobilis and Ooredoo delivery, abuse limits and recovery.
3. Select licensed commercial map tiles, routing and geocoding providers; validate address and route accuracy in every launch zone; set all server secrets.
4. Provision valid GeoJSON service zones, ride categories, zone-category mappings and DZD fare rules in the admin console.
5. Configure and monitor the private dispatch scheduler every 20–30 seconds.
6. Implement and test Firebase push token registration/FCM delivery and an Android foreground location service. Current driver tracking is foreground-only and background offers depend on push, which is not implemented yet.
7. Complete local transport/intermediation, driver/vehicle, insurance, tax, consumer and privacy review for the exact business model and launch city.
8. Generate and protect separate upload keystores, run `scripts/build_release.ps1` or `.sh`, test signed bundles on real Android devices and complete Play Store declarations/review.
9. Run concurrency, abuse, penetration, load, crash, location-permission, offline/network-loss and end-to-end trip tests before inviting paying passengers.

## Scope limitations

The initial product is ride-hailing only and cash-first. It does not include card processing, wallet, driver commission settlement, scheduled rides, multi-stop rides, in-app turn-by-turn driver navigation, push notifications, background location, or an audit-log browser. Candidate ranking currently uses straight-line geographic distance, not live road ETA. These are not silently simulated; configure and test the required integrations before launch.
