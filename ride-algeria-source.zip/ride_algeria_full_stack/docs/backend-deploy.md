# Supabase deployment reference

Run from the repository root with the Supabase CLI installed and authenticated:

```bash
supabase link --project-ref YOUR_PROJECT_REF
supabase db push
```

Deploy functions:

```bash
for fn in create-quote dispatch-trip dispatch-worker driver-active-trip driver-offer-details driver-response request-trip review-driver-application review-cash-collection mark-cash-collected search-places submit-driver-application submit-rating create-support-ticket send-support-message transition-trip update-driver-location; do
  supabase functions deploy "$fn"
done
```

Set secrets (replace placeholders locally; do not commit actual values):

```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=... \
  ROUTING_ADAPTER_URL=... ROUTING_ADAPTER_KEY=... \
  GEOCODING_ADAPTER_URL=... GEOCODING_ADAPTER_KEY=... \
  ALLOWED_ORIGIN=https://admin.yourdomain.dz DISPATCH_WORKER_SECRET=...
```

Supabase supplies project URL and anon key to Edge Functions in normal projects; verify the deployed function environment before traffic. Never pass service-role credentials to mobile clients or the admin browser.

## Provisioning the first administrator

Only a trusted project owner should do this after creating a phone-authenticated user and verifying the UUID:

```sql
update public.profiles
set role = 'admin', is_active = true
where id = 'VERIFIED_AUTH_USER_UUID';
```

Run this through the Supabase SQL editor under owner privileges, not through a public API. The profile-protection trigger intentionally prevents ordinary users from changing their own role.

## Service zone and fares

No zone geometry or fare values are seeded. An operator must insert reviewed GeoJSON polygons, enable categories, and create versioned DZD fare rules for the actual launch city. Quotes will fail closed when any of these records or the routing adapter are missing.

## Dispatch retry schedule

`dispatch-worker` is intentionally deployed with JWT verification disabled and protects itself with the private `x-worker-secret` header. Configure a trusted server-side scheduler to POST to `/functions/v1/dispatch-worker` every 20–30 seconds, sending that secret. Never call it from a mobile app or browser. The database serializes dispatch attempts per trip and stops after five rounds.
