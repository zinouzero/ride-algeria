# Ride Algeria — system architecture

## Applications

- Passenger Android: Flutter, Supabase Auth phone OTP, MapLibre-compatible map tiles through `flutter_map`, GPS pickup, geocoding adapter, server-priced quotes, cash ride requests, Realtime trip status, trip history, rating and support.
- Driver Android: Flutter, OTP, private document upload, pending/approved driver gate, online/offline presence, active-trip restoration, foreground location heartbeat, realtime offers, atomic accept/reject, lifecycle updates, external navigation handoff, cash receipt confirmation, trip history and support.
- Operations web: Next.js 16 App Router + React 19 + Supabase SSR. Phone OTP, admin/support roles, overview, driver approvals, service-zone/category/fare management, cash review and support tickets.

## Backend

Supabase PostgreSQL is the source of truth. RLS protects user-owned reads; client apps cannot directly mutate trips, offers, driver presence, cash ledger, ratings or support tickets. Authenticated Edge Functions validate identity and use the service-role key server-side. Privileged SQL RPCs are granted only to `service_role`.

PostGIS stores validated service-zone geometry and driver geography. GiST indexes support zone coverage and 12 km driver candidate lookup. Candidate ranking currently uses straight-line distance; road-ETA matrix ranking remains an improvement before large-scale deployment.

## Trip state machine

`draft → quoted → requested → searching → assigned → driver_arriving → driver_arrived → in_progress → completed`

Terminal outcomes: `passenger_cancelled`, `driver_cancelled`, `no_driver_found`, `quote_expired`, and `support_review` where applicable. The database locks trip rows for transitions and offer acceptance. Dispatch retries are serialized with `FOR UPDATE SKIP LOCKED`, use five rounds, and require a private scheduled worker call.

## Money

Cash-first only. All monetary database columns ending in `_minor` are integer centimes: 100 centimes = 1 DZD. Admin fare forms accept DZD and convert to centimes. A completed trip creates a due cash collection and ledger entry; the assigned driver declares receipt; an admin can flag or confirm the declaration. No card processing, wallet, refunds automation or driver commission settlement is implemented.

## Core data groups

- Identity and onboarding: profiles, devices, driver_profiles, vehicles, driver_documents.
- Supply and pricing: service_zones, ride_categories, zone_categories, fare_rules.
- Dispatch and trip: ride_quotes, trips, driver_presence, driver_offers, trip_events, driver_locations, idempotency_keys.
- Money: cash_collections, payment_ledger.
- Trust and operations: ratings, support_tickets, support_messages, admin_audit_log.

## Important boundaries

The app does not copy Yassir code, private APIs, assets, brand or driver/customer data. This is an independent implementation. A functioning source tree does not equal a commercial launch: the operator still must configure licensed routing/geocoding/tiles, Algerian OTP delivery, secure dispatch scheduling, Firebase push, Android background location, service zones/fare rules, support operations, local legal/insurance requirements, store signing and live testing.
