# Production integrations and release gates

This document defines the contracts that must be configured before a commercial launch. Credentials belong in Supabase Function Secrets or the hosting provider's secret store, never in Flutter or browser bundles.

## 1. Routing adapter — mandatory

`create-quote` calls `ROUTING_ADAPTER_URL` with a POST request and bearer `ROUTING_ADAPTER_KEY`.

Request:

```json
{
  "origin": { "latitude": 36.7, "longitude": 3.0 },
  "destination": { "latitude": 36.8, "longitude": 3.1 },
  "profile": "car"
}
```

Response:

```json
{
  "distance_m": 8400,
  "duration_s": 1320,
  "geometry": "optional-provider-encoded-polyline"
}
```

`distance_m` and `duration_s` must be positive integers. The Edge Function rejects missing or invalid route data and does not fall back to straight-line distance. Select a provider only after verifying Algeria coverage, commercial use rights, Arabic/French address support, rate limits, data processing terms, and cost at expected trip volume.

## 2. Geocoding adapter — mandatory for address search

`search-places` calls `GEOCODING_ADAPTER_URL` with bearer `GEOCODING_ADAPTER_KEY`.

Request:

```json
{ "query": "Place name", "language": ["ar", "fr"], "country_code": "dz", "limit": 8 }
```

Response:

```json
{
  "results": [
    { "label": "Readable place name", "latitude": 36.7, "longitude": 3.0, "provider_place_id": "provider-id" }
  ]
}
```

The passenger app allows map selection if place search is unavailable, but a polished public launch needs a tested provider and clear pickup pin confirmation.

## 3. Map tiles — mandatory

Build passenger Android with `MAP_TILE_URL` and `MAP_ATTRIBUTION` Dart defines. The URL must be a production tile endpoint whose license permits commercial use. Do not use public OpenStreetMap tile servers as a production tile backend. Verify tile coverage, attribution, caching, offline policy, quotas and pricing.

## 4. Phone OTP / SMS — mandatory

Configure Supabase Auth Phone OTP with an SMS vendor that can reliably deliver to Algerian networks (Djezzy, Mobilis, Ooredoo). Test international phone normalization, delivery latency, retries, abuse limits, OTP expiry, resend cooldown, and account recovery. The profile bootstrap trigger assumes Auth creates a phone-authenticated user with an E.164 phone number.

## 5. Push notifications — mandatory for background driver dispatch

The database retries expired dispatch offers up to five rounds using a locked queue function; the geospatial candidate query uses PostGIS geography and a GiST index, but ranks by straight-line distance rather than road ETA; schedule the private `dispatch-worker` Edge Function every 20–30 seconds. The driver app confirms cash receipt after completion; admins can flag and confirm declared cash in the operations console. The current driver app receives offer events while active through Supabase Realtime. It does not yet register FCM tokens or receive background push. Before launch:

- configure Firebase for both Android package IDs;
- register device tokens in `public.devices` with platform `android`;
- implement a server-side FCM sender using Firebase service credentials stored only in Supabase secrets;
- send a push when an offer is created and when a trip changes state;
- handle notification taps, token refresh, revoked tokens and delivery failures;
- retain Realtime as the foreground synchronization channel.

Do not place Firebase service-account JSON or server keys in the APK.

## 6. Driver background location — mandatory

The driver app currently updates location while the app is in the foreground. It does not yet include a tested Android foreground service, persistent notification, background permission education, battery optimization handling, or process-death recovery. A production dispatch service must continue location only while the driver explicitly chooses to be online, show a persistent notification, stop promptly when offline, and obey Android background-location policy.

## 7. Operations setup — mandatory

Before accepting rides, administrators must provision:

- approved service-zone polygons in `service_zones`;
- enabled ride categories and zone-category mappings;
- fare rules in DZD, including minimum fare, distance/time components and effective dates;
- at least one approved driver, verified documents, and an active vehicle matching an enabled category;
- support staffing, cancellation policy, lost-item process, incident escalation, refunds/adjustments and driver cash reconciliation.

No Algeria-wide service zones or fare amounts are seeded because coverage and commercial prices must be decided by the operator, not guessed.

## 8. Security and compliance review — mandatory

- Have a qualified local adviser confirm the transport/intermediation permissions, vehicle and driver requirements, insurance, tax/accounting, consumer terms, and city-by-city operating rules applicable to the actual business model.
- Publish Arabic and French privacy notice, terms, cancellation/fare rules, retention schedule and support contacts.
- Review location-data minimization, retention, deletion requests, breach response and access audit.
- Configure exact `ALLOWED_ORIGIN`; do not retain wildcard CORS for the production admin origin.
- Provision the first admin account through a trusted operator-only SQL process; never allow public metadata to set `role='admin'`.
- Perform independent penetration testing and RLS review before storing identity documents or real customer location history.

## 9. Release validation — mandatory

The local static suite is not a substitute for these tests:

1. Supabase migrations apply cleanly to a new project and upgrade an already migrated project.
2. Passenger and driver RLS isolation tests with separate test accounts.
3. Concurrent idempotency and concurrent offer acceptance tests.
4. Full trip lifecycle, passenger cancellation during dispatch, driver cancellation, expiry and no-driver cases.
5. Driver location staleness, denied permissions, GPS drift and background process death.
6. OTP delivery and rate-limit tests across Algerian carriers.
7. Routing/geocoding accuracy tests across every launch zone, including address ambiguity and out-of-zone dropoff.
8. Push delivery while foreground/background/terminated.
9. Load tests for peak dispatch, realtime subscriptions, route calls and DB connection limits.
10. Android release signing, Play Integrity/target SDK checks, privacy declarations, accessibility, crash monitoring and store review.

## Known current gaps

- No push token registration or FCM sender; dispatch retry requires a secured external scheduler.
- Driver location is foreground-only; no Android foreground service yet.
- Passenger pickup uses GPS coordinates and destination autocomplete/map pin; reverse geocoding, landmark confirmation and route polyline rendering need completion.
- Driver navigation/route geometry and turn-by-turn handoff are not implemented.
- Admin console currently supports overview, driver approval, service-zone/fare/category configuration, cash reconciliation, support workflow and configuration audit triggers; a dedicated audit-log browser and more detailed finance reports remain outstanding.
- No live Supabase project or routing/geocoding provider is connected.
- Flutter/Dart/Android SDK, Supabase CLI and PostgreSQL server were unavailable in the authoring environment; Flutter builds and database execution could not be run here.
